import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Mic, MicOff } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function VoiceToText({ onTranscript, className = "" }) {
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const [recognition, setRecognition] = useState(null);

  useEffect(() => {
    // Check if speech recognition is supported
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (SpeechRecognition) {
      setIsSupported(true);
      const recognitionInstance = new SpeechRecognition();
      
      // Configure recognition
      recognitionInstance.continuous = false; // Listen for single utterance
      recognitionInstance.interimResults = false; // Only get final results
      recognitionInstance.lang = 'en-US'; // Set language
      
      recognitionInstance.onstart = () => {
        setIsListening(true);
      };
      
      recognitionInstance.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        onTranscript(transcript);
      };
      
      recognitionInstance.onend = () => {
        setIsListening(false);
      };
      
      recognitionInstance.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        if (event.error === 'not-allowed') {
          alert('Microphone access denied. Please allow microphone access and try again.');
        }
      };
      
      setRecognition(recognitionInstance);
    }
  }, [onTranscript]);

  const toggleListening = () => {
    if (!recognition) return;
    
    if (isListening) {
      recognition.stop();
    } else {
      recognition.start();
    }
  };

  if (!isSupported) {
    return null;
  }

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <Button
        type="button"
        variant="ghost"
        size="icon"
        onClick={toggleListening}
        className={`w-8 h-8 transition-all ${
          isListening 
            ? "text-red-400 hover:bg-red-900/30 animate-pulse" 
            : "text-gray-400 hover:text-yellow-300 hover:bg-yellow-900/30"
        }`}
        title={isListening ? "Stop listening" : "Start voice input"}
      >
        {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
      </Button>
      
      {isListening && (
        <Badge variant="outline" className="border-red-500 text-red-400 animate-pulse text-xs">
          <div className="w-2 h-2 bg-red-500 rounded-full mr-1 animate-ping"></div>
          Listening...
        </Badge>
      )}
    </div>
  );
}