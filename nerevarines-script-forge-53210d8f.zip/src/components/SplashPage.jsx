import React, { useEffect } from "react";
import { ScrollText } from "lucide-react";

export default function SplashPage({ onFinish }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onFinish();
    }, 4000); // Display for 4 seconds
    return () => clearTimeout(timer);
  }, [onFinish]);

  const splashBgImage = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d0d51882c8fca653210d8f/3f47e2ff2_elderscrollsonline_3952093b.jpg";

  return (
    <div
      className="splash-container"
      style={{
        backgroundImage: `url(${splashBgImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
      }}
    >
      <style jsx>{`
        .splash-container {
          position: fixed;
          top: 0;
          left: 0;
          width: 100vw;
          height: 100vh;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          z-index: 9999;
          background-color: rgba(0, 0, 0, 0.7); /* Dark overlay for text contrast */
          color: white;
          text-align: center;
          font-family: 'serif'; /* Using the font-serif from Layout */
          overflow: hidden;
        }

        .splash-icon-wrapper {
          position: relative;
          padding: 16px;
          background: linear-gradient(135deg, rgba(139, 95, 191, 0.5) 0%, rgba(76, 42, 133, 0.6) 100%);
          border-radius: 20px;
          border: 2px solid rgba(244, 208, 63, 0.7);
          box-shadow: 0 0 30px rgba(139, 95, 191, 0.8), 0 0 15px rgba(244, 208, 63, 0.5);
          animation: splashGlow 3s infinite alternate;
          margin-bottom: 24px;
        }

        @keyframes splashGlow {
          0% { box-shadow: 0 0 30px rgba(139, 95, 191, 0.8), 0 0 15px rgba(244, 208, 63, 0.5); }
          50% { box-shadow: 0 0 45px rgba(139, 95, 191, 1), 0 0 25px rgba(244, 208, 63, 0.8); }
          100% { box-shadow: 0 0 30px rgba(139, 95, 191, 0.8), 0 0 15px rgba(244, 208, 63, 0.5); }
        }

        .splash-icon {
          width: 80px;
          height: 80px;
          color: #f4d03f; /* Using magical-gold color */
          animation: float 4s ease-in-out infinite;
        }

        .splash-title {
          font-size: 3.5rem; /* Larger font size */
          font-weight: bold;
          color: #f4d03f; /* Gold color for title */
          margin-bottom: 8px;
          letter-spacing: 2px;
          text-shadow: 0 0 20px rgba(244, 208, 63, 0.7), 0 0 10px rgba(243, 156, 18, 0.5);
          animation: textFadeIn 2s ease-out forwards;
        }

        .splash-subtitle {
          font-size: 1.5rem;
          color: #d1c4e9; /* Light purple for subtitle */
          text-shadow: 0 0 10px rgba(139, 95, 191, 0.6);
          animation: textFadeIn 2.5s ease-out forwards;
          animation-delay: 0.5s;
          opacity: 0; /* Start hidden */
        }

        @keyframes textFadeIn {
          0% { opacity: 0; transform: translateY(20px); }
          100% { opacity: 1; transform: translateY(0); }
        }

        /* Reusing float animation from Layout for consistency */
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }

        .loading-dots {
          display: flex;
          margin-top: 30px;
        }
        .loading-dots div {
          width: 10px;
          height: 10px;
          background-color: #f4d03f; /* magical-gold */
          border-radius: 50%;
          margin: 0 5px;
          animation: bounce 1.4s infinite ease-in-out both;
        }
        .loading-dots div:nth-child(1) { animation-delay: -0.32s; }
        .loading-dots div:nth-child(2) { animation-delay: -0.16s; }
        .loading-dots div:nth-child(3) { animation-delay: 0s; }

        @keyframes bounce {
          0%, 80%, 100% { transform: scale(0); }
          40% { transform: scale(1); }
        }
      `}</style>
      <div className="splash-icon-wrapper">
        <ScrollText className="splash-icon" />
      </div>
      <h1 className="splash-title">Unofficial TES Script Creator</h1>
      <p className="splash-subtitle">✨ AI-Powered Modding Assistant ✨</p>
      <div className="loading-dots">
        <div></div>
        <div></div>
        <div></div>
      </div>
    </div>
  );
}