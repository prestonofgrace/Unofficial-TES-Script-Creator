import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clipboard, Download } from "lucide-react";
import ReactMarkdown from "react-markdown";

export default function NexusDescriptionOutput({ description }) {
  const [isCopied, setIsCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(description);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <Card className="bg-gray-800/50 border-yellow-800/30">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-yellow-300 flex items-center gap-2">
          <Download className="w-5 h-5" />
          Nexus Mods Description
        </CardTitle>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleCopy}
          className="text-gray-400 hover:text-white"
        >
          <Clipboard className="w-4 h-4 mr-2" />
          {isCopied ? "Copied!" : "Copy Description"}
        </Button>
      </CardHeader>
      <CardContent>
        <div className="prose prose-invert prose-sm max-w-none bg-black/30 p-4 rounded-md border border-gray-700">
          <ReactMarkdown>{description}</ReactMarkdown>
        </div>
      </CardContent>
    </Card>
  );
}