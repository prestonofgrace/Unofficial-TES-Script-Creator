
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  MessageSquare, 
  AlertTriangle, 
  Lightbulb, 
  HelpCircle, 
  CheckCircle,
  Loader2,
  Wand2,
  RotateCcw
} from "lucide-react";
import VoiceToText from "./VoiceToText";

export default function DiscussionPanel({ 
  game, 
  originalPrompt, 
  discussionHistory, 
  currentDiscussion, 
  isAnalyzing,
  onResponse,
  onGenerateScript,
  onReset,
  isGenerating
}) {
  const [userResponse, setUserResponse] = useState("");

  const complexityColors = {
    Simple: "bg-green-900/50 text-green-300",
    Moderate: "bg-yellow-900/50 text-yellow-300", 
    Complex: "bg-orange-900/50 text-orange-300",
    Advanced: "bg-red-900/50 text-red-300"
  };

  const handleSubmitResponse = () => {
    if (userResponse.trim()) {
      onResponse(userResponse);
      setUserResponse("");
    }
  };

  const latestFollowup = discussionHistory.find(item => item.type === 'ai_followup');
  const canGenerate = latestFollowup?.readyToGenerate || currentDiscussion?.feasible;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-yellow-200">AI Script Analysis</h2>
        <Button variant="ghost" onClick={onReset} className="text-gray-400 hover:text-white">
          <RotateCcw className="w-4 h-4 mr-2" />
          Start Over
        </Button>
      </div>

      {/* Original Request */}
      <Card className="bg-blue-900/20 border-blue-700/50">
        <CardHeader>
          <CardTitle className="text-blue-300 text-lg flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            Your Request for {game}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-300 italic">"{originalPrompt}"</p>
        </CardContent>
      </Card>

      {/* Initial Analysis */}
      {currentDiscussion && (
        <Card className="bg-gray-800/50 border-yellow-800/30">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-yellow-300 text-lg">AI Analysis</CardTitle>
              <div className="flex items-center gap-2">
                {currentDiscussion.feasible ? (
                  <Badge className="bg-green-900/50 text-green-300">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Feasible
                  </Badge>
                ) : (
                  <Badge className="bg-red-900/50 text-red-300">
                    <AlertTriangle className="w-3 h-3 mr-1" />
                    Challenging
                  </Badge>
                )}
                <Badge className={complexityColors[currentDiscussion.complexity]}>
                  {currentDiscussion.complexity}
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {currentDiscussion.limitations.length > 0 && (
              <div>
                <h4 className="flex items-center gap-2 text-orange-300 font-medium mb-2">
                  <AlertTriangle className="w-4 h-4" />
                  Limitations to Consider
                </h4>
                <ul className="text-gray-300 text-sm space-y-1">
                  {currentDiscussion.limitations.map((limitation, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-orange-400 mt-1">•</span>
                      <span>{limitation}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {currentDiscussion.suggestions.length > 0 && (
              <div>
                <h4 className="flex items-center gap-2 text-green-300 font-medium mb-2">
                  <Lightbulb className="w-4 h-4" />
                  Suggestions & Improvements
                </h4>
                <ul className="text-gray-300 text-sm space-y-1">
                  {currentDiscussion.suggestions.map((suggestion, i) => (
                        <li key={i} className="flex items-start gap-2">
                      <span className="text-green-400 mt-1">•</span>
                      <span>{suggestion}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {currentDiscussion.questions.length > 0 && (
              <div>
                <h4 className="flex items-center gap-2 text-blue-300 font-medium mb-2">
                  <HelpCircle className="w-4 h-4" />
                  Clarifying Questions
                </h4>
                <ul className="text-gray-300 text-sm space-y-1">
                  {currentDiscussion.questions.map((question, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-blue-400 mt-1">?</span>
                      <span>{question}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {currentDiscussion.considerations.length > 0 && (
              <div>
                <h4 className="flex items-center gap-2 text-purple-300 font-medium mb-2">
                  <CheckCircle className="w-4 h-4" />
                  Important Considerations
                </h4>
                <ul className="text-gray-300 text-sm space-y-1">
                  {currentDiscussion.considerations.map((consideration, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-purple-400 mt-1">•</span>
                      <span>{consideration}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Discussion History */}
      {discussionHistory.filter(item => item.type !== 'analysis').map((item, index) => (
        <Card key={index} className={item.type === 'user_response' ? "bg-blue-900/20 border-blue-700/50" : "bg-gray-800/50 border-yellow-800/30"}>
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className={`p-2 rounded-full ${item.type === 'user_response' ? 'bg-blue-700' : 'bg-yellow-700'}`}>
                {item.type === 'user_response' ? '👤' : '🤖'}
              </div>
              <div className="flex-1">
                <p className="text-gray-300">{item.content}</p>
                {item.suggestions && item.suggestions.length > 0 && (
                  <div className="mt-3">
                    <h5 className="text-green-300 text-sm font-medium mb-1">Additional Suggestions:</h5>
                    <ul className="text-sm text-gray-400">
                      {item.suggestions.map((suggestion, i) => (
                        <li key={i} className="flex items-start gap-1">
                          <span className="text-green-400">•</span>
                          <span>{suggestion}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}

      {/* Response Input */}
      <Card className="bg-gray-800/50 border-yellow-800/30">
        <CardHeader>
          <CardTitle className="text-yellow-300 text-lg">Continue the Discussion</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <Textarea
              value={userResponse}
              onChange={(e) => setUserResponse(e.target.value)}
              placeholder="Respond to the AI's analysis, ask questions, provide clarifications, or request modifications..."
              className="h-24 bg-gray-900 border-yellow-800/50 text-gray-200 pr-12" // Added pr-12 to make space for the button
            />
            <div className="absolute top-2 right-2">
              <VoiceToText 
                onTranscript={(text) => setUserResponse(text)} 
                className="bg-gray-900/80 backdrop-blur rounded"
              />
            </div>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={handleSubmitResponse}
              disabled={isAnalyzing || !userResponse.trim()}
              className="bg-yellow-700 hover:bg-yellow-600 text-black"
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  AI Responding...
                </>
              ) : (
                <>
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Send Response
                </>
              )}
            </Button>
            
            {canGenerate && (
              <Button
                onClick={onGenerateScript}
                disabled={isGenerating}
                className="bg-green-700 hover:bg-green-600"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating Scripts...
                  </>
                ) : (
                  <>
                    <Wand2 className="mr-2 h-4 w-4" />
                    Generate Script Project
                  </>
                )}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
