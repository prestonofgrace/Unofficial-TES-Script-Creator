
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";

const instructions = {
  Morrowind: {
    title: "Implementing in Morrowind Construction Set",
    steps: [
      "Copy the script code above using the Copy button",
      "Open Morrowind Construction Set and load your plugin files",
      "Go to 'Data Files' and select Morrowind.esm and any other master files",
      "Check 'Set as Active File' for your .esp plugin (or create a new one)",
      "Click the 'Script' icon in the toolbar (looks like a scroll)",
      "In the Script Editor, go to 'Script > New' to create a new script",
      "Paste the copied script code into the new script window",
      "Go to 'Script > Compile' to compile the script (fix any errors if they appear)",
      "Go to 'Script > Save' to save the compiled script",
      "Attach the script to an NPC or object:\n• For NPCs: Characters > NPC, select your NPC, choose the script in the 'Script' dropdown\n• For objects: Find the object type (Container, Door, etc.), select it, choose the script",
      "Save your plugin with 'File > Save'"
    ]
  },
  Oblivion: {
    title: "Implementing in Oblivion Construction Set",
    steps: [
      "Copy the script code above using the Copy button",
      "Open Oblivion Construction Set and set your active plugin",
      "Go to 'Gameplay > Scripts' to open the Script Editor",
      "Click 'New' to create a new script",
      "Paste the copied script code into the script window",
      "Click 'Save and Compile' (fix any compilation errors if they appear)",
      "Give your script a name when prompted",
      "Attach the script to an NPC or object:\n• For NPCs: Go to 'Actors > Actor', find/create your NPC, set the script in the 'Script' field\n• For objects: Go to the appropriate object editor, select your object, set the script",
      "Save your plugin"
    ]
  },
  Skyrim: {
    title: "Implementing in Skyrim Creation Kit",
    steps: [
      "Copy the script code above using the Copy button",
      "Open Skyrim Creation Kit and load your plugin",
      "Go to 'Gameplay > Papyrus Script Manager'",
      "Click 'New' to create a new script",
      "Paste the copied Papyrus script code",
      "Click 'Compile' to compile the script (resolve any errors)",
      "Save the script with the name specified in the 'Scriptname' line",
      "Attach the script to an object or NPC:\n• For objects: Select the object, go to 'Scripts' tab, click 'Add', select your script\n• For NPCs: In the Actor editor, go to 'Scripts' tab, add your script",
      "Set any Properties that the script requires (items, actors, etc.)",
      "Save your plugin"
    ]
  },
  TES3MP: {
    title: "Implementing in TES3MP Server",
    steps: [
      "Copy the Lua script code above using the Copy button.",
      "Access your TES3MP server files.",
      "Navigate to the 'server/data/customScripts' directory. If it doesn't exist, create it.",
      "Create a new file in this directory with the exact title of the script (e.g., 'myQuestSystem.lua').",
      "Paste the copied Lua code into this new file and save it.",
      "Navigate to 'server/data' and open the 'customScripts.lua' file.",
      "Add a new line to this file to load your script: `require(\"customScripts.myQuestSystem\")` (replace 'myQuestSystem' with your script's filename without the .lua).",
      "Save the 'customScripts.lua' file.",
      "Restart your TES3MP server for the new script to take effect.",
      "Monitor the server console for any errors upon startup."
    ]
  }
};

export default function InstructionsPanel({ game }) {
  const gameInstructions = instructions[game];

  return (
    <Card className="bg-blue-900/20 border-blue-700/50">
      <CardHeader>
        <CardTitle className="text-blue-300 flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          {gameInstructions.title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ol className="space-y-3 text-gray-300">
          {gameInstructions.steps.map((step, index) => (
            <li key={index} className="flex gap-3">
              <span className="flex-shrink-0 w-6 h-6 bg-blue-700 text-blue-100 rounded-full flex items-center justify-center text-sm font-bold">
                {index + 1}
              </span>
              <span className="leading-relaxed whitespace-pre-line">{step}</span>
            </li>
          ))}
        </ol>
      </CardContent>
    </Card>
  );
}
