import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft, ArrowRight, X } from 'lucide-react';

const jiubImage = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d0d51882c8fca653210d8f/ff0d52505_Jiub_card_art-removebg-preview.png";

// Using the new, correctly named images
const tutorialImages = {
  // Step 0: Welcome - No image
  1: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d0d51882c8fca653210d8f/1b8723436_scriptgeneratorsideui.png",      // Step 2: Script Generator
  2: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d0d51882c8fca653210d8f/f36f1cc65_Createyourscript.png",              // Step 3: Choose Your Realm
  3: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d0d51882c8fca653210d8f/646ea90fd_scriptdiscription.png",               // Step 4: Speak Your Vision
  4: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d0d51882c8fca653210d8f/79a55ebdf_startaidisscussion.png",            // Step 5: Consult the Oracle
  5: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d0d51882c8fca653210d8f/9e7c6cea9_myscriptssideui.png",                // Step 6: My Scripts
  // Step 6: Mending Spells - No image, as it's on a different page
  7: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d0d51882c8fca653210d8f/ff7b8cccb_nexussideui.png",                    // Step 8: Nexus Generator
};

// Adjusted positions for the new, focused images
const imagePositions = {
  1: { top: '105px', left: '10px' },  // Script Generator
  2: { top: '175px', left: '280px' }, // Game selector
  3: { top: '280px', left: '280px' }, // Script Description
  4: { top: '480px', left: '280px' }, // Start AI Discussion
  5: { top: '150px', left: '10px' },  // My Scripts
  7: { top: '195px', left: '10px' },  // Nexus Generator
};

const tutorialSteps = [
    {
        title: "Welcome, Traveler!",
        content: "Greetings! I am Jiub, your AI guide through the arcane arts of script creation. I've seen my share of strange things, but this contraption... it's something else. Together, we'll use it to forge powerful mods.",
    },
    {
        title: "The Script Generator",
        content: "Our journey starts here, at the 'Script Generator'. This is your workshop. Find it on the left. It's where your ideas become reality.",
    },
    {
        title: "Choose Your Realm",
        content: "First, you must choose the reality you wish to alter. Will it be the ash-choked lands of Vvardenfell, the heart of the Empire, the frozen north of Skyrim, or the shared world of TES3MP?",
    },
    {
        title: "Speak Your Vision",
        content: "Now, describe the script you envision. Use plain language. If you prefer, speak your words aloud; this device is keen enough to transcribe them. Look for the microphone.",
    },
    {
        title: "Consult the Oracle",
        content: "Once your request is clear, engage me in a discussion using this button. I will analyze your needs, offer my wisdom, and help refine your arcane request before we forge the script.",
    },
    {
        title: "Your Personal Grimoire",
        content: "All your created works are stored safely in 'My Scripts'. A treasure trove of your ingenuity, always accessible should you need to revisit them.",
    },
    {
        title: "Mending Flawed Spells",
        content: "Should a script fail to cast true, bring it here. Within 'My Scripts', you'll find the 'AI Error Analysis' tool. I can diagnose its ailments and help you mend its flaws.",
    },
    {
        title: "Spread Your Fame",
        content: "For those who wish to share their magic with the world, the 'Nexus Description Generator' will weave tales of your mods, attracting fellow adventurers to your creations.",
    },
    {
        title: "Your Journey Begins",
        content: "Our lesson is complete. The path is now clear. Go forth, outlander, and imbue the world of Tamriel with your creativity! May your mods be bug-free, traveler!",
    }
];

export default function AppTutorial({ onFinish }) {
    const [currentStep, setCurrentStep] = useState(0);

    const handleNext = () => {
        if (currentStep < tutorialSteps.length - 1) {
            setCurrentStep(currentStep + 1);
        } else {
            onFinish();
        }
    };

    const handlePrev = () => {
        if (currentStep > 0) {
            setCurrentStep(currentStep - 1);
        }
    };

    const handleSkip = () => {
        onFinish();
    };

    const stepData = tutorialSteps[currentStep];
    const currentImage = tutorialImages[currentStep];
    const imagePosition = imagePositions[currentStep];

    return (
        <div className="fixed inset-0 z-[9999]">
            {/* Semi-transparent background overlay */}
            <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
            
            {/* Highlighted image overlay for current step */}
            {currentImage && imagePosition && (
                <div 
                    className="absolute z-[10000] transition-all duration-500 ease-in-out"
                    style={{
                        top: imagePosition.top,
                        left: imagePosition.left,
                        boxShadow: '0 0 60px rgba(244, 208, 63, 0.9), 0 0 30px rgba(255, 255, 255, 0.4)',
                        border: '3px solid #f4d03f',
                        borderRadius: '12px',
                        overflow: 'hidden',
                        background: 'rgba(0,0,0,0.5)',
                    }}
                >
                    <img 
                        src={currentImage} 
                        alt={`Tutorial step ${currentStep + 1}`}
                        className="max-w-none block"
                        style={{ 
                            display: 'block',
                            maxWidth: 'none',
                            height: 'auto'
                        }}
                    />
                </div>
            )}
            
            {/* Jiub's tutorial dialog */}
            <div className="fixed bottom-4 right-4 max-w-sm z-[10001]">
                <div className="bg-black/90 backdrop-blur-md border border-yellow-700/50 rounded-xl shadow-2xl p-6 text-white">
                    {/* Close button */}
                    <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={handleSkip} 
                        className="absolute top-2 right-2 text-gray-400 hover:text-white w-8 h-8 p-0"
                    >
                        <X className="w-4 h-4" />
                    </Button>
                    
                    {/* Jiub's avatar and content */}
                    <div className="flex items-start space-x-4 mb-6">
                        <img 
                            src={jiubImage} 
                            alt="Jiub, your AI guide" 
                            className="w-16 h-16 rounded-full border-2 border-yellow-500 flex-shrink-0 object-cover" 
                        />
                        <div className="flex-1">
                            <h3 className="text-lg font-bold text-yellow-300 mb-2">{stepData.title}</h3>
                            <p className="text-gray-200 text-sm leading-relaxed">{stepData.content}</p>
                        </div>
                    </div>
                    
                    {/* Navigation buttons */}
                    <div className="flex items-center justify-between">
                        <span className="text-xs text-purple-300">
                            Step {currentStep + 1} of {tutorialSteps.length}
                        </span>
                        <div className="flex gap-2">
                            {currentStep > 0 && (
                                <Button 
                                    variant="outline" 
                                    size="sm" 
                                    onClick={handlePrev} 
                                    className="border-purple-600 text-purple-300 hover:bg-purple-900/50"
                                >
                                    <ArrowLeft className="w-4 h-4" />
                                </Button>
                            )}
                            <Button 
                                onClick={handleNext} 
                                size="sm" 
                                className="bg-yellow-700 hover:bg-yellow-600 text-black font-bold"
                            >
                                {currentStep === tutorialSteps.length - 1 ? 'Start Modding!' : 'Next'}
                                {currentStep < tutorialSteps.length - 1 && <ArrowRight className="w-4 h-4 ml-1" />}
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}