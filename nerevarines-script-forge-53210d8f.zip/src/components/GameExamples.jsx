import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const examples = {
  Morrowind: [
    "Create a simple greeting script for an NPC named 'Fargoth'. When the player talks to him, he should say 'Hello, outlander.'",
    "An NPC named 'Caius Cosades' should give the player 200 gold the first time they talk to him.",
    "A chest that requires a key named 'skeleton_key_unique' to open. Show a message if locked.",
    "Create a complete quest system: An NPC gives the player a task to retrieve an ancient artifact from a dungeon, and rewards them with a unique spell when they return with it. Include journal entries and multiple NPCs.",
    "A magical training system where an NPC trainer teaches spells, but only if the player brings specific reagents and has enough gold. Include scripts for the trainer, the spell learning process, and reagent validation."
  ],
  Oblivion: [
    "Create a script for an NPC merchant who gives a 10% discount if the player's Speech skill is over 75.",
    "A magic door that only opens if the player has learned at least 5 spells.",
    "An enchanted weapon that increases in damage as the player's level increases.",
    "Design a complete faction recruitment system: Multiple NPCs can recruit the player into a guild, track their progress through ranks, and give rank-specific equipment and abilities.",
    "Create a dynamic bounty hunter system where NPCs will hunt the player if their bounty is high, with multiple hunter types and escalating difficulty based on crime level."
  ],
  Skyrim: [
    "Create a chest that refills with random potions every 24 in-game hours.",
    "An NPC trainer who teaches spells but only if the player brings specific ingredients.",
    "A magical altar that increases the player's magicka by 50 when activated, with a cooldown.",
    "Build a complete player home system: A purchasable house with upgradeable rooms, storage containers, and NPC servants. Include purchase script, upgrade management, and servant AI.",
    "Design a dynamic weather-based magic system where spells become more powerful during certain weather conditions, with visual effects and NPC reactions to the enhanced magic."
  ],
  TES3MP: [
    "A command '/givegold 100' that gives the player 100 gold and sends them a confirmation message.",
    "A script that gives every new player who logs in for the first time a basic set of iron armor.",
    "A public chest in Balmora that all players can use, with its contents saving automatically.",
    "A server-wide announcement system. An admin can type '/announce This is a message' and it will be broadcast to all online players.",
    "A bounty system where killing a player adds a bounty to the attacker. Other players can kill the wanted person to claim the bounty. Store bounties in a server-side JSON file."
  ],
  OpenMW: [
    "Create a Lua script that adds a new spell effect when the player drinks a sujamma potion.",
    "A script that automatically saves the game every 10 minutes and displays a notification message.",
    "Create a custom UI window that shows the player's current coordinates and cell name.",
    "A script that makes torches burn out after a realistic amount of time and need to be relit.",
    "Build a advanced weather system that affects NPC behavior - NPCs seek shelter during rain and dress warmer in cold weather."
  ],
  MWSE: [
    "Create an MCM (Mod Configuration Menu) for a mod that lets players adjust spell costs and durations.",
    "A script that adds realistic physics to thrown objects using MWSE's enhanced capabilities.",
    "Create a training system where NPCs can teach players new combat techniques with custom animations.",
    "Build a dynamic economy system where item prices fluctuate based on supply, demand, and local events.",
    "A script that adds a detailed spellcrafting interface with preview effects and ingredient requirements."
  ]
};

export default function GameExamples({ selectedGame, onExampleSelect }) {
  return (
    <Card className="bg-transparent border-none">
      <CardHeader>
        <CardTitle className="text-yellow-300 text-xl">
          Try these {selectedGame} examples:
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {examples[selectedGame].map((example, i) => (
            <button
              key={i}
              onClick={() => onExampleSelect(example)}
              className="p-4 bg-gray-800/70 rounded-lg border border-yellow-800/30 text-left hover:bg-gray-700/90 transition-colors"
            >
              <p className="text-sm text-gray-300">{example}</p>
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}