import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clipboard, Code, FileText, Gamepad2, ChevronDown, ChevronUp } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

const gameIcons = {
  Morrowind: <FileText className="w-4 h-4" />,
  Oblivion: <Gamepad2 className="w-4 h-4" />,
  Skyrim: <Code className="w-4 h-4" />
};

const gameColors = {
  Morrowind: "bg-red-900/50 text-red-300 border-red-700",
  Oblivion: "bg-blue-900/50 text-blue-300 border-blue-700",
  Skyrim: "bg-purple-900/50 text-purple-300 border-purple-700"
};

const categoryColors = {
  NPC: "bg-green-900/50 text-green-300",
  Object: "bg-orange-900/50 text-orange-300",
  Quest: "bg-yellow-900/50 text-yellow-300",
  Utility: "bg-cyan-900/50 text-cyan-300",
  Combat: "bg-red-900/50 text-red-300",
  Magic: "bg-purple-900/50 text-purple-300",
  Other: "bg-gray-900/50 text-gray-300"
};

export default function ScriptProjectOutput({ project }) {
  const [expandedScripts, setExpandedScripts] = useState(new Set([0])); // First script expanded by default
  const [copiedStates, setCopiedStates] = useState({});

  const handleCopy = (scriptIndex, content) => {
    navigator.clipboard.writeText(content);
    setCopiedStates(prev => ({ ...prev, [scriptIndex]: true }));
    setTimeout(() => {
      setCopiedStates(prev => ({ ...prev, [scriptIndex]: false }));
    }, 2000);
  };

  const toggleScript = (index) => {
    setExpandedScripts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(index)) {
        newSet.delete(index);
      } else {
        newSet.add(index);
      }
      return newSet;
    });
  };

  return (
    <div className="space-y-6">
      {/* Project Header */}
      <Card className="bg-gradient-to-r from-yellow-900/20 to-orange-900/20 border-yellow-800/50">
        <CardHeader>
          <CardTitle className="text-yellow-200 text-2xl">{project.projectName}</CardTitle>
          <p className="text-gray-300 text-lg">{project.projectDescription}</p>
          <Badge className="self-start bg-blue-900/50 text-blue-300">
            {project.scripts.length} Script{project.scripts.length !== 1 ? 's' : ''}
          </Badge>
        </CardHeader>
      </Card>

      {/* Individual Scripts */}
      <div className="space-y-4">
        {project.scripts.map((script, index) => (
          <Card key={index} className="bg-gray-800/50 border-yellow-800/30">
            <Collapsible
              open={expandedScripts.has(index)}
              onOpenChange={() => toggleScript(index)}
            >
              <CollapsibleTrigger asChild>
                <CardHeader className="cursor-pointer hover:bg-gray-700/30 transition-colors">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-yellow-300 text-xl flex items-center gap-2">
                        {script.title}
                        {expandedScripts.has(index) ? (
                          <ChevronUp className="w-5 h-5 text-gray-400" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-gray-400" />
                        )}
                      </CardTitle>
                      <p className="text-gray-300 mt-2">{script.description}</p>
                      <div className="flex gap-2 mt-3">
                        <Badge className={`${categoryColors[script.category]} border-0`}>
                          {script.category}
                        </Badge>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCopy(index, script.scriptCode);
                      }}
                      className="text-gray-400 hover:text-white"
                    >
                      <Clipboard className="w-4 h-4 mr-2" />
                      {copiedStates[index] ? "Copied!" : "Copy Code"}
                    </Button>
                  </div>
                </CardHeader>
              </CollapsibleTrigger>

              <CollapsibleContent>
                <CardContent className="space-y-4">
                  {/* Script Code */}
                  <div>
                    <h4 className="text-green-300 font-medium mb-2">Script Code:</h4>
                    <pre className="bg-black/50 p-4 rounded-md overflow-x-auto text-sm text-green-300 whitespace-pre-wrap border border-gray-700">
                      <code>{script.scriptCode}</code>
                    </pre>
                  </div>

                  {/* Implementation Instructions */}
                  <div>
                    <h4 className="text-blue-300 font-medium mb-2">Implementation Instructions:</h4>
                    <div className="bg-blue-900/20 p-4 rounded-md border border-blue-700/50">
                      <div className="text-blue-200 text-sm whitespace-pre-line">
                        {script.implementationNotes}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </CollapsibleContent>
            </Collapsible>
          </Card>
        ))}
      </div>
    </div>
  );
}