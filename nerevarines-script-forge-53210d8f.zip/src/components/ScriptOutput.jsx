
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clipboard, Code, FileText, Gamepad2, Globe } from "lucide-react";

const gameIcons = {
  Morrowind: <FileText className="w-4 h-4" />,
  Oblivion: <Gamepad2 className="w-4 h-4" />,
  Skyrim: <Code className="w-4 h-4" />,
  TES3MP: <Globe className="w-4 h-4" />
};

const gameColors = {
  Morrowind: "bg-red-900/50 text-red-300 border-red-700",
  Oblivion: "bg-blue-900/50 text-blue-300 border-blue-700",
  Skyrim: "bg-purple-900/50 text-purple-300 border-purple-700",
  TES3MP: "bg-teal-900/50 text-teal-300 border-teal-700"
};

const categoryColors = {
  NPC: "bg-green-900/50 text-green-300",
  Object: "bg-orange-900/50 text-orange-300",
  Quest: "bg-yellow-900/50 text-yellow-300",
  Utility: "bg-cyan-900/50 text-cyan-300",
  Combat: "bg-red-900/50 text-red-300",
  Magic: "bg-purple-900/50 text-purple-300",
  Other: "bg-gray-900/50 text-gray-300"
};

export default function ScriptOutput({ script, showEditButton = false, onEdit = null }) {
  const [isCopied, setIsCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(script.scriptCode);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <Card className="bg-stone-900/50 border-yellow-800/30">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-yellow-300 text-xl mb-2">
              {script.title}
            </CardTitle>
            <p className="text-gray-300 mb-3">{script.description}</p>
            <div className="flex gap-2 flex-wrap">
              <Badge className={`${gameColors[script.game]} border`}>
                {gameIcons[script.game]}
                <span className="ml-1">{script.game}</span>
              </Badge>
              <Badge className={`${categoryColors[script.category]} border-0`}>
                {script.category}
              </Badge>
            </div>
          </div>
          <div className="flex gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleCopy}
              className="text-gray-400 hover:text-white"
            >
              <Clipboard className="w-4 h-4 mr-2" />
              {isCopied ? "Copied!" : "Copy Code"}
            </Button>
            {showEditButton && onEdit && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onEdit}
                className="text-yellow-400 hover:text-yellow-300"
              >
                Edit Script
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <pre className="bg-black/50 p-4 rounded-md overflow-x-auto text-sm text-green-300 whitespace-pre-wrap border border-gray-700">
          <code>{script.scriptCode}</code>
        </pre>
      </CardContent>
    </Card>
  );
}
