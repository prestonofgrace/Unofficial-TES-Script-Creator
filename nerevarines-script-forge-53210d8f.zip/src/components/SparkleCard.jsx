import React from "react";
import { Card } from "@/components/ui/card";

export default function SparkleCard({ children, className, ...props }) {
  return (
    <Card className={`magical-card ${className || ''}`} {...props}>
      <div className="card-sparkle-1"></div>
      <div className="card-sparkle-2"></div>
      <div className="card-sparkle-3"></div>
      <div className="card-sparkle-4"></div>
      {children}
    </Card>
  );
}