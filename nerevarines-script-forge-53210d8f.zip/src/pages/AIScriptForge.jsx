
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { AIScriptSession } from "@/api/entities";
import { LearningFile } from "@/api/entities";
import { ScriptFix } from "@/api/entities";
import { User } from "@/api/entities";
import { GameScript } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Wand2, 
  Loader2, 
  AlertCircle, 
  Plus, 
  MessageSquare, 
  Save, 
  RotateCcw, 
  Archive,
  TestTube2,
  Send,
  History,
  Code2,
  Copy,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  FileCode2
} from "lucide-react";
import { createPageUrl } from "@/utils";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

const categoryColors = {
  NPC: "bg-green-900/50 text-green-300",
  Object: "bg-orange-900/50 text-orange-300",
  Quest: "bg-yellow-900/50 text-yellow-300",
  Utility: "bg-cyan-900/50 text-cyan-300",
  Combat: "bg-red-900/50 text-red-300",
  Magic: "bg-purple-900/50 text-purple-300",
  Other: "bg-gray-900/50 text-gray-300"
};

export default function AIScriptForgePage() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);
  const [sessions, setSessions] = useState([]);
  const [activeSession, setActiveSession] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  // New session creation
  const [showNewSessionForm, setShowNewSessionForm] = useState(false);
  const [newSessionName, setNewSessionName] = useState("");
  const [newSessionGame, setNewSessionGame] = useState("Morrowind");
  const [newSessionPrompt, setNewSessionPrompt] = useState("");

  // Active session interaction
  const [challengeInput, setChallengeInput] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [copiedStates, setCopiedStates] = useState({});
  const [expandedScripts, setExpandedScripts] = useState(new Set());

  useEffect(() => {
    const loadUserAndSessions = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);

        // Check if user has admin access
        if (user.role !== 'admin') {
          setError("Access Denied: AI Script Forge is only available to administrators.");
          setIsLoading(false);
          return;
        }

        // Load user's sessions
        const userSessions = await AIScriptSession.filter({ created_by: user.email }, '-created_date');
        setSessions(userSessions);
      } catch (error) {
        console.error("Error loading user or sessions:", error);
        setError("Error loading sessions. Please try again.");
      } finally {
        setIsLoading(false);
      }
    };

    loadUserAndSessions();
  }, []);

  useEffect(() => {
    // When active session changes, expand the first script by default
    if (activeSession?.scripts?.length > 0) {
      setExpandedScripts(new Set([0]));
    } else {
      setExpandedScripts(new Set());
    }
  }, [activeSession]);

  const handleCreateSession = async () => {
    if (!newSessionName.trim() || !newSessionPrompt.trim()) {
      setError("Please provide both a session name and initial challenge.");
      return;
    }

    setIsProcessing(true);
    try {
      const sessionData = {
        sessionName: newSessionName.trim(),
        game: newSessionGame,
        initialPrompt: newSessionPrompt.trim(),
        currentProjectName: `${newSessionName.trim()} Project`,
        currentProjectDescription: "A new script project initiated in the AI Script Forge.",
        scripts: [],
        conversationHistory: [],
        status: "active",
        iterationCount: 0
      };

      const newSession = await AIScriptSession.create(sessionData);
      
      // Add to local state
      setSessions(prev => [newSession, ...prev]);
      setActiveSession(newSession);
      
      // Reset form
      setNewSessionName("");
      setNewSessionPrompt("");
      setShowNewSessionForm(false);
      
      // Start the first AI interaction
      await processFirstChallenge(newSession);
      
      setSuccess("New AI Script Forge session created!");
      setTimeout(() => setSuccess(null), 3000);
    } catch (error) {
      console.error("Error creating session:", error);
      setError("Failed to create session. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const processFirstChallenge = async (session) => {
    setIsProcessing(true);
    try {
      await processAIChallenge(session.initialPrompt, session);
    } catch (error) {
      console.error("Error processing first challenge:", error);
      setError("Created session, but failed to get initial AI response. You can continue manually.");
    } finally {
      setIsProcessing(false);
    }
  };

  const processAIChallenge = async (challenge, sessionToUpdate = null) => {
    const session = sessionToUpdate || activeSession;
    if (!session) return;

    setIsProcessing(true);
    setError(null);

    try {
      // Fetch learning context for the game
      const allLearningFiles = await LearningFile.list('-created_date', 50);
      const gameSpecificFiles = allLearningFiles.filter(file => 
        file.game === session.game || file.game === 'Other'
      );

      // Get validated fixes for this game
      const previousFixes = await ScriptFix.list('-created_date', 25);
      const gameFixes = previousFixes.filter(fix => 
        fix.game === session.game && fix.userValidated
      );

      const learningContext = gameSpecificFiles.length > 0 ? `
      LEARNING LIBRARY ACCESS:
      You have access to ${gameSpecificFiles.length} verified reference files for ${session.game}.
      Study these files as authoritative examples of correct syntax and patterns.
      Filenames: ${gameSpecificFiles.map(f => f.fileName).join(', ')}
      ` : '';

      const fixesContext = gameFixes.length > 0 ? `
      VALIDATED FIXES DATABASE:
      Learn from these verified solutions to common ${session.game} scripting issues:
      ${gameFixes.slice(0, 5).map((fix, i) => `
      Fix ${i + 1}: ${fix.problemType} - ${fix.errorPattern}
      Solution: ${fix.solution}
      `).join('\n')}
      ` : '';

      const conversationContext = session.conversationHistory.length > 0 ? `
      CONVERSATION HISTORY:
      ${session.conversationHistory.map((entry, i) => {
        if (entry.type === 'user_challenge') return `User Challenge ${i + 1}: ${entry.content}`;
        // For AI response, include the explanation, but not the full project data to avoid token overflow
        if (entry.type === 'ai_response') return `AI Response ${i + 1} (Project: ${entry.project.projectName}, ${entry.project.scripts.length} scripts): ${entry.content}`;
        return '';
      }).join('\n')}
      ` : '';

      const currentProjectContext = session.scripts && session.scripts.length > 0 ? `
      CURRENT PROJECT BEING DEVELOPED:
      Project Name: ${session.currentProjectName}
      Project Description: ${session.currentProjectDescription}
      
      Current Scripts (${session.scripts.length} total):
      ${session.scripts.map((script, i) => `--- Script ${i + 1}: ${script.title} ---
Description: ${script.description}
Category: ${script.category}
Code:
${script.scriptCode}
---`).join('\n\n')}
      ` : 'This is a new project. No scripts have been generated yet.';

      const forgePrompt = `You are in the AI Script Forge - a specialized development environment for creating perfect, multi-script ${session.game} projects. This is an iterative testing ground where accuracy is paramount.

      FORGE MISSION: Generate syntactically perfect, compilation-ready ${session.game} script projects.

      CRITICAL REQUIREMENTS:
      1. ABSOLUTE SYNTAX ACCURACY: Every function name, parameter, and structure MUST be correct.
      2. PROJECT-WIDE CONTEXT: You are working on a whole project, not just one script. Scripts may need to interact. Maintain consistency across the entire project.
      3. LEARNING LIBRARY ADHERENCE: Use the provided reference files as your authoritative guide.
      4. ITERATION AWARENESS: Learn from the developer's challenges and improve the entire project continuously.
      5. DETAILED EXPLANATIONS: Explain your project-wide changes and reasoning.

      ${learningContext}
      ${fixesContext}
      ${conversationContext}
      ${currentProjectContext}

      DEVELOPER CHALLENGE: "${challenge}"

      Your task is to respond to the developer's challenge by updating the script project. You can add, remove, or modify scripts as needed.

      Respond with a JSON object containing:
      - "explanation": Your detailed explanation of what you're doing and why, considering the whole project.
      - "project": An object containing the FULL, UPDATED script project:
        - "projectName": Updated name for the entire project.
        - "projectDescription": Updated high-level description of the project.
        - "scripts": An array of ALL script objects for the project. Each object must have:
          - "title": A descriptive name for the script (e.g., 'MyQuestNPC.psc' or 'mySystem.lua').
          - "description": A 1-sentence explanation of this script's role.
          - "scriptCode": The complete, perfect ${session.game} script code.
          - "category": One of: NPC, Object, Quest, Utility, Combat, Magic, Other.
          - "implementationNotes": A single string containing a bulleted list of instructions for THIS SPECIFIC SCRIPT. Use newline characters for each bullet point.
      - "changes": Array of strings describing specific changes made across the project.
      - "confidenceLevel": Number 1-10 of how confident you are that this entire project will compile and work correctly.
      - "questions": Any clarifying questions you have for the developer.`;

      const supportedFileTypes = ['png', 'jpeg', 'jpg', 'gif', 'webp', 'txt', 'md', 'pdf', 'json', 'html', 'xml'];
      const analyzableFiles = gameSpecificFiles.filter(file => 
        file.fileType && supportedFileTypes.includes(file.fileType.toLowerCase())
      );
      const fileUrls = analyzableFiles.map(file => file.fileUrl);

      const requestData = {
        prompt: forgePrompt,
        response_json_schema: {
          type: "object",
          properties: {
            explanation: { type: "string" },
            project: {
              type: "object",
              properties: {
                projectName: { type: "string" },
                projectDescription: { type: "string" },
                scripts: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      title: { type: "string" },
                      description: { type: "string" },
                      scriptCode: { type: "string" },
                      category: { type: "string" },
                      implementationNotes: { type: "string" }
                    },
                    required: ["title", "description", "scriptCode", "category", "implementationNotes"]
                  }
                }
              },
              required: ["projectName", "projectDescription", "scripts"]
            },
            changes: { type: "array", items: { type: "string" } },
            confidenceLevel: { type: "number" },
            questions: { type: "array", items: { type: "string" } }
          },
          required: ["explanation", "project", "changes", "confidenceLevel"]
        }
      };

      if (fileUrls.length > 0) {
        requestData.file_urls = fileUrls;
      }

      const aiResponse = await InvokeLLM(requestData);

      // COMPREHENSIVE VALIDATION - Check every level of the expected structure
      if (!aiResponse) {
        throw new Error("AI returned no response. Please try again.");
      }

      if (typeof aiResponse !== 'object') {
        throw new Error("AI returned invalid response format. Expected an object.");
      }

      if (!aiResponse.project) {
        throw new Error("AI response missing 'project' field. Please try the challenge again.");
      }

      if (typeof aiResponse.project !== 'object') {
        throw new Error("AI response 'project' field is not an object. Please try again.");
      }

      if (!aiResponse.project.projectName || typeof aiResponse.project.projectName !== 'string') {
        throw new Error("AI response missing or invalid 'projectName'. Please try again.");
      }

      if (!aiResponse.project.projectDescription || typeof aiResponse.project.projectDescription !== 'string') {
        throw new Error("AI response missing or invalid 'projectDescription'. Please try again.");
      }

      if (!Array.isArray(aiResponse.project.scripts)) {
        throw new Error("AI response 'scripts' field is not an array. Please try again.");
      }

      if (aiResponse.project.scripts.length === 0) {
        throw new Error("AI returned no scripts in the project. Please try again with a more specific request.");
      }

      // Validate each script object
      for (let i = 0; i < aiResponse.project.scripts.length; i++) {
        const script = aiResponse.project.scripts[i];
        if (!script || typeof script !== 'object') {
          throw new Error(`Script ${i + 1} is not a valid object. Please try again.`);
        }
        if (!script.title || typeof script.title !== 'string') {
          throw new Error(`Script ${i + 1} missing or invalid title. Please try again.`);
        }
        if (!script.scriptCode || typeof script.scriptCode !== 'string') {
          throw new Error(`Script ${i + 1} missing or invalid code. Please try again.`);
        }
        if (!script.category || typeof script.category !== 'string') {
          throw new Error(`Script ${i + 1} missing or invalid category. Please try again.`);
        }
      }
      // If we made it here, the response structure is valid - proceed with sanitization

      // --- FIX STARTS HERE: Sanitize implementationNotes ---
      // This ensures that if the AI returns an array for implementationNotes, we convert it to a valid string before saving.
      if (aiResponse.project && Array.isArray(aiResponse.project.scripts)) {
        aiResponse.project.scripts.forEach(script => {
          if (script && Array.isArray(script.implementationNotes)) {
            // Convert the array of notes into a single string with bullet points.
            script.implementationNotes = script.implementationNotes.map(note => `• ${note}`).join('\n');
          }
          // Ensure implementationNotes is always a string. If it's null, undefined, or some other non-string type,
          // convert it to an empty string to prevent rendering errors.
          if (script && typeof script.implementationNotes !== 'string') {
            script.implementationNotes = String(script.implementationNotes || '');
          }
        });
      }
      // --- FIX ENDS HERE ---

      // Update session with new, sanitized data
      const updatedHistory = [
        ...session.conversationHistory,
        {
          type: 'user_challenge',
          content: challenge,
          timestamp: Date.now()
        },
        {
          type: 'ai_response',
          content: aiResponse.explanation,
          project: aiResponse.project, // This now contains the sanitized data
          changes: aiResponse.changes,
          confidenceLevel: aiResponse.confidenceLevel,
          questions: aiResponse.questions || [],
          timestamp: Date.now()
        }
      ];

      const updatedSession = {
        ...session,
        currentProjectName: aiResponse.project.projectName,
        currentProjectDescription: aiResponse.project.projectDescription,
        scripts: aiResponse.project.scripts, // This now contains the sanitized data
        conversationHistory: updatedHistory,
        iterationCount: session.iterationCount + 1
      };

      await AIScriptSession.update(session.id, updatedSession);
      
      // Update local state
      if (sessionToUpdate) {
        setActiveSession(updatedSession);
      } else {
        setActiveSession(updatedSession);
        setSessions(prev => prev.map(s => s.id === session.id ? updatedSession : s));
      }

      setChallengeInput("");

    } catch (error) {
      console.error("AI processing error:", error);
      if (error.message && error.message.includes('Unsupported file type')) {
        setError("File processing error. The AI will work with available context. Try your challenge again.");
      } else {
        // Updated to provide a more descriptive error message to the user.
        setError(error.message || "Failed to process AI challenge. Please try again.");
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSendChallenge = async () => {
    if (!challengeInput.trim() || !activeSession) return;
    await processAIChallenge(challengeInput.trim());
  };

  const handleCopyScript = (scriptIndex, scriptCode) => {
    if (scriptCode) {
      navigator.clipboard.writeText(scriptCode);
      setCopiedStates(prev => ({ ...prev, [scriptIndex]: true }));
      setTimeout(() => setCopiedStates(prev => ({ ...prev, [scriptIndex]: false })), 2000);
    }
  };

  const handleSaveToMyScripts = async () => {
    if (!activeSession?.scripts || activeSession.scripts.length === 0) return;
    
    setIsSaving(true);
    try {
      const scriptsToSave = activeSession.scripts.map(script => ({
        game: activeSession.game,
        title: script.title,
        description: script.description,
        scriptCode: script.scriptCode,
        category: script.category,
        implementationNotes: script.implementationNotes,
        originalPrompt: `[AI Script Forge Project: ${activeSession.sessionName}] Initial Challenge: ${activeSession.initialPrompt}`,
        projectName: activeSession.currentProjectName,
        projectDescription: activeSession.currentProjectDescription
      }));

      // Assuming GameScript.bulkCreate is available and handles an array of script data
      await GameScript.bulkCreate(scriptsToSave);
      setSuccess(`Project "${activeSession.currentProjectName}" with ${scriptsToSave.length} script(s) saved successfully!`);
      setTimeout(() => setSuccess(null), 4000);
    } catch (error) {
      console.error("Save error:", error);
      setError("Failed to save script(s). Please try again.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleArchiveSession = async (sessionId) => {
    try {
      await AIScriptSession.update(sessionId, { status: 'archived' });
      setSessions(prev => prev.map(s => s.id === sessionId ? { ...s, status: 'archived' } : s));
      if (activeSession?.id === sessionId) {
        setActiveSession(null);
      }
      setSuccess("Session archived successfully!");
      setTimeout(() => setSuccess(null), 3000);
    } catch (error) {
      setError("Failed to archive session.");
    }
  };

  const getLatestAIResponse = () => {
    if (!activeSession?.conversationHistory.length) return null;
    const aiResponses = activeSession.conversationHistory.filter(entry => entry.type === 'ai_response');
    return aiResponses[aiResponses.length - 1];
  };

  const toggleScript = (index) => {
    setExpandedScripts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(index)) {
        newSet.delete(index);
      } else {
        newSet.add(index);
      }
      return newSet;
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-300"></div>
      </div>
    );
  }

  if (error && !currentUser) {
    return (
      <div className="text-center py-12">
        <Alert variant="destructive" className="max-w-md mx-auto">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
        <Button 
          onClick={() => navigate(createPageUrl("Home"))} 
          className="mt-4"
        >
          Back to Home
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-yellow-200 mb-2 flex items-center justify-center gap-3">
          <TestTube2 className="w-8 h-8 text-purple-400" />
          AI Script Forge
        </h1>
        <p className="text-gray-400">Dedicated Testing Environment for Perfect Script Project Development</p>
        <Badge className="mt-2 bg-purple-900/50 text-purple-300">Administrator Only</Badge>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="border-green-600 bg-green-900/20">
          <CheckCircle2 className="h-4 w-4 text-green-400" />
          <AlertDescription className="text-green-300">{success}</AlertDescription>
        </Alert>
      )}

      {/* Session Management */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sessions List */}
        <Card className="lg:col-span-1 bg-gray-800/50 border-purple-800/30">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-purple-300 flex items-center gap-2">
                <History className="w-5 h-5" />
                Forge Sessions
              </CardTitle>
              <Button
                size="sm"
                onClick={() => setShowNewSessionForm(true)}
                className="bg-purple-700 hover:bg-purple-600"
              >
                <Plus className="w-4 h-4 mr-2" />
                New Session
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-80">
              <div className="space-y-2">
                {sessions.filter(s => s.status === 'active').map(session => (
                  <Card 
                    key={session.id}
                    className={`cursor-pointer transition-colors ${
                      activeSession?.id === session.id 
                        ? 'bg-purple-900/30 border-purple-600' 
                        : 'bg-gray-900/30 border-gray-600 hover:bg-gray-800/50'
                    }`}
                    onClick={() => setActiveSession(session)}
                  >
                    <CardContent className="p-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-medium text-gray-200 text-sm">{session.sessionName}</h4>
                          <Badge className="mt-1 text-xs">{session.game}</Badge>
                          <p className="text-xs text-gray-400 mt-1">
                            {session.iterationCount} iterations - {session.scripts?.length || 0} scripts
                          </p>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleArchiveSession(session.id);
                          }}
                          className="text-gray-400 hover:text-red-400"
                        >
                          <Archive className="w-3 h-3" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Main Forge Area */}
        <div className="lg:col-span-2 space-y-6">
          {/* New Session Form */}
          {showNewSessionForm && (
            <Card className="bg-purple-900/20 border-purple-700/50">
              <CardHeader>
                <CardTitle className="text-purple-300">Create New Forge Session</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input
                  placeholder="Session name (e.g., 'Morrowind Guard AI Fix Project')"
                  value={newSessionName}
                  onChange={(e) => setNewSessionName(e.target.value)}
                  className="bg-gray-900 border-purple-800/50"
                />
                <Select value={newSessionGame} onValueChange={setNewSessionGame}>
                  <SelectTrigger className="bg-gray-900 border-purple-800/50">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Morrowind">Morrowind</SelectItem>
                    <SelectItem value="Oblivion">Oblivion</SelectItem>
                    <SelectItem value="Skyrim">Skyrim</SelectItem>
                    <SelectItem value="TES3MP">TES3MP</SelectItem>
                    <SelectItem value="OpenMW">OpenMW</SelectItem>
                    <SelectItem value="MWSE">MWSE</SelectItem>
                  </SelectContent>
                </Select>
                <Textarea
                  placeholder="Initial challenge for the AI (e.g., 'Create a simple NPC greeting project that compiles, with separate scripts for the NPC and dialogue.')"
                  value={newSessionPrompt}
                  onChange={(e) => setNewSessionPrompt(e.target.value)}
                  className="h-24 bg-gray-900 border-purple-800/50"
                />
                <div className="flex gap-3">
                  <Button
                    onClick={handleCreateSession}
                    disabled={isProcessing}
                    className="bg-purple-700 hover:bg-purple-600"
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Creating & Processing...
                      </>
                    ) : (
                      <>
                        <Wand2 className="w-4 h-4 mr-2" />
                        Start Forge Session
                      </>
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowNewSessionForm(false);
                      setNewSessionName("");
                      setNewSessionPrompt("");
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Active Session Display */}
          {activeSession && (
            <>
              {/* Current Project Display */}
              <Card className="bg-gray-800/50 border-yellow-800/30">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-yellow-300 flex items-center gap-2">
                        <FileCode2 className="w-5 h-5" />
                        {activeSession.currentProjectName}
                      </CardTitle>
                      <p className="text-gray-300 text-sm mt-1">{activeSession.currentProjectDescription}</p>
                      <div className="flex gap-2 mt-2 flex-wrap">
                        <Badge>{activeSession.game}</Badge>
                        <Badge variant="outline">Iteration {activeSession.iterationCount}</Badge>
                        <Badge variant="outline">{activeSession.scripts?.length || 0} Script(s)</Badge>
                        {(() => {
                          const latestResponse = getLatestAIResponse();
                          if (latestResponse?.confidenceLevel) {
                            return (
                              <Badge className={
                                latestResponse.confidenceLevel >= 8 
                                  ? "bg-green-900/50 text-green-300"
                                  : latestResponse.confidenceLevel >= 6
                                  ? "bg-yellow-900/50 text-yellow-300"
                                  : "bg-red-900/50 text-red-300"
                              }>
                                AI Confidence: {latestResponse.confidenceLevel}/10
                              </Badge>
                            );
                          }
                          return null;
                        })()}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={handleSaveToMyScripts}
                        disabled={isSaving || !activeSession.scripts || activeSession.scripts.length === 0}
                        className="bg-green-700 hover:bg-green-600"
                      >
                        {isSaving ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          <>
                            <Save className="w-4 h-4 mr-2" />
                            Save Project
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {activeSession.scripts && activeSession.scripts.length > 0 ? (
                    <div className="space-y-3">
                      {activeSession.scripts.map((script, index) => (
                        <Collapsible 
                          key={index}
                          open={expandedScripts.has(index)}
                          onOpenChange={() => toggleScript(index)}
                          className="border border-gray-700 rounded-lg"
                        >
                          <CollapsibleTrigger asChild>
                            <div className="flex items-center justify-between p-3 bg-gray-900/40 hover:bg-gray-900/60 rounded-lg cursor-pointer">
                                <div className="flex items-center gap-3">
                                  {expandedScripts.has(index) ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
                                  <h4 className="font-medium text-gray-200">{script.title}</h4>
                                  <Badge className={`${categoryColors[script.category] || categoryColors['Other']} border-0`}>
                                    {script.category}
                                  </Badge>
                                </div>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={(e) => {
                                      e.stopPropagation(); // Prevent collapsible from toggling
                                      handleCopyScript(index, script.scriptCode);
                                  }}
                                  className="text-gray-400 hover:text-white"
                                >
                                  <Copy className="w-4 h-4 mr-2" />
                                  {copiedStates[index] ? "Copied!" : "Copy Code"}
                                </Button>
                            </div>
                          </CollapsibleTrigger>
                          <CollapsibleContent className="p-4 bg-black/30 rounded-b-lg">
                              <pre className="bg-transparent overflow-x-auto text-sm text-green-300 whitespace-pre-wrap">
                                <code>{script.scriptCode}</code>
                              </pre>
                              {script.implementationNotes && (
                                <div className="mt-4 border-t border-gray-700 pt-3">
                                  <h5 className="text-blue-300 font-medium mb-1 text-xs">Implementation Notes:</h5>
                                  {/* Using a div and whitespace-pre-line to respect bullet points/line breaks from LLM */}
                                  <div className="text-blue-200 text-xs whitespace-pre-line">
                                    {script.implementationNotes}
                                  </div>
                                </div>
                              )}
                          </CollapsibleContent>
                        </Collapsible>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-400">
                      <FileCode2 className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>No scripts generated for this project yet. Send your first challenge!</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Challenge Input */}
              <Card className="bg-gray-800/50 border-purple-800/30">
                <CardHeader>
                  <CardTitle className="text-purple-300 flex items-center gap-2">
                    <MessageSquare className="w-5 h-5" />
                    Challenge the AI
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    value={challengeInput}
                    onChange={(e) => setChallengeInput(e.target.value)}
                    placeholder="Challenge the AI (e.g., 'This GetGlobal syntax is wrong, fix it across all scripts using the MWS.txt reference', 'Add error handling to MyNPC.psc', 'Make the dialogue more efficient', 'Add a new quest script.')"
                    className="h-24 bg-gray-900 border-purple-800/50 text-gray-200"
                  />
                  <Button
                    onClick={handleSendChallenge}
                    disabled={isProcessing || !challengeInput.trim()}
                    className="bg-purple-700 hover:bg-purple-600 w-full"
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        AI Processing Challenge...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Send Challenge to AI
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Conversation History */}
              {activeSession.conversationHistory.length > 0 && (
                <Card className="bg-gray-800/50 border-gray-700/30">
                  <CardHeader>
                    <CardTitle className="text-gray-300 flex items-center gap-2">
                      <History className="w-5 h-5" />
                      Forge History
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-96">
                      <div className="space-y-4">
                        {activeSession.conversationHistory.map((entry, index) => (
                          <div key={index} className={`p-4 rounded-lg border ${
                            entry.type === 'user_challenge' 
                              ? 'bg-blue-900/20 border-blue-700/50' 
                              : 'bg-gray-900/30 border-gray-600/50'
                          }`}>
                            <div className="flex items-start gap-3">
                              <div className={`p-2 rounded-full ${
                                entry.type === 'user_challenge' ? 'bg-blue-700' : 'bg-purple-700'
                              }`}>
                                {entry.type === 'user_challenge' ? '👤' : '🤖'}
                              </div>
                              <div className="flex-1">
                                <div className="flex justify-between items-start mb-2">
                                  <h4 className="font-medium text-sm text-gray-300">
                                    {entry.type === 'user_challenge' ? 'Your Challenge' : 'AI Response'}
                                  </h4>
                                  <span className="text-xs text-gray-500">
                                    {new Date(entry.timestamp).toLocaleTimeString()}
                                  </span>
                                </div>
                                <p className="text-gray-300 text-sm whitespace-pre-wrap">{entry.content}</p>
                                
                                {entry.type === 'ai_response' && entry.project && (
                                  <div className="mt-3 text-xs text-gray-400">
                                    <Badge variant="outline">Updated Project: {entry.project.projectName} ({entry.project.scripts.length} scripts)</Badge>
                                  </div>
                                )}

                                {entry.type === 'ai_response' && entry.changes && (
                                  <div className="mt-3">
                                    <h5 className="text-green-300 text-xs font-medium mb-1">Changes Made:</h5>
                                    <ul className="text-xs text-gray-400 space-y-1">
                                      {entry.changes.map((change, i) => (
                                        <li key={i} className="flex items-start gap-1">
                                          <span className="text-green-400">•</span>
                                          <span>{change}</span>
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                )}

                                {entry.type === 'ai_response' && entry.questions && entry.questions.length > 0 && (
                                  <div className="mt-3">
                                    <h5 className="text-yellow-300 text-xs font-medium mb-1">AI Questions for You:</h5>
                                    <ul className="text-xs text-gray-400 space-y-1">
                                      {entry.questions.map((question, i) => (
                                        <li key={i} className="flex items-start gap-1">
                                          <span className="text-yellow-400">?</span>
                                          <span>{question}</span>
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              )}
            </>
          )}

          {!activeSession && !showNewSessionForm && (
            <Card className="bg-gray-800/50 border-gray-700/30">
              <CardContent className="text-center py-12">
                <TestTube2 className="w-16 h-16 mx-auto mb-4 text-purple-400 opacity-50" />
                <h3 className="text-xl text-gray-300 mb-2">Welcome to AI Script Forge</h3>
                <p className="text-gray-400 mb-6">
                  Select an active session or create a new one to begin iterative script project development.
                </p>
                <Button
                  onClick={() => setShowNewSessionForm(true)}
                  className="bg-purple-700 hover:bg-purple-600"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create Your First Session
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
