
import React, { useState } from "react";
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Wand2, Loader2, AlertCircle, Clipboard, FileText, Download } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import ReactMarkdown from "react-markdown";

export default function NexusDescriptionGeneratorPage() {
  const [modName, setModName] = useState("");
  const [selectedGame, setSelectedGame] = useState("Skyrim");
  const [modDescription, setModDescription] = useState("");
  const [features, setFeatures] = useState("");
  const [requirements, setRequirements] = useState("");
  const [installInstructions, setInstallInstructions] = useState("");
  const [generatedDescription, setGeneratedDescription] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [isCopied, setIsCopied] = useState(false);

  const handleGenerate = async () => {
    if (!modName.trim() || !modDescription.trim()) {
      setError("Please fill in at least the mod name and description fields.");
      return;
    }

    setIsGenerating(true);
    setError(null);
    setGeneratedDescription(null);

    const prompt = `You are an expert at writing professional, engaging descriptions for Nexus Mods. Create a comprehensive mod description page for a ${selectedGame} mod.

    Mod Details:
    - Name: ${modName}
    - Game: ${selectedGame}
    - Description: ${modDescription}
    ${features ? `- Features: ${features}` : ''}
    ${requirements ? `- Requirements: ${requirements}` : ''}
    ${installInstructions ? `- Installation Notes: ${installInstructions}` : ''}

    Create a professional Nexus Mods description in markdown format with these sections:

    ### What This Mod Does
    (Compelling overview of the mod's purpose and what it adds to the game)

    ### Features
    (Bulleted list of key features and functionality)

    ### Installation
    (Clear, step-by-step installation instructions)

    ### Requirements & Dependencies
    (List any required mods, DLC, or tools needed)

    ### Compatibility & Known Issues
    (Brief section on mod compatibility and any known limitations)

    ### Credits & Permissions
    (Credits section mentioning the "Unofficial TES Script Creator" AI tool)

    Make it engaging, professional, and informative. Use proper markdown formatting. Be specific about ${selectedGame} terminology and modding conventions.`;

    try {
      const result = await InvokeLLM({
        prompt: prompt
      });

      setGeneratedDescription(result);
    } catch (e) {
      setError("Failed to generate Nexus description. Please try again.");
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = () => {
    if (generatedDescription) {
      navigator.clipboard.writeText(generatedDescription);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
      setSuccess("Description copied to clipboard!");
      setTimeout(() => setSuccess(null), 3000);
    }
  };

  const handleReset = () => {
    setModName("");
    setModDescription("");
    setFeatures("");
    setRequirements("");
    setInstallInstructions("");
    setGeneratedDescription(null);
    setError(null);
    setSuccess(null);
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-yellow-200 mb-2 flex items-center justify-center gap-3">
          <FileText className="w-8 h-8" />
          Nexus Mods Description Generator
        </h1>
        <p className="text-gray-400">Create professional descriptions for your Nexus Mods pages</p>
      </div>

      {/* Input Form */}
      <Card className="bg-gray-800/50 border-yellow-800/30">
        <CardHeader>
          <CardTitle className="text-yellow-300 text-xl flex items-center gap-3">
            <Wand2 className="w-6 h-6" />
            Mod Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Mod Name *</label>
              <Input
                value={modName}
                onChange={(e) => setModName(e.target.value)}
                placeholder="e.g., Enhanced Magic System"
                className="bg-gray-900 border-yellow-800/50 text-gray-200"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Target Game *</label>
              <Select value={selectedGame} onValueChange={setSelectedGame}>
                <SelectTrigger className="bg-gray-900 border-yellow-800/50 text-gray-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Morrowind">The Elder Scrolls III: Morrowind</SelectItem>
                  <SelectItem value="Oblivion">The Elder Scrolls IV: Oblivion</SelectItem>
                  <SelectItem value="Skyrim">The Elder Scrolls V: Skyrim</SelectItem>
                  <SelectItem value="Skyrim Special Edition">Skyrim Special Edition</SelectItem>
                  <SelectItem value="TES3MP">TES3MP</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Mod Description *</label>
            <Textarea
              value={modDescription}
              onChange={(e) => setModDescription(e.target.value)}
              placeholder="Describe what your mod does, its purpose, and main functionality..."
              className="h-24 bg-gray-900 border-yellow-800/50 text-gray-200"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Key Features (Optional)</label>
            <Textarea
              value={features}
              onChange={(e) => setFeatures(e.target.value)}
              placeholder="List the main features and functionality of your mod..."
              className="h-20 bg-gray-900 border-yellow-800/50 text-gray-200"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Requirements (Optional)</label>
              <Textarea
                value={requirements}
                onChange={(e) => setRequirements(e.target.value)}
                placeholder="e.g., SKSE, DLC requirements, other mods..."
                className="h-20 bg-gray-900 border-yellow-800/50 text-gray-200"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Installation Notes (Optional)</label>
              <Textarea
                value={installInstructions}
                onChange={(e) => setInstallInstructions(e.target.value)}
                placeholder="Any special installation steps or configuration..."
                className="h-20 bg-gray-900 border-yellow-800/50 text-gray-200"
              />
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={handleGenerate}
              disabled={isGenerating}
              className="bg-yellow-700 hover:bg-yellow-600 text-black font-bold"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Download className="mr-2 h-5 w-5" />
                  Generate Nexus Description
                </>
              )}
            </Button>

            {generatedDescription && (
              <Button variant="outline" onClick={handleReset}>
                Create Another
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Error/Success Messages */}
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="border-green-600 bg-green-900/20">
          <AlertCircle className="h-4 w-4 text-green-400" />
          <AlertTitle className="text-green-400">Success</AlertTitle>
          <AlertDescription className="text-green-300">{success}</AlertDescription>
        </Alert>
      )}

      {/* Generated Description */}
      {generatedDescription && (
        <Card className="bg-gray-800/50 border-yellow-800/30">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-yellow-300 flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Generated Nexus Description
            </CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleCopy}
              className="text-gray-400 hover:text-white"
            >
              <Clipboard className="w-4 h-4 mr-2" />
              {isCopied ? "Copied!" : "Copy Description"}
            </Button>
          </CardHeader>
          <CardContent>
            {/* Raw Markdown for Copying */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-300 mb-2">Raw Markdown (Copy This):</label>
              <pre className="bg-black/50 p-4 rounded-md text-sm text-gray-300 border border-gray-700 max-h-64 overflow-y-auto whitespace-pre-wrap">
                {generatedDescription}
              </pre>
            </div>

            {/* Rendered Preview */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Preview:</label>
              <div className="prose prose-invert prose-sm max-w-none bg-black/30 p-4 rounded-md border border-gray-700 max-h-96 overflow-y-auto">
                <ReactMarkdown>{generatedDescription}</ReactMarkdown>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Usage Instructions */}
      <Card className="bg-blue-900/20 border-blue-700/50">
        <CardHeader>
          <CardTitle className="text-blue-300 text-lg">How to Use</CardTitle>
        </CardHeader>
        <CardContent className="text-blue-200 text-sm space-y-2">
          <ol className="list-decimal list-inside space-y-1">
            <li>Fill in your mod's basic information above</li>
            <li>Click "Generate Nexus Description" to create your professional description</li>
            <li>Copy the raw markdown text from the generated description</li>
            <li>Paste it directly into your Nexus Mods description field</li>
            <li>Edit and customize as needed for your specific mod</li>
          </ol>
          <p className="mt-3 text-blue-300">
            <strong>Tip:</strong> The more details you provide, the better and more specific your generated description will be!
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
