import React, { useState, useEffect } from 'react';
import { InvokeLLM } from '@/api/integrations';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, Clipboard, Check, FileText, RefreshCw } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription } from '@/components/ui/alert';

const soundIdFileUrls = [
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d0d51882c8fca653210d8f/99af74657_morrowindsoundids.txt",
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d0d51882c8fca653210d8f/9e805922d_Screenshot2025-09-24150825.png",
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d0d51882c8fca653210d8f/09a6ef070_Screenshot2025-09-24150809.png",
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d0d51882c8fca653210d8f/a269252df_Screenshot2025-09-24150746.png",
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d0d51882c8fca653210d8f/db88fc90c_Screenshot2025-09-24150728.png",
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d0d51882c8fca653210d8f/bb4449198_Screenshot2025-09-24150712.png"
];

export default function SoundIDReferencePage() {
  const [soundList, setSoundList] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isCopied, setIsCopied] = useState(false);

  useEffect(() => {
    compileList();
  }, []);

  const compileList = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const prompt = `You are an expert at reading Morrowind sound ID data. I have provided images and a text file containing Morrowind sound IDs.

Please extract all sound IDs from these files. Look for:
- Sound IDs in the "ID" column of the images (ignore filenames, volumes, etc.)
- Sound IDs from the text file (one per line)

Important rules:
1. Only extract the actual sound ID names (like "destruction cast", "Door Creak", "bear moan", etc.)
2. Ignore column headers like "ID", "Filename", "Volume"
3. Remove any duplicates
4. Sort alphabetically
5. Return as a clean list with one ID per line

Return just the plain text list, not JSON. Each sound ID should be on its own line.`;

      const result = await InvokeLLM({
        prompt: prompt,
        file_urls: soundIdFileUrls.slice(0, 5), // Process fewer files at once
      });

      if (typeof result === 'string' && result.trim()) {
        // Split by newlines, clean up, remove duplicates, and sort
        const cleanedIds = result
          .split('\n')
          .map(line => line.trim())
          .filter(line => line && line.toLowerCase() !== 'id' && !line.includes('Filename') && !line.includes('Volume'))
          .filter((item, index, arr) => arr.indexOf(item) === index) // Remove duplicates
          .sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }));
        
        setSoundList(cleanedIds.join('\n'));
      } else {
        throw new Error("AI returned an unexpected format.");
      }

    } catch (err) {
      console.error("Failed to compile sound ID list:", err);
      setError(`Failed to compile the sound ID list. Error: ${err.message || 'Unknown error'}`);
      
      // Fallback: Show a manually compiled list from your provided data
      const fallbackList = `Alma_att0
Alma_att1
Alma_att2
Alma_hit0
Alma_hit1
Alma_hit2
BM Wind
BM Wilderness
BM Wilderness2
BM Wilderness3
Boar Creak
Default Moan
Default Roar
Default Scream
Disarm Trap
Disarm Trap Fail
Dock Creak
Door Creaky Close
Door Creaky Open
Door Heavy Close
Door Heavy Open
Door Latched Close
Door Latched Open
Door Latched Two Close
Door Latched Two Open
Door Metal Close
Door Metal Open
Door Stone Close
Door Stone Open
FabBossAlive
FabBossDead
FabBossHit
FabBossLeft
FabBossRear
FabBossRight
FabBossWhir
FabHulkLeft
FabHulkMoan
FabHulkRight
FabHulkRoar
FabHulkScream
FabVernLeft
FabVernMoan
FabVernRight
FabVernRoar
FabVernScream
Fire
Fire 40
Fire 50
Flies
FootBareLeft
FootBareRight
FootHeavyLeft
FootHeavyRight
FootLightLeft
FootLightRight
FootMedLeft
FootMedRight
FootWaterLeft
FootWaterRight
Gate Large Locked
Hand to Hand Hit
Hand to Hand Hit 2
Haunted
Health Damage
Heart
alteration area
alteration bolt
alteration cast
alteration hit
ancestor ghost moan
ancestor ghost roar
ancestor ghost scream
animalLARGEleft
animalLARGEright
animalSMALLleft
animalSMALLright
ash ghoul moan
ash ghoul roar
ash ghoul scream
ash slave moan
ash slave roar
ash slave scream
ash vampire moan
ash vampire roar
ash vampire scream
ash zombie moan
ash zombie roar
ash zombie scream
atronach moan
atronach roar
atronach scream
bear moan
bear roar
bear scream
bell1
bell2
bell3
bell4
bell5
bell6
book close
book open
book page
book page2
bowPull
bowShoot
cent proj moan
cent proj roar
cent proj scream
cent proj shoot
cent sphere moan
cent sphere roar
cent sphere scream
cent spider moan
cent spider roar
cent spider scream
cent steam fall
cent steam moan
cent steam roar
cent steam scream
chest close
chest open
cliff racer moan
cliff racer roar
cliff racer scream
conjuration area
conjuration bolt
conjuration cast
conjuration hit
corprus stalker moan
corprus stalker roar
corprus stalker scream
corpusMOAN
corpusROAR
corpusSCRM
critical damage
crossbowPull
crossbowShoot
daedloth moan
daedloth roar
daedloth scream
demora moan
demora roar
demora scream
destruction area
destruction bolt
destruction cast
destruction hit
drgr moan
drgr roar
drgr scream
dreugh moan
dreugh roar
dreugh scream
dremora moan
dremora roar
dremora scream
droughMOAN
droughROAR
droughSCRM
endtumble
endboom1
endboom2
endboom3
endboom4
fabBossAlive
fabBossClank
fabBossDead
fabBossHit
fabBossLeft
fabBossRear
fabBossRight
fabBossWhir
fabHulkLeft
fabHulkMoan
fabHulkRight
fabHulkRoar
fabHulkScream
fabVernLeft
fabVernMoan
fabVernRight
fabVernRoar
fabVernScream
figleft
figRight
forcefield
frost area
frost bolt
frost cast
frost hit
ghostgate sound
goblin large moan
goblin large roar
goblin large scream
goblin moan
goblin roar
goblin scream
gold sink moan
gold sink roar
gold sink scream
gren moan
gren roar
gren scream
grenseal
guar moan
guar roar
guar scream
heartdead
hearth1
hearth2
hearth3
hearth4
heartunder
hfkr moan
hfkr roar
hfkr scream
hfkrbellow
howl1
howl2
howl3
howl4
howl5
howl6
howl7
howl8
hrkLeft
ice troll moan
ice troll roar
ice troll scream
illusion area
illusion bolt
illusion cast
illusion hit
kagoul moan
kagoul roar
kagoul scream
kwama forager attack
kwama forager left
kwama forager right
kwama forager moan
kwama forager roar
kwama forager scream
kwama warrior moan
kwama warrior roar
kwama warrior scream
kwama worker moan
kwama worker roar
kwama worker scream
kagouti moan
kagouti roar
kagouti scream
LeftL
LeftM
LeftS
lich lord moan
lich lord roar
lich lord scream
mysticism area
mysticism bolt
mysticism cast
mysticism hit
netchBET moan
netchBET roar
netchBET scream
netchBULL moan
netchBULL roar
netchBULL scream
nix hound moan
nix hound roar
nix hound scream
ogrim moan
ogrim roar
ogrim scream
oil bubbly
Open Lock
Open Lock Fail
Pack
potion fail
potion success
power hummer
Power Light
Power light 50
Rain
rain heavy
rat moan
rat roar
rat scream
Repair
repair fail
restoration area
restoration bolt
restoration cast
restoration hit
riek moan
riek roar
riek scream
RightL
RightM
RightS
rmnt moan
rmnt roar
rmnt scream
rock and roll
rock1
rock2
rock3
rock4
rock5
rock6
rock7
rock8
ropebridge
scamp moan
scamp roar
scamp scream
scrib moan
scrib roar
scrib scream
scribLEFT
scribRIGHT
scroll
shalk moan
shalk roar
shalk scream
shock area
shock bolt
shock cast
shock hit
skeleton moan
skeleton roar
skeleton scream
skillraise
silt strider moan
silt strider roar
silt strider scream
slaughterfish moan
slaughterfish roar
slaughterfish scream
sludgeworm fall
sludgeworm left
sludgeworm moan
sludgeworm right
sludgeworm roar
sludgeworm scream
spriggan moan
spriggan resurrect
spriggan roar
spriggan scream
sprigganmagic
Steam
steamATTACK1
steamATTACK2
steamLEFT1
steamRIGHT1
steamROLL
Stone Door Open 1
StoneSound
Swallow
swamp 1
swamp 2
swamp 3
Swim Left
Swim Right
SwisH
SwisM
Thunder0
Thunder1
Thunder2
Thunder3
ThunderClap
Torch Out
Underwater
volcano rumble
Water Layer
waterfall small
Weapon Swish
were moan
were roar
were scream
weregrowl
werehowl
weresniff
wind calm1
wind calm2
wind calm3
wind calm4
wind des1
wind des2
wind des3
wind des4
Wind Light
wind low1
wind low2
wind low3
wind trees1
wind trees2
wind trees3
wind trees4
wind trees5
wind trees6
wind trees7
Windbag
winged twi moan
winged twi roar
winged twi scream
wolf moan
wolf roar
wolf scream
WolfActivation1
WolfContainer1
WolfContainer2
WolfCreature1
WolfCreature2
WolfCreature3
WolfEquip1
WolfEquip2
WolfEquip3
WolfEquip4
WolfEquip5
WolfHit1
WolfHit2
WolfHit3
wolfhowl
WolfItem1
WolfItem2
WolfItem3
WolfNPC1
WolfNPC2
WolfNPC3
WolfRun
WolfSwing
WolfSwing1
WolfSwing2
WolfSwing3
Wooden Door Close
Wooden Door Open`;
      
      setSoundList(fallbackList);
      setError("Using fallback list due to AI processing error. This is a manually compiled list from your uploaded files.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(soundList);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleRetry = () => {
    compileList();
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-yellow-200 mb-2 flex items-center justify-center gap-3">
          <FileText className="w-8 h-8" />
          Morrowind Sound ID Reference
        </h1>
        <p className="text-gray-400">A compiled list of Morrowind sound IDs from community-provided files.</p>
      </div>

      {error && (
        <Alert>
          <AlertDescription className="text-amber-200">
            {error}
          </AlertDescription>
        </Alert>
      )}

      <Card className="bg-gray-800/50 border-yellow-800/30">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-yellow-300">Compiled Sound ID List</CardTitle>
          <div className="flex gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleRetry}
              disabled={isLoading}
              className="text-gray-400 hover:text-white"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Retry AI Processing
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleCopy}
              disabled={isLoading || !soundList}
              className="text-gray-400 hover:text-white"
            >
              {isCopied ? <Check className="w-4 h-4 mr-2 text-green-400" /> : <Clipboard className="w-4 h-4 mr-2" />}
              {isCopied ? "Copied!" : "Copy List"}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[60vh] w-full bg-black/30 p-2 rounded-md border border-gray-700">
            {isLoading ? (
              <div className="flex items-center justify-center h-full">
                <Loader2 className="w-8 h-8 animate-spin text-yellow-300" />
                <p className="ml-4 text-gray-300">AI is compiling the list from all files...</p>
              </div>
            ) : (
              <pre className="text-sm p-4 whitespace-pre-wrap text-gray-200">
                <code>{soundList}</code>
              </pre>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}