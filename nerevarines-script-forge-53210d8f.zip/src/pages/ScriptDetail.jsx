
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { GameScript } from "@/api/entities";
import { LearningFile } from "@/api/entities";
import { User } from "@/api/entities"; // Added import for User entity
import { InvokeLLM, UploadFile } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Edit3, Send, Loader2, AlertCircle, Save, X, Upload, MessageSquare, Wand2, RotateCcw, Mic, MicOff } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { createPageUrl } from "@/utils";

import ScriptOutput from "../components/ScriptOutput";
import InstructionsPanel from "../components/InstructionsPanel";
import ScriptDiscussionPanel from "../components/ScriptDiscussionPanel";

// VoiceToText Component Definition
const VoiceToText = ({ onTranscript, className }) => {
  const [isListening, setIsListening] = useState(false);
  const [hasSpeechRecognition, setHasSpeechRecognition] = useState(false);
  const [recognition, setRecognition] = useState(null);

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      setHasSpeechRecognition(true);
      const newRecognition = new SpeechRecognition();
      newRecognition.continuous = false; // Listen for a single utterance
      newRecognition.interimResults = false;
      newRecognition.lang = 'en-US';

      newRecognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        onTranscript(transcript);
        setIsListening(false);
      };

      newRecognition.onend = () => {
        setIsListening(false);
      };

      newRecognition.onerror = (event) => {
        console.error("Speech recognition error:", event.error);
        setIsListening(false);
      };
      setRecognition(newRecognition);
    } else {
      setHasSpeechRecognition(false);
    }
  }, [onTranscript]);

  const toggleListening = () => {
    if (!hasSpeechRecognition) {
      alert("Your browser does not support Speech Recognition. Please use Chrome or Edge.");
      return;
    }

    if (isListening) {
      recognition.stop();
    } else {
      recognition.start();
    }
    setIsListening(!isListening);
  };

  if (!hasSpeechRecognition) {
    return null; // Or a disabled button/message
  }

  return (
    <Button
      type="button"
      onClick={toggleListening}
      variant="ghost"
      size="icon"
      className={`${className} ${isListening ? 'text-red-500 hover:bg-red-900/50' : 'text-gray-400 hover:text-gray-200 hover:bg-gray-700/50'}`}
      aria-label={isListening ? "Stop listening" : "Start voice input"}
    >
      {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
    </Button>
  );
};

export default function ScriptDetailPage() {
  const navigate = useNavigate();
  const [script, setScript] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [editPrompt, setEditPrompt] = useState("");
  const [editedScript, setEditedScript] = useState(null);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [showInstructions, setShowInstructions] = useState(false);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [uploadedFileUrl, setUploadedFileUrl] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  
  // Discussion state
  const [showDiscussion, setShowDiscussion] = useState(false);
  const [discussionHistory, setDiscussionHistory] = useState([]);
  const [currentDiscussion, setCurrentDiscussion] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const urlParams = new URLSearchParams(window.location.search);
  const scriptId = urlParams.get('id');

  useEffect(() => {
    if (scriptId) {
      const loadScript = async () => {
        setIsLoading(true);
        try {
          // It's better to fetch the specific item if the user has access.
          // However, since we're filtering on the list page, the user should only be able to click their own scripts.
          // For security, a direct fetch with an ID should ideally be checked on the backend.
          // For now, we replicate the logic of filtering by user.
          const user = await User.me();
          const userScripts = await GameScript.filter({ created_by: user.email });
          const foundScript = userScripts.find(s => s.id === scriptId);
          if (foundScript) {
            setScript(foundScript);
          } else {
            setError("Script not found or you don't have permission to view it.");
          }
        } catch (error) {
          setError("Error loading script");
          console.error(error);
        } finally {
          setIsLoading(false);
        }
      };

      loadScript();
    }
  }, [scriptId]);

  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    // Validate file type
    const validTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      setError("Please upload a valid image file (PNG, JPEG, GIF, or WebP).");
      return;
    }

    // Validate file size (max 10MB)
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (file.size > maxSize) {
      setError("Image file too large. Please upload an image under 10MB.");
      return;
    }

    setIsUploading(true);
    setError(null);
    setUploadedFile(file);

    try {
      const { file_url } = await UploadFile({ file });
      setUploadedFileUrl(file_url);
    } catch (e) {
      setError("Failed to upload image. Please try a different image file.");
      setUploadedFile(null);
      console.error("Upload error:", e);
    } finally {
      setIsUploading(false);
    }
  };

  const removeFile = () => {
    setUploadedFile(null);
    setUploadedFileUrl(null);
  };

  const handleStartDiscussion = async (discussionPrompt) => {
    setIsAnalyzing(true);
    setError(null);
    setCurrentDiscussion(null);
    setDiscussionHistory([]);

    try {
      // Fetch learning files for this game from the library
      const allLearningFiles = await LearningFile.list('-created_date', 50);
      const gameSpecificFiles = allLearningFiles.filter(file => 
        file.game === script.game || file.game === 'Other'
      );
      const libraryFileUrls = gameSpecificFiles.map(file => file.fileUrl);

      const learningContext = libraryFileUrls.length > 0 ? `
      
      REFERENCE LEARNING LIBRARY:
      You have access to ${libraryFileUrls.length} reference file(s) from the learning library for ${script.game}. Use these files to understand best practices, common patterns, and proper API usage when analyzing the script.
      ` : '';

      const fullDiscussionPrompt = `You are an expert in ${script.game} scripting and modding. A user has an existing script and wants to discuss potential improvements, fixes, or modifications.

      EXISTING SCRIPT:
      Title: ${script.title}
      Description: ${script.description}
      Game: ${script.game}
      Category: ${script.category}
      
      Script Code:
      ${script.scriptCode}
      ${learningContext}
      USER'S DISCUSSION PROMPT: "${discussionPrompt}"

      Please analyze this existing script and the user's concerns. Return a JSON object with:
      - "feasible": boolean (is the user's request technically possible in ${script.game}?)
      - "limitations": array of strings (any technical limitations or challenges)
      - "suggestions": array of strings (improvements or alternative approaches)
      - "questions": array of strings (clarifying questions to ask the user)
      - "considerations": array of strings (important things the user should know)
      - "complexity": string ("Simple", "Moderate", "Complex", or "Advanced")
      - "scriptAnalysis": string (analysis of the current script - what it does well, potential issues)

      Be helpful, specific, and educational. Focus on ${script.game}'s capabilities and limitations.`;

      const requestData = {
        prompt: fullDiscussionPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            feasible: { type: "boolean" },
            limitations: { type: "array", items: { type: "string" } },
            suggestions: { type: "array", items: { type: "string" } },
            questions: { type: "array", items: { type: "string" } },
            considerations: { type: "array", items: { type: "string" } },
            complexity: { type: "string" },
            scriptAnalysis: { type: "string" }
          },
          required: ["feasible", "limitations", "suggestions", "questions", "considerations", "complexity", "scriptAnalysis"]
        }
      };

      // Include uploaded image and learning library files
      const allFileUrls = [];
      if (uploadedFileUrl) allFileUrls.push(uploadedFileUrl);
      if (libraryFileUrls.length > 0) allFileUrls.push(...libraryFileUrls);
      
      if (allFileUrls.length > 0) {
        requestData.file_urls = allFileUrls;
      }

      const result = await InvokeLLM(requestData);
      
      setCurrentDiscussion(result);
      setDiscussionHistory([{ type: 'analysis', content: result, timestamp: Date.now() }]);
      setShowDiscussion(true);
    } catch (e) {
      console.error("Discussion error:", e);
      if (e.message && e.message.includes('image')) {
        setError("There was an issue with the uploaded image. Please try uploading a different image or continue without an image.");
      } else {
        setError("Failed to analyze script. Please try again.");
      }
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleDiscussionResponse = async (response) => {
    setIsAnalyzing(true);
    
    const conversationHistory = discussionHistory.map(item => {
      if (item.type === 'analysis') {
        return `AI Analysis: Feasible: ${item.content.feasible}, Complexity: ${item.content.complexity}
        Script Analysis: ${item.content.scriptAnalysis}
        Limitations: ${item.content.limitations.join(', ')}
        Suggestions: ${item.content.suggestions.join(', ')}
        Questions: ${item.content.questions.join(', ')}`;
      } else if (item.type === 'user_response') {
        return `User Response: ${item.content}`;
      } else if (item.type === 'ai_followup') {
        return `AI Response: ${item.content}`;
      }
      return '';
    }).join('\n\n');

    const followupPrompt = `You are continuing a discussion about a ${script.game} script.

    Script being discussed: "${script.title}"
    
    Previous conversation:
    ${conversationHistory}
    
    User's latest response: "${response}"
    
    Please provide a helpful follow-up response. Address their concerns, answer questions, and provide additional guidance. Keep it concise but informative.
    
    Return a JSON object with:
    - "response": string (your response to the user)
    - "readyToEdit": boolean (do you think we have enough info to make good script modifications?)
    - "additionalSuggestions": array of strings (any new suggestions based on their response)`;

    try {
      const requestData = {
        prompt: followupPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            response: { type: "string" },
            readyToEdit: { type: "boolean" },
            additionalSuggestions: { type: "array", items: { type: "string" } }
          },
          required: ["response", "readyToEdit"]
        }
      };

      // Only add file_urls if we have a valid upload URL  
      if (uploadedFileUrl) {
        requestData.file_urls = [uploadedFileUrl];
      }

      const result = await InvokeLLM(requestData);

      const newHistory = [
        ...discussionHistory,
        { type: 'user_response', content: response, timestamp: Date.now() },
        { type: 'ai_followup', content: result.response, readyToEdit: result.readyToEdit, suggestions: result.additionalSuggestions || [], timestamp: Date.now() }
      ];
      
      setDiscussionHistory(newHistory);
    } catch (e) {
      console.error("Followup error:", e);
      if (e.message && e.message.includes('image')) {
        setError("There was an issue with the uploaded image. The discussion will continue without image context.");
      } else {
        setError("Failed to continue discussion. Please try again.");
      }
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleProceedToEdit = () => {
    setShowDiscussion(false);
    setIsEditing(true);
    // Pre-populate the edit prompt with discussion context if available
    const latestSuggestion = discussionHistory.find(item => item.type === 'ai_followup')?.suggestions?.[0];
    if (latestSuggestion && !editPrompt) {
      setEditPrompt(`Based on our discussion: ${latestSuggestion}`);
    }
  };

  const handleResetDiscussion = () => {
    setShowDiscussion(false);
    setDiscussionHistory([]);
    setCurrentDiscussion(null);
    setUploadedFile(null);
    setUploadedFileUrl(null);
  };

  const handleEditScript = async () => {
    if (!editPrompt.trim()) {
      setError("Please describe what you want to change about the script.");
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      // Fetch learning files for this game from the library
      const allLearningFiles = await LearningFile.list('-created_date', 50);
      const gameSpecificFiles = allLearningFiles.filter(file => 
        file.game === script.game || file.game === 'Other'
      );
      const libraryFileUrls = gameSpecificFiles.map(file => file.fileUrl);

      const gamePrompts = {
        Morrowind: "You are an expert in Morrowind scripting. The user will provide an existing script and request changes.",
        Oblivion: "You are an expert in Oblivion scripting. The user will provide an existing script and request changes.",
        Skyrim: "You are an expert in Skyrim Papyrus scripting. The user will provide an existing script and request changes.",
        TES3MP: "You are an expert in TES3MP server-side Lua scripting. The user will provide an existing script and request changes. Your modifications MUST be server-authoritative and follow multiplayer best practices.",
        OpenMW: "You are an expert in OpenMW Lua scripting. The user will provide an existing script and request changes.",
        MWSE: "You are an expert in MWSE Lua scripting. The user will provide an existing script and request changes."
      };

      const discussionContext = discussionHistory.length > 0 ? `
      
      DISCUSSION CONTEXT:
      The user and AI have discussed this script. Key points from the discussion:
      ${discussionHistory.map(item => {
        if (item.type === 'analysis') return `AI Analysis: ${item.content.scriptAnalysis}. Suggestions: ${item.content.suggestions.join(', ')}`;
        if (item.type === 'user_response') return `User: ${item.content}`;
        if (item.type === 'ai_followup') return `AI Response: ${item.content}`;
        return '';
      }).join('\n')}
      ` : '';

      const learningContext = libraryFileUrls.length > 0 ? `
      
      REFERENCE LEARNING LIBRARY:
      You have access to ${libraryFileUrls.length} reference file(s) from the learning library for ${script.game}. Study these files to understand proper coding patterns, API usage, and best practices when making modifications.
      ` : '';

      const imageContextPrompt = uploadedFileUrl ? 
        "\n\nThe user has also provided an image for additional context (e.g., an error screenshot, game element, etc.). Use this visual information to better understand their request and provide more accurate solutions." : "";

      const fullPrompt = `${gamePrompts[script.game]}

      CURRENT SCRIPT:
      ${script.scriptCode}
      ${discussionContext}
      ${learningContext}
      USER'S CHANGE REQUEST: "${editPrompt}"${imageContextPrompt}

      Please modify the script according to the user's request and discussion context. Maintain the same structure and style while incorporating knowledge from the learning library files.
      
      Return a JSON object with:
      - "title": Updated title for the script (if changed, otherwise keep the same)
      - "description": Updated description of what the script does
      - "scriptCode": The modified script code
      - "category": Updated category if changed (NPC, Object, Quest, Utility, Combat, Magic, Other)`;

      const requestData = {
        prompt: fullPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            description: { type: "string" },
            scriptCode: { type: "string" },
            category: { type: "string" }
          },
          required: ["title", "description", "scriptCode", "category"]
        }
      };

      // Include uploaded image and learning library files
      const allFileUrls = [];
      if (uploadedFileUrl) allFileUrls.push(uploadedFileUrl);
      if (libraryFileUrls.length > 0) allFileUrls.push(...libraryFileUrls);
      
      if (allFileUrls.length > 0) {
        requestData.file_urls = allFileUrls;
      }

      const result = await InvokeLLM(requestData);

      setEditedScript({
        ...result,
        game: script.game,
        originalPrompt: script.originalPrompt
      });
    } catch (e) {
      console.error("Edit error:", e);
      if (e.message && e.message.includes('image')) {
        setError("There was an issue with the uploaded image. Please try editing without the image or upload a different image.");
      } else {
        setError("Failed to edit script. Please try again.");
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSaveChanges = async () => {
    if (!editedScript) return;

    setIsSaving(true);
    try {
      await GameScript.update(script.id, editedScript);
      setScript({ ...script, ...editedScript });
      setEditedScript(null);
      setIsEditing(false);
      setEditPrompt("");
      setUploadedFile(null);
      setUploadedFileUrl(null);
      setDiscussionHistory([]);
      setCurrentDiscussion(null);
      setSuccess("Script updated successfully!");
      setTimeout(() => setSuccess(null), 3000);
    } catch (e) {
      setError("Failed to save changes. Please try again.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditedScript(null);
    setEditPrompt("");
    setUploadedFile(null);
    setUploadedFileUrl(null);
    setError(null);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-300"></div>
      </div>
    );
  }

  if (!script) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl text-red-400">{error || "Script not found"}</h2>
        <Button onClick={() => navigate(createPageUrl("MyScripts"))} className="mt-4">
          Back to My Scripts
        </Button>
      </div>
    );
  }

  const displayScript = editedScript || script;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          onClick={() => navigate(createPageUrl("MyScripts"))}
          className="text-gray-400 hover:text-white"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to My Scripts
        </Button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="border-green-600 bg-green-900/20">
          <AlertCircle className="h-4 w-4 text-green-400" />
          <AlertDescription className="text-green-300">{success}</AlertDescription>
        </Alert>
      )}

      <ScriptOutput script={displayScript} />

      {/* Discussion Panel */}
      {showDiscussion && (
        <ScriptDiscussionPanel
          script={script}
          discussionHistory={discussionHistory}
          currentDiscussion={currentDiscussion}
          isAnalyzing={isAnalyzing}
          onResponse={handleDiscussionResponse}
          onProceedToEdit={handleProceedToEdit}
          onReset={handleResetDiscussion}
        />
      )}

      {/* Discussion or Edit Section */}
      {!showDiscussion && !isEditing && (
        <Card className="bg-gray-800/50 border-yellow-800/30">
          <CardHeader>
            <CardTitle className="text-yellow-300 flex items-center gap-2">
              <MessageSquare className="w-5 h-5" />
              AI Script Assistant
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center py-6">
              <p className="text-gray-400 mb-4">
                Discuss potential improvements with the AI or directly edit your script.
              </p>
              <div className="flex gap-3 justify-center">
                <Button
                  onClick={() => {
                    setShowDiscussion(true);
                    // Auto-start discussion with a generic prompt
                    handleStartDiscussion("I want to discuss potential improvements or issues with this script.");
                  }}
                  disabled={isAnalyzing}
                  className="bg-blue-700 hover:bg-blue-600"
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Starting Discussion...
                    </>
                  ) : (
                    <>
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Discuss with AI
                    </>
                  )}
                </Button>
                <Button
                  onClick={() => setIsEditing(true)}
                  className="bg-yellow-700 hover:bg-yellow-600 text-black"
                >
                  <Edit3 className="w-4 h-4 mr-2" />
                  Direct Edit
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Edit Section */}
      {isEditing && (
        <Card className="bg-gray-800/50 border-yellow-800/30">
          <CardHeader>
            <CardTitle className="text-yellow-300 flex items-center gap-2">
              <Edit3 className="w-5 h-5" />
              AI Script Editor
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  What would you like to change about this script?
                </label>
                <div className="relative">
                  <Textarea
                    value={editPrompt}
                    onChange={(e) => setEditPrompt(e.target.value)}
                    placeholder="e.g., 'The NPC isn't giving gold, fix this', 'Make the spell cost 25 magicka instead of 50', 'Add a level requirement of 10'"
                    className="h-24 bg-gray-900 border-yellow-800/50 text-gray-200"
                  />
                  <div className="absolute top-2 right-2">
                    <VoiceToText 
                      onTranscript={(text) => setEditPrompt(prev => prev + (prev ? " " : "") + text)} 
                      className="bg-gray-900/80 backdrop-blur rounded"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label htmlFor="image-upload-edit" className="block text-sm font-medium text-gray-300 mb-2">
                  Upload Error Screenshot or Context Image (Optional)
                </label>
                <div className="flex items-center gap-4">
                  <label htmlFor="image-upload-edit" className="cursor-pointer">
                    <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-800">
                      <Upload className="w-4 h-4 mr-2" />
                      Choose File
                    </Button>
                  </label>
                  <Input 
                    id="image-upload-edit" 
                    type="file" 
                    className="hidden" 
                    onChange={handleFileChange}
                    accept="image/png, image/jpeg, image/jpg"
                  />
                  {isUploading && <Loader2 className="w-5 h-5 animate-spin text-gray-400" />}
                  {uploadedFile && !isUploading && (
                    <div className="flex items-center gap-2 text-sm text-gray-300">
                      <span>{uploadedFile.name}</span>
                      <Button variant="ghost" size="icon" onClick={removeFile} className="w-6 h-6 p-0 text-gray-400 hover:text-gray-200">
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </div>
                {uploadedFile && (
                  <div className="mt-4">
                    <img 
                      src={URL.createObjectURL(uploadedFile)} 
                      alt="Upload preview" 
                      className="max-h-40 rounded-md border border-gray-600 object-contain"
                    />
                  </div>
                )}
              </div>

              <div className="flex gap-3">
                <Button
                  onClick={handleEditScript}
                  disabled={isProcessing || isUploading}
                  className="bg-yellow-700 hover:bg-yellow-600 text-black"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Send className="mr-2 h-4 w-4" />
                      Apply Changes
                    </>
                  )}
                </Button>
                <Button variant="outline" onClick={handleCancelEdit}>
                  <X className="mr-2 h-4 w-4" />
                  Cancel
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Save edited script */}
      {editedScript && (
        <Card className="bg-green-900/20 border-green-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-green-300 font-medium">Script Updated</h3>
                <p className="text-green-200 text-sm">Review the changes above and save if you're happy with them.</p>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={handleSaveChanges}
                  disabled={isSaving}
                  className="bg-green-700 hover:bg-green-600"
                >
                  {isSaving ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Save Changes
                    </>
                  )}
                </Button>
                <Button variant="outline" onClick={handleCancelEdit}>
                  Discard
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex justify-center">
        <Button
          variant="outline"
          onClick={() => setShowInstructions(!showInstructions)}
          className="border-yellow-700 text-yellow-300 hover:bg-yellow-900/30"
        >
          {showInstructions ? "Hide" : "Show"} Implementation Instructions
        </Button>
      </div>

      {showInstructions && (
        <InstructionsPanel game={script.game} />
      )}
    </div>
  );
}
