
import React, { useState, useEffect, useRef } from "react";
import { Task } from "@/api/entities/Task";
import { InvokeLLM, UploadFile } from "@/api/integrations";
import { GameScript } from "@/api/entities";
import { ScriptFix } from "@/api/entities";
import { LearningFile } from "@/api/entities";
import { AILearningReport } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Wand2, Loader2, AlertCircle, MessageSquare, Save, RotateCcw, Upload, X } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";

import GameExamples from "../components/GameExamples";
import DiscussionPanel from "../components/DiscussionPanel";
import ScriptProjectOutput from "../components/ScriptProjectOutput";
import NexusDescriptionOutput from "../components/NexusDescriptionOutput";
import VoiceToText from "../components/VoiceToText";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function HomePage() {
  const [selectedGame, setSelectedGame] = useState("Morrowind");
  const [prompt, setPrompt] = useState("");
  const [discussionHistory, setDiscussionHistory] = useState([]);
  const [currentDiscussion, setCurrentDiscussion] = useState(null);
  const [generatedProject, setGeneratedProject] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [phase, setPhase] = useState("input");
  const [uploadedFile, setUploadedFile] = useState(null);
  const [uploadedFileUrl, setUploadedFileUrl] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);

  // Add new state for learning files
  const [learningFiles, setLearningFiles] = useState([]);
  const [learningFileUrls, setLearningFileUrls] = useState([]);
  const [isUploadingLearningFiles, setIsUploadingLearningFiles] = useState(false);
  const [isFileAnalysisLoading, setIsFileAnalysisLoading] = useState(false);
  const [fileAnalysisReport, setFileAnalysisReport] = useState(null);
  const [learningFileGame, setLearningFileGame] = useState("TES3MP");
  const [isSavingLearningReport, setIsSavingLearningReport] = useState(false);

  // Add refs for file inputs
  const imageInputRef = useRef(null);
  const learningFilesInputRef = useRef(null);

  const imageContextPromptSegment = `
    The user may have provided an image for additional context (e.g., a screenshot of an error, a map location, an item in the game). If a file URL is included with this prompt, analyze the image's content as a crucial part of the user's request.
  `;

  const nexusPromptSegment = `
    - "nexusDescription": A complete description for a Nexus Mods page, formatted in markdown. It MUST have these sections: 
      - ### What it Does
      - ### How to Install (summarize the script implementation notes)
      - ### Requirements & Dependencies
      - ### Credits (crediting the user who made the request and this "Unofficial TES Script Creator" AI).
  `;

  const gamePrompts = {
    Morrowind: async () => {
      const previousFixes = await ScriptFix.list('-created_date', 25);
      const morrowindFixes = previousFixes.filter(fix => fix.game === "Morrowind" && fix.userValidated);
      
      const learningContext = morrowindFixes.length > 0 ? `
      LEARN FROM THESE VALIDATED FIXES:
      Previous users have encountered these issues and successful solutions in Morrowind scripts:
      ${morrowindFixes.slice(0, 10).map((fix, i) => `
      Issue ${i + 1}:
      - Problem Type: ${fix.problemType} in ${fix.scriptCategory} scripts
      - Error Pattern: ${fix.errorPattern}
      - Solution: ${fix.solution}
      `).join('\n')}
      
      APPLY THIS KNOWLEDGE to avoid these common mistakes in your script generation.
      ` : '';

      return `You are an expert in the Morrowind scripting language and modding. Your task is to translate a user's plain English request into a functional Morrowind script project.

      CRITICAL SYNTAX REQUIREMENTS - THIS IS ABSOLUTELY ESSENTIAL:
      1. EXACT FUNCTION NAMES: Use only verified Morrowind script functions. Common examples:
         - GetGlobalValue, SetGlobalValue (NOT GetGlobal/SetGlobal)
         - GetItemCount, AddItem, RemoveItem
         - GetDistance, GetAngle, GetPos
         - MessageBox, Choice, Journal
         - Enable, Disable, Lock, Unlock
      
      2. PERFECT SYNTAX STRUCTURE:
         - Scripts MUST start with "Begin [ScriptName]" and end with "End [ScriptName]"
         - Variable declarations use proper types: short, long, float
         - Conditional blocks: if/elseif/else/endif
         - Proper spacing and indentation
      
      3. ACCURATE PARAMETER USAGE:
         - Function parameters must match exact Morrowind requirements
         - String parameters in quotes, numeric without
         - Object references must be valid
      
      4. LEARNING LIBRARY ADHERENCE:
         - The user has provided learning files containing VERIFIED working Morrowind scripts
         - STUDY these files as your PRIMARY reference for correct syntax
         - MIMIC the exact patterns, function calls, and structure shown in these examples
         - If a learning file shows "GetGlobalValue" instead of "GetGlobal", use "GetGlobalValue"
         - Treat these files as the AUTHORITATIVE source for proper Morrowind scripting syntax
      
      5. VALIDATION PROCESS:
         - After generating each script, mentally check every function name against Morrowind's actual API
         - Ensure every conditional block is properly closed
         - Verify all variable declarations are valid
         - Cross-reference with the learning library examples for correctness
      
      ${learningContext}
      ${imageContextPromptSegment}
      
      REMEMBER: Experienced modders will test this code in the TES Construction Set. It MUST compile and run without syntax errors or you will damage the credibility of this tool. 
      
      IMPORTANT: If the request is complex, break it down into multiple, smaller, interconnected scripts.
      Return a JSON object containing a "project" with:
      - "projectName": A short, descriptive name for the overall mod project.
      - "projectDescription": A 1-2 sentence explanation of what the whole mod project does.
      - "scripts": An array of script objects. Each script object must have:
        - "title": A descriptive CamelCase name for the script (e.g., 'MyQuestNPC').
        - "description": A 1-sentence explanation of this specific script's role.
        - "scriptCode": The complete Morrowind script code with PERFECT syntax. It must start with 'Begin ScriptName' and end with 'End ScriptName'. USE ONLY VERIFIED FUNCTION NAMES FROM LEARNING EXAMPLES.
        - "category": One of: NPC, Object, Quest, Utility, Combat, Magic, Other.
        - "implementationNotes": A single string containing a bulleted list of step-by-step instructions on how to attach THIS SPECIFIC SCRIPT in the Morrowind Construction Set.
      ${nexusPromptSegment}`;
    },

    Oblivion: async () => {
      const previousFixes = await ScriptFix.list('-created_date', 25);
      const oblivionFixes = previousFixes.filter(fix => fix.game === "Oblivion" && fix.userValidated);
      
      const learningContext = oblivionFixes.length > 0 ? `
      LEARN FROM THESE VALIDATED FIXES:
      Previous users have encountered these issues and successful solutions in Oblivion scripts:
      ${oblivionFixes.slice(0, 10).map((fix, i) => `
      Issue ${i + 1}:
      - Problem Type: ${fix.problemType} in ${fix.scriptCategory} scripts
      - Error Pattern: ${fix.errorPattern}
      - Solution: ${fix.solution}
      `).join('\n')}
      
      APPLY THIS KNOWLEDGE to avoid these common mistakes in your script generation.
      ` : '';

      return `You are an expert in the Oblivion scripting language and modding. Your task is to translate a user's plain English request into a functional Oblivion script project.

      CRITICAL SYNTAX REQUIREMENTS - THIS IS ABSOLUTELY ESSENTIAL:
      1. EXACT FUNCTION NAMES: Use only verified Oblivion script functions. Common examples:
         - GetGlobalValue, SetGlobalValue
         - GetItemCount, AddItem, RemoveItem
         - GetDistance, GetActorValue, ModActorValue
         - MessageBox, ShowMessage
         - Enable, Disable, Lock, Unlock
      
      2. PERFECT SYNTAX STRUCTURE:
         - Scripts MUST start with "ScriptName [ScriptName]" and end with "End"
         - Variable declarations: ref, short, long, float
         - Conditional blocks: if/elseif/else/endif
         - Proper spacing and indentation
      
      3. LEARNING LIBRARY ADHERENCE:
         - The user has provided learning files containing VERIFIED working Oblivion scripts
         - STUDY these files as your PRIMARY reference for correct syntax
         - MIMIC the exact patterns, function calls, and structure shown in these examples
         - Treat these files as the AUTHORITATIVE source for proper Oblivion scripting syntax
      
      4. VALIDATION PROCESS:
         - After generating each script, mentally verify every function name against Oblivion's actual API
         - Ensure proper script block structure
         - Cross-reference with learning library examples for correctness
      
      ${learningContext}
      ${imageContextPromptSegment}
      
      REMEMBER: This code will be tested in the Oblivion Construction Set. It MUST compile without syntax errors.
      
      IMPORTANT: If the request is complex, break it down into multiple, smaller, interconnected scripts.
      Return a JSON object containing a "project" with:
      - "projectName": A short, descriptive name for the overall mod project.
      - "projectDescription": A 1-2 sentence explanation of what the whole mod project does.
      - "scripts": An array of script objects. Each script object must have:
        - "title": A descriptive name for the script (e.g., 'MyQuestScript').
        - "description": A 1-sentence explanation of this specific script's role.
        - "scriptCode": The complete Oblivion script code with PERFECT syntax. It must start with 'ScriptName ScriptName' and end with 'End'. USE ONLY VERIFIED FUNCTION NAMES.
        - "category": One of: NPC, Object, Quest, Utility, Combat, Magic, Other.
        - "implementationNotes": A single string containing a bulleted list of step-by-step instructions on how to attach THIS SPECIFIC SCRIPT in the Oblivion Construction Set.
      ${nexusPromptSegment}`;
    },

    Skyrim: async () => {
      const previousFixes = await ScriptFix.list('-created_date', 25);
      const skyrimFixes = previousFixes.filter(fix => fix.game === "Skyrim" && fix.userValidated);
      
      const learningContext = skyrimFixes.length > 0 ? `
      LEARN FROM THESE VALIDATED FIXES:
      Previous users have encountered these issues and successful solutions in Skyrim scripts:
      ${skyrimFixes.slice(0, 10).map((fix, i) => `
      Issue ${i + 1}:
      - Problem Type: ${fix.problemType} in ${fix.scriptCategory} scripts
      - Error Pattern: ${fix.errorPattern}
      - Solution: ${fix.solution}
      `).join('\n')}
      
      APPLY THIS KNOWLEDGE to avoid these common mistakes in your script generation.
      ` : '';

      return `You are an expert in Skyrim's Papyrus scripting language and modding. Your task is to translate a user's plain English request into a functional Papyrus script project.

      CRITICAL SYNTAX REQUIREMENTS - THIS IS ABSOLUTELY ESSENTIAL:
      1. EXACT PAPYRUS SYNTAX: Use only verified Papyrus functions and syntax:
         - GlobalVariable.GetValue(), GlobalVariable.SetValue()
         - Game.GetPlayer(), PlayerRef.AddItem()
         - Debug.MessageBox(), Debug.Notification()
         - RegisterForSingleUpdate(), OnUpdate()
         - Proper event handling with Event/EndEvent blocks
      
      2. PERFECT SCRIPT STRUCTURE:
         - Scripts MUST start with "Scriptname [ScriptName] extends [BaseType]"
         - Proper property declarations with {auto} or getter/setter
         - Event blocks properly structured
         - Function definitions with proper return types
      
      3. LEARNING LIBRARY ADHERENCE:
         - The user has provided learning files containing VERIFIED working Papyrus scripts
         - STUDY these files as your PRIMARY reference for correct syntax
         - MIMIC the exact patterns, function calls, and structure shown in these examples
         - Treat these files as the AUTHORITATIVE source for proper Papyrus scripting syntax
      
      4. VALIDATION PROCESS:
         - Verify every function call matches Papyrus API exactly
         - Ensure proper extends declarations and property definitions
         - Cross-reference with learning library examples for correctness
      
      ${learningContext}
      ${imageContextPromptSegment}
      
      REMEMBER: This code will be compiled by the Creation Kit. It MUST have perfect Papyrus syntax or it will fail compilation.
      
      IMPORTANT: If the request is complex, break it down into multiple, smaller, interconnected scripts.
      Return a JSON object containing a "project" with:
      - "projectName": A short, descriptive name for the overall mod project.
      - "projectDescription": A 1-2 sentence explanation of what the whole mod project does.
      - "scripts": An array of script objects. Each script object must have:
        - "title": A descriptive name for the script (e.g., 'MyQuestScript').
        - "description": A 1-sentence explanation of this specific script's role.
        - "scriptCode": The complete Papyrus script code with PERFECT syntax. It must start with 'Scriptname ScriptName extends ...'. USE ONLY VERIFIED PAPYRUS FUNCTIONS.
        - "category": One of: NPC, Object, Quest, Utility, Combat, Magic, Other.
        - "implementationNotes": A single string containing a bulleted list of step-by-step instructions on how to attach THIS SPECIFIC SCRIPT and set its properties in the Skyrim Creation Kit.
      ${nexusPromptSegment}`;
    },

    TES3MP: async () => {
      const previousFixes = await ScriptFix.list('-created_date', 25);
      const tes3mpFixes = previousFixes.filter(fix => fix.game === "TES3MP" && fix.userValidated);
      
      const learningContext = tes3mpFixes.length > 0 ? `
      LEARN FROM THESE VALIDATED FIXES FOR TES3MP:
      Previous users have encountered these issues and successful solutions in TES3MP Lua scripts:
      ${tes3mpFixes.slice(0, 10).map((fix, i) => `
      Issue ${i + 1}:
      - Problem Type: ${fix.problemType} in ${fix.scriptCategory} scripts
      - Error Pattern: ${fix.errorPattern}
      - Solution: ${fix.solution}
      `).join('\n')}
      
      APPLY THIS KNOWLEDGE to avoid these common multiplayer scripting mistakes. Focus on server-authoritative logic and proper event handling.
      ` : '';

      return `You are an expert in TES3MP server-side Lua scripting. Your task is to translate a user's plain English request into a functional Lua script project for a TES3MP server.

      CRITICAL SYNTAX REQUIREMENTS - THIS IS ABSOLUTELY ESSENTIAL:
      1. EXACT TES3MP LUA FUNCTIONS: Use only verified TES3MP API functions:
         - tes3mp.SendMessage(pid, message)
         - tes3mp.GetPlayerName(pid)
         - tes3mp.AddLink("script.lua")
         - tes3mp.RegisterEvent(event, callback)
         - Players[pid] table access patterns
         - Proper JSON handling for data storage
      
      2. PERFECT LUA STRUCTURE:
         - Proper function definitions: function functionName(parameters)
         - Correct table syntax and indexing
         - Proper string concatenation with ..
         - Valid conditional and loop structures
      
      3. LEARNING LIBRARY ADHERENCE:
         - The user has provided learning files containing VERIFIED working TES3MP Lua scripts
         - STUDY these files as your PRIMARY reference for correct TES3MP API usage
         - MIMIC the exact patterns, function calls, and server architecture shown
         - Treat these files as the AUTHORITATIVE source for proper TES3MP scripting
      
      4. SERVER-AUTHORITATIVE LOGIC:
         - All logic MUST be server-side only
         - Use proper player ID (pid) handling
         - Ensure multiplayer-safe operations
      
      Key TES3MP Concepts to Follow:
      - All logic MUST be server-authoritative. Do not write client-side logic.
      - Use 'tes3mp' library functions for player interaction, data storage, and event handling (e.g., tes3mp.SendMessage, tes3mp.GetData, tes3mp.AddListener).
      - Scripts are typically placed in 'server/data/customScripts' and loaded via 'customScripts.lua'.
      - Assume the user is familiar with setting up a TES3MP server but not with Lua scripting.
      
      ${learningContext}
      ${imageContextPromptSegment}
      
      REMEMBER: This code will run on a live TES3MP server. It MUST have perfect Lua syntax and valid TES3MP API calls.
      
      Return a JSON object containing a "project" with:
      - "projectName": A short, descriptive name for the overall mod project.
      - "projectDescription": A 1-2 sentence explanation of what the whole mod project does.
      - "scripts": An array of script objects. Each script object must have:
        - "title": A descriptive CamelCase name for the Lua script file (e.g., 'myQuestSystem.lua').
        - "description": A 1-sentence explanation of this specific script's role.
        - "scriptCode": The complete server-side Lua script code with PERFECT syntax. USE ONLY VERIFIED TES3MP API FUNCTIONS.
        - "category": One of: NPC, Object, Quest, Utility, Combat, Magic, Other.
        - "implementationNotes": A single string containing a bulleted list of step-by-step instructions for installing this script on a TES3MP server (e.g., where to place the file, what to add to customScripts.lua).
      ${nexusPromptSegment}`;
    },

    OpenMW: async () => {
      const previousFixes = await ScriptFix.list('-created_date', 25);
      const openmwFixes = previousFixes.filter(fix => fix.game === "OpenMW" && fix.userValidated);
      
      const learningContext = openmwFixes.length > 0 ? `
      LEARN FROM THESE VALIDATED FIXES FOR OPENMW:
      Previous users have encountered these issues and successful solutions in OpenMW Lua scripts:
      ${openmwFixes.slice(0, 10).map((fix, i) => `
      Issue ${i + 1}:
      - Problem Type: ${fix.problemType} in ${fix.scriptCategory} scripts
      - Error Pattern: ${fix.errorPattern}
      - Solution: ${fix.solution}
      `).join('\n')}
      
      APPLY THIS KNOWLEDGE to avoid these common OpenMW Lua scripting mistakes.
      ` : '';

      return `You are an expert in OpenMW Lua scripting. OpenMW is the open-source reimplementation of Morrowind that supports modern Lua scripting. Your task is to translate a user's plain English request into a functional OpenMW Lua script project.

      CRITICAL SYNTAX REQUIREMENTS - THIS IS ABSOLUTELY ESSENTIAL:
      1. EXACT OPENMW LUA API: Use only verified OpenMW Lua functions:
         - openmw.core, openmw.util, openmw.world, openmw.ui
         - types.Player, types.NPC, types.Container
         - I.Events, I.Settings, I.UI
         - Proper module structure with return statements
      
      2. PERFECT LUA STRUCTURE FOR OPENMW:
         - Proper module definition: local M = {}; return M
         - Correct API namespace usage
         - Valid event handler registration
         - Proper coroutine handling if needed
      
      3. LEARNING LIBRARY ADHERENCE:
         - The user has provided learning files containing VERIFIED working OpenMW Lua scripts
         - STUDY these files as your PRIMARY reference for correct OpenMW API usage
         - MIMIC the exact patterns, module structure, and API calls shown
         - Treat these files as the AUTHORITATIVE source for proper OpenMW Lua scripting
      
      Key OpenMW Lua Concepts to Follow:
      - OpenMW Lua scripts run in a sandboxed environment with specific APIs (openmw.core, openmw.util, openmw.world, etc.)
      - Scripts can be global, local (cell), or player scripts with different capabilities
      - Use proper OpenMW API functions for world interaction, UI, events, and data storage
      - Follow OpenMW's script naming conventions and directory structure
      - Scripts are typically placed in 'data/scripts/' directory
      
      ${learningContext}
      ${imageContextPromptSegment}
      
      REMEMBER: This code will run in OpenMW's Lua environment. It MUST use valid OpenMW API calls and proper Lua syntax.
      
      Return a JSON object containing a "project" with:
      - "projectName": A short, descriptive name for the overall mod project.
      - "projectDescription": A 1-2 sentence explanation of what the whole mod project does.
      - "scripts": An array of script objects. Each script object must have:
        - "title": A descriptive name for the Lua script file (e.g., 'questHelper.lua').
        - "description": A 1-sentence explanation of this specific script's role.
        - "scriptCode": The complete OpenMW Lua script code with PERFECT syntax. USE ONLY VERIFIED OPENMW API CALLS.
        - "category": One of: NPC, Object, Quest, Utility, Combat, Magic, Other.
        - "implementationNotes": A single string containing a bulleted list of step-by-step instructions for installing this script in OpenMW (e.g., file placement, cfg modifications).
      ${nexusPromptSegment}`;
    },

    MWSE: async () => {
      const previousFixes = await ScriptFix.list('-created_date', 25);
      const mwseFixes = previousFixes.filter(fix => fix.game === "MWSE" && fix.userValidated);
      
      const learningContext = mwseFixes.length > 0 ? `
      LEARN FROM THESE VALIDATED FIXES FOR MWSE:
      Previous users have encountered these issues and successful solutions in MWSE Lua scripts:
      ${mwseFixes.slice(0, 10).map((fix, i) => `
      Issue ${i + 1}:
      - Problem Type: ${fix.problemType} in ${fix.scriptCategory} scripts
      - Error Pattern: ${fix.errorPattern}
      - Solution: ${fix.solution}
      `).join('\n')}
      
      APPLY THIS KNOWLEDGE to avoid these common MWSE Lua scripting mistakes.
      ` : '';

      return `You are an expert in MWSE (Morrowind Script Extender) Lua scripting. MWSE extends Morrowind's scripting capabilities with powerful Lua APIs. Your task is to translate a user's plain English request into a functional MWSE Lua script project.

      CRITICAL SYNTAX REQUIREMENTS - THIS IS ABSOLUTELY ESSENTIAL:
      1. EXACT MWSE LUA API: Use only verified MWSE functions:
         - mwse, tes3, event, timer, config, ui
         - event.register("eventName", callback)
         - tes3.player, tes3.getObject, tes3.addItem
         - tes3ui.create functions for UI
         - Proper event handling patterns
      
      2. PERFECT LUA STRUCTURE FOR MWSE:
         - Proper event registration syntax
         - Correct callback function definitions
         - Valid MWSE configuration patterns
         - Proper error handling where needed
      
      3. LEARNING LIBRARY ADHERENCE:
         - The user has provided learning files containing VERIFIED working MWSE Lua scripts
         - STUDY these files as your PRIMARY reference for correct MWSE API usage
         - MIMIC the exact patterns, event handling, and API calls shown
         - Treat these files as the AUTHORITATIVE source for proper MWSE scripting
      
      Key MWSE Concepts to Follow:
      - MWSE Lua provides extensive APIs: mwse, tes3, event, timer, config, ui, etc.
      - Use event-driven programming with proper event handlers (e.g., event.register())
      - Scripts typically go in 'Data Files/MWSE/mods/[ModName]/' directory
      - Use proper MWSE naming conventions and mod structure (main.lua, config.lua, etc.)
      - Leverage MWSE's UI framework for MCM (Mod Configuration Menu) integration
      - Use tes3.* functions for game world interaction and data access
      
      ${learningContext}
      ${imageContextPromptSegment}
      
      REMEMBER: This code will run in MWSE's Lua environment with Morrowind. It MUST use valid MWSE API calls and proper event-driven patterns.
      
      Return a JSON object containing a "project" with:
      - "projectName": A short, descriptive name for the overall mod project.
      - "projectDescription": A 1-2 sentence explanation of what the whole mod project does.
      - "scripts": An array of script objects. Each script object must have:
        - "title": A descriptive name for the Lua script file (e.g., 'main.lua', 'config.lua').
        - "description": A 1-sentence explanation of this specific script's role.
        - "scriptCode": The complete MWSE Lua script code with PERFECT syntax. USE ONLY VERIFIED MWSE API CALLS.
        - "category": One of: NPC, Object, Quest, Utility, Combat, Magic, Other.
        - "implementationNotes": A single string containing a bulleted list of step-by-step instructions for installing this MWSE mod (e.g., directory structure, file placement).
      ${nexusPromptSegment}`;
    }
  };

  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const validTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      setError("Please upload a valid image file (PNG, JPEG, GIF, JPG, or WebP).");
      setUploadedFile(null);
      setUploadedFileUrl(null);
      return;
    }

    const maxSize = 10 * 1024 * 1024;
    if (file.size > maxSize) {
      setError("Image file too large. Please upload an image under 10MB.");
      setUploadedFile(null);
      setUploadedFileUrl(null);
      return;
    }

    setIsUploading(true);
    setError(null);
    setUploadedFile(file);

    try {
      const { file_url } = await UploadFile({ file });
      setUploadedFileUrl(file_url);
    } catch (e) {
      setError("Failed to upload image. Please try a different image file.");
      console.error("Upload error:", e);
    } finally {
      setIsUploading(false);
    }
  };

  const removeFile = () => {
    setUploadedFile(null);
    setUploadedFileUrl(null);
    setError(null);
    if (imageInputRef.current) {
      imageInputRef.current.value = ''; // Clear the input field
    }
  };

  const handleLearningFilesChange = async (event) => {
    // CRITICAL DEBUGGING STEP
    console.log("--- FOLDER SELECTION EVENT ---");
    console.log("event.target.files:", event.target.files);

    const files = Array.from(event.target.files);
    if (!files.length) {
      console.log("No files were received from the folder selection.");
      return;
    }
    console.log(`Received ${files.length} files from the browser.`);
    
    // Log some file paths for debugging
    console.log("Sample file paths:", files.slice(0, 3).map(f => ({ name: f.name, path: f.webkitRelativePath })));

    let tempErrorMessages = [];
    let tempSuccessMessages = [];

    // Filter out duplicates based on file name from already displayed/tracked learningFiles
    const existingFileNames = learningFiles.map(f => f.name);
    const newFilesToProcess = files.filter(file => !existingFileNames.includes(file.name));
    const duplicateFiles = files.filter(file => existingFileNames.includes(file.name));

    if (duplicateFiles.length > 0) {
      const duplicateNames = duplicateFiles.map(f => f.name).slice(0, 5).join(', ');
      tempErrorMessages.push(`Skipped ${duplicateFiles.length} duplicate file(s): ${duplicateNames}${duplicateFiles.length > 5 ? '...' : ''}.`);
      console.log(`Filtered out ${duplicateFiles.length} duplicate files`);
    }

    if (newFilesToProcess.length === 0) {
      console.log("No new unique files to add after filtering duplicates.");
      // If only duplicates were selected, update error and clear input
      if (tempErrorMessages.length > 0) {
        setError(tempErrorMessages.join('\n\n'));
      } else {
        setError(null); // Clear any previous error if nothing happened
      }
      if (learningFilesInputRef.current) {
        learningFilesInputRef.current.value = '';
      }
      setIsFileAnalysisLoading(false);
      return;
    }

    console.log(`Adding ${newFilesToProcess.length} new unique files (${duplicateFiles.length} duplicates filtered out)`);

    // IMMEDIATELY show new files in UI BEFORE any validation - this ensures visual feedback
    // Update `learningFiles` which triggers re-render, so `learningFiles.length` below will be correct for *display*
    setLearningFiles(prev => [...prev, ...newFilesToProcess]);
    setFileAnalysisReport(null); // Clear previous report, as new files mean new analysis
    console.log('New unique files IMMEDIATELY added to UI state, now checking validation...');

    const validTypes = [
      'text/plain', 'text/markdown', 'application/pdf',
      'application/json', 'text/html', 'text/xml'
    ];
    const maxSize = 10 * 1024 * 1024; // 10MB per file
    const maxFiles = 50; 

    let validationWarnings = [];
    let validFilesForUpload = [];

    // Calculate total files that would be displayed *if all passed validation and were unique*
    // This assumes `learningFiles` has updated, but useState updates are asynchronous.
    // For this calculation, it's safer to base it on the current `learningFiles` length + `newFilesToProcess` length.
    const currentTotalFilesForDisplay = learningFiles.length + newFilesToProcess.length; 
    
    // Check if total files for display exceeds max processing limit
    if (currentTotalFilesForDisplay > maxFiles) {
      // This is a warning that some files *won't be processed for AI analysis* even if displayed.
      tempErrorMessages.push(`You have selected ${currentTotalFilesForDisplay} files in total. The AI will analyze up to ${maxFiles} files for learning purposes. Files beyond this limit may still appear in the list but will not be used by the AI.`);
    }


    for (const file of newFilesToProcess) { 
      if (file.type === 'application/zip') {
        validationWarnings.push(`${file.name}: Zip files are not supported for upload. Please unzip and upload individual script or text files.`);
        continue;
      }
      
      const isTextFile = validTypes.includes(file.type) || 
                        file.name.toLowerCase().endsWith('.lua') || 
                        file.name.toLowerCase().endsWith('.js') ||
                        file.name.toLowerCase().endsWith('.py') ||
                        file.name.toLowerCase().endsWith('.txt') ||
                        file.name.toLowerCase().endsWith('.md') ||
                        file.name.toLowerCase().endsWith('.json');
      
      if (!isTextFile) {
        validationWarnings.push(`${file.name}: Unsupported file type. Only text files, common script types (.lua, .js, .py), markdown, JSON, and PDF are uploaded.`);
        continue;
      }
      
      if (file.size > maxSize) {
        validationWarnings.push(`${file.name}: File too large (${(file.size / 1024 / 1024).toFixed(1)}MB). Max 10MB per file.`);
        continue;
      }

      validFilesForUpload.push(file);
    }

    if (validationWarnings.length > 0) {
      const warningMessage = `Some newly selected files have issues:\n${validationWarnings.slice(0, 5).join('\n')}${validationWarnings.length > 5 ? `\n...and ${validationWarnings.length - 5} more issues.` : ''}`;
      tempErrorMessages.push(warningMessage);
    }

    console.log(`${validFilesForUpload.length} out of ${newFilesToProcess.length} new unique files passed validation and will be considered for upload.`);

    // Determine how many files we can still upload given the maxFiles limit and already uploaded URLs
    const alreadyUploadedCount = learningFileUrls.length; // This is the count of *actually uploaded* URLs
    const availableSlots = maxFiles - alreadyUploadedCount; 
    const filesToActuallyUpload = validFilesForUpload.slice(0, Math.max(0, availableSlots)); 

    if (filesToActuallyUpload.length > 0) {
      setIsUploadingLearningFiles(true);

      const batchId = `batch_${Date.now()}_${Math.random().toString(36).substring(2)}`;
      const successfullyUploadedUrls = [];
      const successfullyUploadedFiles = [];
      const failedUploads = [];

      try {
        for (const file of filesToActuallyUpload) { 
          try {
            console.log(`Attempting to upload: ${file.name}`);
            const { file_url } = await UploadFile({ file });
            console.log(`Successfully uploaded: ${file.name} to ${file_url}`);
            
            await LearningFile.create({
              fileName: file.name,
              fileUrl: file_url,
              relativePath: file.webkitRelativePath || file.name, // Add folder structure support
              game: learningFileGame,
              fileType: file.name.split('.').pop() || 'unknown',
              size: file.size,
              aiAnalysisReportId: batchId
            });

            successfullyUploadedUrls.push(file_url);
            successfullyUploadedFiles.push(file);

          } catch (uploadError) {
            console.error(`Failed to upload ${file.name}:`, uploadError);
            failedUploads.push({
              fileName: file.name,
              error: uploadError.message || 'Unknown upload error'
            });
          }
        }

        setLearningFileUrls(prev => [...prev, ...successfullyUploadedUrls]);

        if (successfullyUploadedFiles.length > 0) {
          tempSuccessMessages.push(`Successfully uploaded ${successfullyUploadedFiles.length} of ${filesToActuallyUpload.length} eligible file(s) to the '${learningFileGame}' library.${failedUploads.length > 0 ? ` ${failedUploads.length} files failed to upload.` : ' The AI is reviewing them...'}`);
        }

        if (failedUploads.length > 0) {
          const failedFileNames = failedUploads.map(f => f.fileName).join(', ');
          tempErrorMessages.push(`Failed to upload: ${failedFileNames}. Please try uploading these files again or check if they're corrupted.`);
        }
        
        if (successfullyUploadedUrls.length > 0) {
          console.log(`Starting analysis for ${successfullyUploadedFiles.length} successfully uploaded files`);
          // totalFiles argument to analyzeLearningFiles should be the actual total count displayed
          analyzeLearningFiles(successfullyUploadedUrls, successfullyUploadedFiles, currentTotalFilesForDisplay, batchId);
        } else {
          console.log('No new eligible files were successfully uploaded, skipping AI analysis for this batch.');
          setIsFileAnalysisLoading(false);
        }

      } catch (e) {
        console.error("Unexpected error during upload process:", e);
        tempErrorMessages.push(`An unexpected error occurred during the upload process. Please try again.`);
      } finally {
        setIsUploadingLearningFiles(false);
        if (learningFilesInputRef.current) {
          learningFilesInputRef.current.value = ''; 
        }
      }
    } else {
      console.log('No valid files to upload in this batch, or max file limit reached. All unique selected files are displayed.');
      if (learningFilesInputRef.current) {
        learningFilesInputRef.current.value = '';
      }
      setIsFileAnalysisLoading(false);
    }

    // Final consolidated error and success messages
    if (tempErrorMessages.length > 0) {
      setError(tempErrorMessages.join('\n\n'));
    } else {
      setError(null); 
    }
    if (tempSuccessMessages.length > 0) {
      setSuccess(tempSuccessMessages.join('\n\n'));
      setTimeout(() => setSuccess(null), 5000); // Clear success after 5 seconds
    } else {
      setSuccess(null); 
    }
  };

  const analyzeLearningFiles = async (fileUrlsToAnalyze, filesToAnalyze, totalFiles, batchId) => {
    setIsFileAnalysisLoading(true);
    setFileAnalysisReport(null); 
    
    console.log('Starting AI analysis for uploaded files...');
    
    // Determine which files are actually suitable for direct AI content analysis (not just context)
    const analyzableFilesForReport = filesToAnalyze.filter(f => 
      f.name.toLowerCase().endsWith('.txt') ||
      f.name.toLowerCase().endsWith('.md') ||
      f.name.toLowerCase().endsWith('.pdf') ||
      f.name.toLowerCase().endsWith('.json') ||
      f.name.toLowerCase().endsWith('.html') ||
      f.name.toLowerCase().endsWith('.xml')
    );

    if (analyzableFilesForReport.length === 0) {
      // No files can be analyzed for a detailed report, but they'll still be used as context.
      const defaultReport = {
        overallAssessment: `Files uploaded successfully to the '${learningFileGame}' library. While these script files cannot be analyzed directly for a detailed report, they will be used as valuable context when generating new scripts.`,
        keyLearnings: ["Files are available as learning context", "Script generation will reference these files", "Upload successful - ready for script creation"],
        qualityScore: 7,
        recommendations: "For a detailed AI analysis report, try uploading .txt, .md, .pdf, or .json versions of your scripts. However, the current files will still significantly help improve script generation."
      };
      
      try {
        // Save the default report
        await AILearningReport.create({
          batchId: batchId,
          game: learningFileGame,
          fileCount: totalFiles,
          analyzedFileNames: [], // No files could be analyzed for report
          overallAssessment: defaultReport.overallAssessment,
          keyLearnings: defaultReport.keyLearnings,
          qualityScore: defaultReport.qualityScore,
          recommendations: defaultReport.recommendations
        });
      } catch (reportError) {
        console.error('Failed to save default analysis report:', reportError);
      }
      
      setFileAnalysisReport(defaultReport);
      setIsFileAnalysisLoading(false);
      setError(null); // Clear any previous error if we're giving a default report
      return;
    }
    
    const fileNames = analyzableFilesForReport.map(f => f.name).join(', ');
    const analysisPrompt = `You are a Modding Learning Material Assessor. Your task is to analyze the content of the files provided by the user and give them feedback. The user has uploaded the following files for the '${learningFileGame}' category that can be analyzed: ${fileNames}.

    ${analyzableFilesForReport.length < filesToAnalyze.length ? `Note: The user uploaded ${filesToAnalyze.length} total files, but only ${analyzableFilesForReport.length} are suitable for direct content analysis. The others (likely script files) are still uploaded and will be used as contextual reference.` : ''}

    Please review the content of these files and provide a report. The goal is to determine how useful these files are for teaching you about Elder Scrolls modding, specifically for '${learningFileGame}'. Focus on extracting actionable insights for script generation.

    Return a JSON object with:
    - "overallAssessment": A 1-2 sentence summary of the files' purpose and quality.
    - "keyLearnings": An array of 3-5 specific, key takeaways or patterns you learned from these files (e.g., "Learned the proper syntax for TES3MP event listeners," "Identified a common pattern for defining local variables in Papyrus," etc.).
    - "qualityScore": A score from 1 to 10 on how useful these files are for learning, with 1 being "not useful" and 10 being "extremely useful reference material".
    - "recommendations": A brief suggestion on what other types of files would be helpful, or how these files could be improved.`;

    try {
      // Filter fileUrlsToAnalyze to only include those corresponding to analyzableFilesForReport
      const urlsForAnalysisPrompt = fileUrlsToAnalyze.filter((url, index) => {
        return analyzableFilesForReport.some(f => url.includes(f.name)); // Simple check, might need more robust matching for real systems
      });


      const result = await InvokeLLM({
        prompt: analysisPrompt,
        file_urls: urlsForAnalysisPrompt.length > 0 ? urlsForAnalysisPrompt : fileUrlsToAnalyze, // Use filtered URLs if possible, else all uploaded
        response_json_schema: {
          type: "object",
          properties: {
            overallAssessment: { type: "string" },
            keyLearnings: { type: "array", items: { type: "string" } },
            qualityScore: { type: "number" },
            recommendations: { type: "string" }
          },
          required: ["overallAssessment", "keyLearnings", "qualityScore", "recommendations"]
        }
      });
      
      console.log('AI analysis completed successfully');
      
      // Save the AI analysis report
      await AILearningReport.create({
        batchId: batchId,
        game: learningFileGame,
        fileCount: totalFiles,
        analyzedFileNames: analyzableFilesForReport.map(f => f.name), // Only list files that were part of the detailed analysis
        overallAssessment: result.overallAssessment,
        keyLearnings: result.keyLearnings,
        qualityScore: result.qualityScore,
        recommendations: result.recommendations
      });
      
      setFileAnalysisReport(result);
      setError(null); // Clear any previous error if analysis succeeds
    } catch(analysisError) {
      console.error("AI analysis error:", analysisError);
      setError("The AI failed to analyze some of the uploaded files. They will still be used as context for script generation, but a detailed analysis report could not be generated.");
      setFileAnalysisReport(null); // Ensure report is null on error
    } finally {
      setIsFileAnalysisLoading(false);
    }
  };

  const removeLearningFile = (indexToRemove) => {
    // We need to match by name/URL to correctly remove from learningFileUrls as well
    const fileToRemove = learningFiles[indexToRemove];
    
    // Remove from the displayed list
    const newFiles = learningFiles.filter((_, index) => index !== indexToRemove);
    setLearningFiles(newFiles);

    // If the file removed was also successfully uploaded, remove its URL
    if (fileToRemove && fileToRemove.name) {
      setLearningFileUrls(prevUrls => prevUrls.filter(url => !url.includes(fileToRemove.name)));
    }
    
    if (newFiles.length === 0) {
      setFileAnalysisReport(null);
      if (learningFilesInputRef.current) {
        learningFilesInputRef.current.value = '';
      }
    }
  };

  const removeAllLearningFiles = () => {
    setLearningFiles([]);
    setLearningFileUrls([]);
    setFileAnalysisReport(null); // Also clear the report
    if (learningFilesInputRef.current) {
      learningFilesInputRef.current.value = ''; // Clear the input field
    }
  };

  const handleStartDiscussion = async () => {
    if (!prompt.trim()) {
      setError("Please enter a description for the script.");
      return;
    }
    
    setIsAnalyzing(true);
    setError(null);
    setCurrentDiscussion(null);
    setDiscussionHistory([]);

    const discussionPrompt = `You are an expert in ${selectedGame} scripting and modding. A user wants to create a script and has provided their request. Your job is to analyze their request, provide helpful insights, and guide them toward the best implementation.
    ${imageContextPromptSegment}
    User's request: "${prompt}"
    Target game: ${selectedGame}

    Please analyze this request and provide guidance. Return a JSON object with:
    - "feasible": boolean (is this request technically possible in ${selectedGame}?)
    - "limitations": array of strings (any technical limitations or challenges)
    - "suggestions": array of strings (improvements or alternative approaches)
    - "questions": array of strings (clarifying questions to ask the user)
    - "considerations": array of strings (important things the user should know)
    - "complexity": string ("Simple", "Moderate", "Complex", or "Advanced")

    Be helpful, specific, and educational. Focus on ${selectedGame}'s capabilities and limitations.`;

    try {
      const requestData = {
        prompt: discussionPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            feasible: { type: "boolean" },
            limitations: { type: "array", items: { type: "string" } },
            suggestions: { type: "array", items: { type: "string" } },
            questions: { type: "array", items: { type: "string" } },
            considerations: { type: "array", items: { type: "string" } },
            complexity: { type: "string" }
          },
          required: ["feasible", "limitations", "suggestions", "questions", "considerations", "complexity"]
        }
      };

      // Include both context image and learning files
      const allFileUrls = [];
      if (uploadedFileUrl) allFileUrls.push(uploadedFileUrl);
      if (learningFileUrls.length > 0) allFileUrls.push(...learningFileUrls);
      
      if (allFileUrls.length > 0) {
        requestData.file_urls = allFileUrls;
      }

      const result = await InvokeLLM(requestData);
      
      setCurrentDiscussion(result);
      setDiscussionHistory([{ type: 'analysis', content: result, timestamp: Date.now() }]);
      setPhase("discussion");

    } catch (e) {
      setError("Failed to analyze request. Please try again.");
      console.error(e);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleDiscussionResponse = async (response) => {
    setIsAnalyzing(true);
    
    const conversationHistory = discussionHistory.map(item => {
      if (item.type === 'analysis') {
        return `AI Analysis: Feasible: ${item.content.feasible}, Complexity: ${item.content.complexity}
        Limitations: ${item.content.limitations.join(', ')}
        Suggestions: ${item.content.suggestions.join(', ')}
        Questions: ${item.content.questions.join(', ')}`;
      } else if (item.type === 'user_response') {
        return `User Response: ${item.content}`;
      } else if (item.type === 'ai_followup') {
        return `AI Response: ${item.content}`;
      }
      return '';
    }).join('\n\n');

    const followupPrompt = `You are continuing a discussion about a ${selectedGame} script request.

    Original request: "${prompt}"
    
    Previous conversation:
    ${conversationHistory}
    
    User's latest response: "${response}"
    
    Please provide a helpful follow-up response. Address their concerns, answer questions, and provide additional guidance. Keep it concise but informative.
    
    Return a JSON object with:
    - "response": string (your response to the user)
    - "readyToGenerate": boolean (do you think we have enough info to generate a good script?)
    - "additionalSuggestions": array of strings (any new suggestions based on their response)`;

    try {
      const requestData = {
        prompt: followupPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            response: { type: "string" },
            readyToGenerate: { type: "boolean" },
            additionalSuggestions: { type: "array", items: { type: "string" } }
          },
          required: ["response", "readyToGenerate"]
        }
      };

      if (uploadedFileUrl) {
        requestData.file_urls = [uploadedFileUrl];
      }

      const result = await InvokeLLM(requestData);

      const newHistory = [
        ...discussionHistory,
        { type: 'user_response', content: response, timestamp: Date.now() },
        { type: 'ai_followup', content: result.response, readyToGenerate: result.readyToGenerate, suggestions: result.additionalSuggestions || [], timestamp: Date.now() }
      ];
      
      setDiscussionHistory(newHistory);
    } catch (e) {
      setError("Failed to continue discussion. Please try again.");
      console.error(e);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleGenerateScript = async () => {
    setIsGenerating(true);
    setError(null);
    setGeneratedProject(null);

    const conversationContext = discussionHistory.length > 0 ? discussionHistory.map(item => {
      if (item.type === 'analysis') {
        return `Initial Analysis - Complexity: ${item.content.complexity}. Key considerations: ${item.content.considerations.join(', ')}`;
      } else if (item.type === 'user_response') {
        return `User clarification: ${item.content}`;
      } else if (item.type === 'ai_followup') {
        return `AI guidance: ${item.content}`;
      }
      return '';
    }).join(' ') : '';

    try {
      // Fetch ALL learning files from the library for this game
      const allLearningFiles = await LearningFile.list('-created_date', 100);
      const gameSpecificFiles = allLearningFiles.filter(file => 
        file.game === selectedGame || file.game === 'Other'
      );

      // --- CRITICAL FIX: Define supported file types for AI analysis ---
      // These are file types whose *content* can be read and analyzed by the LLM.
      // Script files like .lua, .js, .py are *referenced* for syntax but not directly read for content analysis due to LLM limitations.
      const supportedFileTypesForAnalysis = ['png', 'jpeg', 'jpg', 'gif', 'webp', 'txt', 'md', 'pdf', 'json', 'html', 'xml'];
      
      const analyzableLibraryFiles = gameSpecificFiles.filter(file => 
        file.fileType && supportedFileTypesForAnalysis.includes(file.fileType.toLowerCase())
      );
      const libraryFileUrlsForAnalysis = analyzableLibraryFiles.map(file => file.fileUrl);

      // Also get recent AI learning reports for this game
      const recentReports = await AILearningReport.list('-created_date', 10);
      const gameReports = recentReports.filter(report => 
        report.game === selectedGame || report.game === 'Other'
      );

      const gamePrompt = await gamePrompts[selectedGame]();
      
      const learningContext = gameSpecificFiles.length > 0 ? `
      CRITICAL: REFERENCE THE LEARNING LIBRARY
      You have access to ${gameSpecificFiles.length} reference file(s) from the community learning library for ${selectedGame}. Their filenames are: ${gameSpecificFiles.map(f => f.fileName).join(', ')}.
      
      Of these, you can directly analyze the content of ${analyzableLibraryFiles.length} files. The others are script files for contextual reference only.
      
      STUDY THE ANALYZABLE FILES CAREFULLY and incorporate their knowledge into your script generation.
      
      ${learningFileUrls.length > 0 ? `ADDITIONAL CONTEXT: The user has also provided ${learningFileUrls.length} file(s) as immediate context for this specific request.` : ''}
      ` : '';

      const reportsContext = gameReports.length > 0 ? `
      PREVIOUS AI ANALYSIS INSIGHTS:
      Based on previous analysis of learning materials, here are key insights for ${selectedGame}:
      ${gameReports.slice(0, 3).map((report, i) => `
      Analysis ${i + 1}:
      - Quality Assessment: ${report.overallAssessment}
      - Key Learnings: ${report.keyLearnings.slice(0, 3).join(', ')}
      - Recommendations: ${report.recommendations}
      `).join('\n')}
      
      Apply these insights to create better scripts.
      ` : '';

      const fullPrompt = `${gamePrompt}
      ${learningContext}
      ${reportsContext}
      Original user request: "${prompt}"
      
      Discussion context: ${conversationContext}
      
      Based on the learning library files, AI analysis insights, discussion context, and previous user fixes, generate the most appropriate ${selectedGame} script project:`;

      const requestData = {
        prompt: fullPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            project: {
              type: "object",
              properties: {
                projectName: { type: "string" },
                projectDescription: { type: "string" },
                scripts: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      title: { type: "string" },
                      description: { type: "string" },
                      scriptCode: { type: "string" },
                      category: { type: "string" },
                      implementationNotes: { type: "string" }
                    },
                    required: ["title", "description", "scriptCode", "category", "implementationNotes"]
                  }
                },
                nexusDescription: { type: "string" }
              },
              required: ["projectName", "projectDescription", "scripts", "nexusDescription"]
            }
          },
          required: ["project"]
        }
      };

      // --- CRITICAL FIX: Combine ONLY supported file URLs for the API call ---
      const allFileUrlsForAnalysis = [];
      if (uploadedFileUrl) { // User's context image is always supported
          allFileUrlsForAnalysis.push(uploadedFileUrl);
      }
      
      // Filter session-uploaded files to only include supported types
      const analyzableSessionFileUrls = learningFileUrls.filter(url => {
        // Find the original File object that corresponds to this URL
        const matchingFile = learningFiles.find(file => url.includes(file.name));
        
        if (matchingFile) {
          const extension = (matchingFile.name.split('.').pop() || '').toLowerCase();
          return supportedFileTypesForAnalysis.includes(extension);
        }
        return false;
      });

      // Add the filtered URLs to the final list
      if (analyzableSessionFileUrls.length > 0) {
        allFileUrlsForAnalysis.push(...analyzableSessionFileUrls);
      }
      if (libraryFileUrlsForAnalysis.length > 0) {
        allFileUrlsForAnalysis.push(...libraryFileUrlsForAnalysis);
      }
      
      if (allFileUrlsForAnalysis.length > 0) {
        // Use a Set to remove duplicate URLs before making the call
        requestData.file_urls = [...new Set(allFileUrlsForAnalysis)];
      }

      const result = await InvokeLLM(requestData);
      
      // --- FIX STARTS HERE: Add validation and sanitization ---
      if (!result || !result.project) {
        throw new Error("The AI returned an invalid or incomplete project structure. Please try again.");
      }

      // Sanitize implementationNotes to prevent crashes if the AI returns an array.
      if (result.project && Array.isArray(result.project.scripts)) {
        result.project.scripts.forEach(script => {
          if (script && Array.isArray(script.implementationNotes)) {
            // Convert the array of notes into a single string with bullet points.
            script.implementationNotes = script.implementationNotes.map(note => `• ${note}`).join('\n');
          }
        });
      }
      // --- FIX ENDS HERE ---

      setGeneratedProject(result.project);
      setPhase("generated");
    } catch (e) {
      if (e.message && e.message.includes('Unsupported file type')) {
        setError("The AI failed to analyze a file. I have applied a fix to prevent this. Please try generating the script again.");
      } else {
        setError("Failed to generate script project. Please try again. Error: " + e.message); // Added error message for better debugging
      }
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveProject = async () => {
    if (!generatedProject || !generatedProject.scripts) return;
    
    setIsSaving(true);
    try {
      const projectId = `proj_${Date.now()}_${Math.random().toString(36).substring(2)}`;
      
      const scriptsToSave = generatedProject.scripts.map(script => ({
        ...script,
        game: selectedGame,
        originalPrompt: prompt,
        projectId: projectId,
        projectName: generatedProject.projectName,
        projectDescription: generatedProject.projectDescription,
      }));
      
      await GameScript.bulkCreate(scriptsToSave);
      setSuccess(`Project "${generatedProject.projectName}" with ${generatedProject.scripts.length} script(s) saved successfully to 'My Scripts'.`);
      setTimeout(() => setSuccess(null), 4000);
    } catch (e) {
      setError("Failed to save script project. Please try again.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleReset = () => {
    setPhase("input");
    setPrompt("");
    setDiscussionHistory([]);
    setCurrentDiscussion(null);
    setGeneratedProject(null);
    setError(null);
    setSuccess(null);
    setUploadedFile(null);
    setUploadedFileUrl(null);
    setIsUploading(false);
    setIsRecording(false);
    setLearningFiles([]);
    setLearningFileUrls([]);
    setIsUploadingLearningFiles(false);
    setIsFileAnalysisLoading(false); // Reset this
    setFileAnalysisReport(null); // Reset this
    setLearningFileGame("TES3MP"); // Reset game category
    if (imageInputRef.current) {
      imageInputRef.current.value = '';
    }
    if (learningFilesInputRef.current) {
      learningFilesInputRef.current.value = '';
    }
  };

  const handleVoiceToTextTranscript = (transcript) => {
    setPrompt(prevPrompt => {
      let newPrompt;
      if (!prevPrompt.trim()) {
        newPrompt = transcript;
      } else {
        newPrompt = prevPrompt.endsWith(' ') ? prevPrompt + transcript : prevPrompt + ' ' + transcript;
      }
      return newPrompt;
    });
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-yellow-200 mb-2">
          Unofficial TES Script Creator
        </h1>
        <p className="text-gray-400">AI-powered scripting for Morrowind, Oblivion, and Skyrim</p>
        {/* DEBUG: Show file count */}
        <p className="text-red-400 text-sm mt-2">DEBUG: Learning Files Count = {learningFiles.length}</p>
      </div>

      {phase === "input" && (
        <>
          <Card className="bg-gray-800/50 border-yellow-800/30">
            <CardHeader>
              <CardTitle className="text-yellow-300 text-xl flex items-center gap-3">
                <Wand2 className="w-6 h-6" />
                Create Your Script
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Target Game</label>
                <Select 
                  value={selectedGame} 
                  onValueChange={setSelectedGame} 
                  disabled={isRecording || isUploadingLearningFiles || isFileAnalysisLoading}
                >
                  <SelectTrigger id="game-select-trigger" className="bg-gray-900 border-yellow-800/50 text-gray-200">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Morrowind">The Elder Scrolls III: Morrowind</SelectItem>
                    <SelectItem value="Oblivion">The Elder Scrolls IV: Oblivion</SelectItem>
                    <SelectItem value="Skyrim">The Elder Scrolls V: Skyrim</SelectItem>
                    <SelectItem value="TES3MP">TES3MP (Morrowind Multiplayer)</SelectItem>
                    <SelectItem value="OpenMW">OpenMW Lua Scripting</SelectItem>
                    <SelectItem value="MWSE">MWSE (Morrowind Script Extender)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label htmlFor="script-description-input" className="block text-sm font-medium text-gray-300 mb-2">
                  Script Description
                </label>
                <div className="relative">
                  <Textarea
                    id="script-description-input"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder={`Describe what you want your ${selectedGame} script to do...`}
                    className="h-32 bg-gray-900 border-yellow-800/50 focus:border-yellow-600 text-gray-200 pr-10"
                    disabled={isRecording || isUploadingLearningFiles || isFileAnalysisLoading}
                  />
                  <div className="absolute bottom-2 right-2">
                    <VoiceToText
                      onTranscript={handleVoiceToTextTranscript}
                      isRecording={isRecording}
                      setIsRecording={setIsRecording}
                    />
                  </div>
                </div>
              </div>

              <div id="image-upload-area">
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Upload Image for Context (Optional)
                </label>
                <div className="flex items-center gap-4">
                  <Button
                    variant="outline"
                    className="border-gray-600 text-gray-300 hover:bg-gray-800"
                    disabled={isRecording || isUploadingLearningFiles || isFileAnalysisLoading}
                    onClick={() => imageInputRef.current.click()}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Choose File
                  </Button>
                  <Input 
                    ref={imageInputRef}
                    id="image-upload" 
                    type="file" 
                    className="hidden" 
                    onChange={handleFileChange}
                    accept="image/png, image/jpeg, image/jpg, image/gif, image/webp"
                    disabled={isRecording || isUploadingLearningFiles || isFileAnalysisLoading}
                  />
                  {isUploading && <Loader2 className="w-5 h-5 animate-spin text-gray-400" />}
                  {uploadedFile && !isUploading && (
                    <div className="flex items-center gap-2 text-sm text-gray-300">
                      <span>{uploadedFile.name}</span>
                      <Button variant="ghost" size="icon" onClick={removeFile} className="w-6 h-6 p-0 text-gray-400 hover:text-gray-200">
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </div>
                {uploadedFile && (
                  <div className="mt-4">
                    <img 
                      src={uploadedFileUrl || URL.createObjectURL(uploadedFile)} 
                      alt="Upload preview" 
                      className="max-h-40 rounded-md border border-gray-600 object-contain"
                    />
                  </div>
                )}
              </div>

              {/* Learning Files Section - MODIFIED */}
              <div className="border-t border-gray-700 pt-4">
                <label className="block text-sm font-medium text-yellow-300 mb-2">
                  📚 Help the AI Learn (Optional)
                </label>
                <p className="text-xs text-gray-400 mb-3">
                  Upload a folder of example scripts or documentation to the community library. This helps the AI learn and improves results for everyone. All files in the selected folder and its sub-folders will be uploaded.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1">Categorize for Game:</label>
                        <Select 
                          value={learningFileGame} 
                          onValueChange={setLearningFileGame}
                          disabled={isRecording || isUploadingLearningFiles || isFileAnalysisLoading}
                        >
                            <SelectTrigger className="bg-gray-900 border-yellow-800/50 text-gray-200">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="TES3MP">TES3MP</SelectItem>
                                <SelectItem value="OpenMW">OpenMW</SelectItem>
                                <SelectItem value="MWSE">MWSE</SelectItem>
                                <SelectItem value="Morrowind">Morrowind</SelectItem>
                                <SelectItem value="Oblivion">Oblivion</SelectItem>
                                <SelectItem value="Skyrim">Skyrim</SelectItem>
                                <SelectItem value="Other">Other</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </div>

                <div className="flex items-center gap-4">
                  <Button
                    variant="outline"
                    className="border-yellow-600 text-yellow-300 hover:bg-yellow-900/20"
                    disabled={isRecording || isUploadingLearningFiles || isFileAnalysisLoading}
                    onClick={() => learningFilesInputRef.current.click()}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    {isUploadingLearningFiles ? "Uploading..." : "Upload Folder"}
                  </Button>
                  <Input
                    ref={learningFilesInputRef}
                    id="learning-files"
                    type="file"
                    multiple
                    directory=""
                    webkitdirectory=""
                    className="hidden"
                    onChange={handleLearningFilesChange}
                    accept=".txt,.md,.lua,.js,.py,.json,.html,.xml,.pdf"
                    disabled={isRecording || isUploadingLearningFiles || isFileAnalysisLoading}
                  />
                  {isUploadingLearningFiles && <Loader2 className="w-5 h-5 animate-spin text-yellow-400" />}
                </div>

                {/* FIXED: Removed the !isUploadingLearningFiles condition so files show immediately */}
                {learningFiles.length > 0 && (
                  <div className="mt-4 space-y-2">
                    <div className="flex justify-between items-center">
                      <p className="text-sm font-medium text-gray-300">{learningFiles.length} file(s) selected:</p>
                      <Button variant="link" size="sm" onClick={removeAllLearningFiles} className="p-0 h-auto text-red-400 hover:text-red-300">
                        Clear All
                      </Button>
                    </div>
                    <ScrollArea className="h-40 w-full bg-black/30 p-2 rounded-md border border-gray-700">
                      <div className="space-y-2">
                        {learningFiles.map((file, index) => (
                          <div key={index} className="flex items-center justify-between p-2 bg-gray-800/50 rounded text-sm">
                            <span className="text-gray-300 truncate" title={file.name}>{file.name}</span>
                            <Button variant="ghost" size="icon" onClick={() => removeLearningFile(index)} className="w-6 h-6 p-0 text-gray-400 hover:text-gray-200 flex-shrink-0">
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                )}

                {isFileAnalysisLoading && (
                  <div className="mt-4 flex items-center gap-3 text-yellow-200">
                    <Loader2 className="w-5 h-5 animate-spin"/>
                    <span>AI is reviewing your files...</span>
                  </div>
                )}

                {fileAnalysisReport && (
                  <Card className="mt-4 bg-gray-900/30 border-yellow-700/40">
                    <CardHeader className="p-3 pb-2">
                      <CardTitle className="text-yellow-300 text-lg flex justify-between items-center">
                        AI Learning Report
                        <Button variant="ghost" size="icon" onClick={() => setFileAnalysisReport(null)} className="w-7 h-7 p-0 text-gray-400 hover:text-white">
                          <X className="w-4 h-4"/>
                        </Button>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-3 pt-0 space-y-3 text-sm">
                      <div>
                        <h4 className="font-semibold text-gray-300">Assessment:</h4>
                        <p className="text-gray-400 italic">"{fileAnalysisReport.overallAssessment}"</p>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-300">Key Learnings:</h4>
                        <ul className="list-disc list-inside space-y-1 text-gray-400 pl-4">
                          {fileAnalysisReport.keyLearnings.map((item, i) => <li key={i}>{item}</li>)}
                        </ul>
                      </div>
                      <div className="flex justify-between items-start gap-4">
                        <div className="flex-grow">
                          <h4 className="font-semibold text-gray-300">Recommendations:</h4>
                          <p className="text-gray-400">{fileAnalysisReport.recommendations}</p>
                        </div>
                        <div className="text-center flex-shrink-0">
                          <p className="font-semibold text-gray-300">Usefulness</p>
                          <p className="text-2xl font-bold text-yellow-400">{fileAnalysisReport.qualityScore}/10</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>

              <div id="start-discussion-button-container">
                <Button
                  id="start-discussion-button"
                  onClick={handleStartDiscussion}
                  disabled={isAnalyzing || isUploading || isRecording || isUploadingLearningFiles || isFileAnalysisLoading}
                  className="w-full bg-yellow-700 hover:bg-yellow-600 text-black font-bold text-lg py-6"
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Analyzing Request...
                    </>
                  ) : (
                    <>
                      <MessageSquare className="mr-2 h-5 w-5" />
                      Start AI Discussion
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          <GameExamples 
            selectedGame={selectedGame} 
            onExampleSelect={setPrompt} 
          />
        </>
      )}

      {phase === "discussion" && (
        <div id="discussion-panel-container">
          <DiscussionPanel
            game={selectedGame}
            originalPrompt={prompt}
            discussionHistory={discussionHistory}
            currentDiscussion={currentDiscussion}
            isAnalyzing={isAnalyzing}
            onResponse={handleDiscussionResponse}
            onGenerateScript={handleGenerateScript}
            onReset={handleReset}
            isGenerating={isGenerating}
          />
        </div>
      )}

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="border-green-600 bg-green-900/20">
          <AlertCircle className="h-4 w-4 text-green-400" />
          <AlertTitle className="text-green-400">Success</AlertTitle>
          <AlertDescription className="text-green-300">{success}</AlertDescription>
        </Alert>
      )}

      {phase === "generated" && generatedProject && (
        <div className="space-y-6">
          <ScriptProjectOutput project={generatedProject} />
          
          <NexusDescriptionOutput description={generatedProject.nexusDescription} />

          <div className="flex gap-3 items-center">
            <Button
              onClick={handleSaveProject}
              disabled={isSaving}
              className="bg-green-700 hover:bg-green-600"
            >
              {isSaving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save Project to My Scripts
                </>
              )}
            </Button>
            
            <Button
              variant="outline"
              onClick={handleReset}
              className="border-gray-600 text-gray-300 hover:bg-gray-800"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Create Another Project
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
