import Layout from "./Layout.jsx";

import Home from "./Home";

import MyScripts from "./MyScripts";

import ScriptDetail from "./ScriptDetail";

import NexusDescriptionGenerator from "./NexusDescriptionGenerator";

import LearningLibrary from "./LearningLibrary";

import AIScriptForge from "./AIScriptForge";

import SoundIDReference from "./SoundIDReference";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    MyScripts: MyScripts,
    
    ScriptDetail: ScriptDetail,
    
    NexusDescriptionGenerator: NexusDescriptionGenerator,
    
    LearningLibrary: LearningLibrary,
    
    AIScriptForge: AIScriptForge,
    
    SoundIDReference: SoundIDReference,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/MyScripts" element={<MyScripts />} />
                
                <Route path="/ScriptDetail" element={<ScriptDetail />} />
                
                <Route path="/NexusDescriptionGenerator" element={<NexusDescriptionGenerator />} />
                
                <Route path="/LearningLibrary" element={<LearningLibrary />} />
                
                <Route path="/AIScriptForge" element={<AIScriptForge />} />
                
                <Route path="/SoundIDReference" element={<SoundIDReference />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}