

import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ScrollText, Wand2, Library, Settings, FileText, BrainCircuit, ListMusic } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Badge } from "@/components/ui/badge"; // Added Badge import
import SplashPage from "@/components/SplashPage";
import AppTutorial from "@/components/AppTutorial";
import { User } from "@/api/entities";

const navigationItems = [
  {
    title: "Script Generator",
    url: createPageUrl("Home"),
    icon: Wand2,
  },
  {
    title: "My Scripts",
    url: createPageUrl("MyScripts"),
    icon: Library,
  },
  {
    title: "Learning Library",
    url: createPageUrl("LearningLibrary"),
    icon: BrainCircuit,
  },
  {
    title: "Sound ID Reference",
    url: createPageUrl("SoundIDReference"),
    icon: ListMusic,
  },
  {
    title: "AI Script Forge", // New item
    url: createPageUrl("AIScriptForge"),
    icon: Settings,
    adminOnly: true,
  },
  {
    title: "Nexus Desc. Generator",
    url: createPageUrl("NexusDescriptionGenerator"),
    icon: FileText,
  },
];

export default function Layout({ children }) {
  const location = useLocation();
  const [showSplash, setShowSplash] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  // Load current user
  useEffect(() => {
    const loadCurrentUser = async () => {
      try {
        const user = await User.me(); 
        setCurrentUser(user);
      } catch (error) {
        // User not logged in or error, ignore and set currentUser to null
        console.error("Failed to load user:", error);
        setCurrentUser(null);
      }
    };
    loadCurrentUser();
  }, []);

  // Check if splash has been shown in this session
  useEffect(() => {
    const splashShown = sessionStorage.getItem('splashShown');
    if (!splashShown) {
      setShowSplash(true);
    }
  }, []);

  const handleSplashFinish = () => {
    setShowSplash(false);
    sessionStorage.setItem('splashShown', 'true');

    // Check if tutorial should be shown after splash
    const tutorialCompleted = localStorage.getItem('tutorialCompleted');
    const jiubTutorialCompleted = localStorage.getItem('hasCompletedJiubTutorial');
    if (!tutorialCompleted && !jiubTutorialCompleted) {
      setShowTutorial(true);
    }
  };

  const handleTutorialFinish = () => {
    setShowTutorial(false);
    localStorage.setItem('tutorialCompleted', 'true');
    localStorage.setItem('hasCompletedJiubTutorial', 'true');
  };

  const restartTutorial = () => {
    localStorage.removeItem('tutorialCompleted');
    localStorage.removeItem('hasCompletedJiubTutorial');
    sessionStorage.removeItem('splashShown');
    window.location.href = createPageUrl('Home');
  };

  if (showSplash) {
    return <SplashPage onFinish={handleSplashFinish} />;
  }

  return (
    <SidebarProvider>
      {/* Tutorial Overlay */}
      {showTutorial && (
        <AppTutorial onFinish={handleTutorialFinish} />
      )}
      
      <div className="min-h-screen flex w-full magical-bg text-gray-200 font-serif">
        <style jsx>{`
          :root {
            --magical-deep-purple: #1a0b2e;
            --magical-purple: #2d1b4e;
            --magical-lavender: #4c2a85;
            --magical-gold: #f4d03f;
            --magical-amber: #f39c12;
            --magical-silver: #bdc3c7;
            --magical-glow-purple: #8b5fbf;
            --magical-glow-gold: #f1c40f;
          }

          @keyframes sparkle {
            0%, 100% { opacity: 0; transform: scale(0.8); }
            50% { opacity: 1; transform: scale(1.2); }
          }

          @keyframes sparkleFloat {
            0%, 100% { 
              opacity: 0; 
              transform: translateY(10px) scale(0.5);
            }
            25% { 
              opacity: 0.8; 
              transform: translateY(-5px) scale(1);
            }
            50% { 
              opacity: 1; 
              transform: translateY(-15px) scale(1.2);
            }
            75% { 
              opacity: 0.6; 
              transform: translateY(-8px) scale(0.8);
            }
          }

          @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
          }

          @keyframes cardSparkle1 {
            0%, 100% { opacity: 0; }
            20% { opacity: 0.8; }
            40% { opacity: 0; }
          }

          @keyframes cardSparkle2 {
            0%, 100% { opacity: 0; }
            30% { opacity: 0.6; }
            60% { opacity: 0; }
          }

          @keyframes cardSparkle3 {
            0%, 100% { opacity: 0; }
            10% { opacity: 0.9; }
            50% { opacity: 0; }
          }

          @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
          }

          @keyframes magicalGlow {
            0%, 100% { box-shadow: 0 0 20px rgba(139, 95, 191, 0.3); }
            50% { box-shadow: 0 0 40px rgba(139, 95, 191, 0.6); }
          }

          @keyframes twinkle {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 1; }
          }

          .magical-bg {
            background: linear-gradient(135deg, #0f0517 0%, #1a0b2e 25%, #2d1b4e 50%, #1a0b2e 75%, #0f0517 100%);
            position: relative;
          }

          .magical-bg::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
              radial-gradient(circle at 20% 80%, rgba(139, 95, 191, 0.1) 1px, transparent 1px),
              radial-gradient(circle at 80% 20%, rgba(244, 208, 63, 0.1) 1px, transparent 1px),
              radial-gradient(circle at 40% 40%, rgba(139, 95, 191, 0.08) 1px, transparent 1px),
              radial-gradient(circle at 90% 70%, rgba(244, 208, 63, 0.08) 1px, transparent 1px),
              radial-gradient(circle at 60% 90%, rgba(139, 95, 191, 0.06) 1px, transparent 1px);
            background-size: 300px 300px, 200px 200px, 400px 400px, 250px 250px, 350px 350px;
            animation: twinkle 4s infinite alternate;
            pointer-events: none;
            z-index: 0;
          }

          .rounded-lg.border.bg-card.text-card-foreground.shadow-sm,
          [data-card="true"],
          .bg-gray-800\\/50,
          .bg-stone-900\\/50,
          .bg-blue-900\\/20,
          .bg-red-900\\/20,
          .bg-green-900\\/20 {
            background: linear-gradient(145deg, rgba(45, 27, 78, 0.8) 0%, rgba(26, 11, 46, 0.9) 100%) !important;
            border: 1px solid rgba(139, 95, 191, 0.3) !important;
            backdrop-filter: blur(10px);
            border-radius: 16px !important;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
          }

          .rounded-lg.border.bg-card.text-card-foreground.shadow-sm:hover,
          [data-card="true"]:hover,
          .bg-gray-800\\/50:hover,
          .bg-stone-900\\/50:hover,
          .bg-blue-900\\/20:hover,
          .bg-red-900\\/20:hover,
          .bg-green-900\\/20:hover {
            border-color: rgba(139, 95, 191, 0.6) !important;
            box-shadow: 0 8px 32px rgba(139, 95, 191, 0.15), 0 0 0 1px rgba(139, 95, 191, 0.1) !important;
            transform: translateY(-2px);
          }

          .rounded-lg.border.bg-card.text-card-foreground.shadow-sm::before,
          [data-card="true"]::before,
          .bg-gray-800\\/50::before,
          .bg-stone-900\\/50::before,
          .bg-blue-900\\/20::before,
          .bg-red-900\\/20::before,
          .bg-green-900\\/20::before {
            content: '';
            position: absolute;
            top: 20%;
            left: 15%;
            width: 4px;
            height: 4px;
            background: radial-gradient(circle, #f4d03f 0%, transparent 70%);
            border-radius: 50%;
            animation: cardSparkle1 4s infinite ease-out;
            pointer-events: none;
            z-index: 2;
          }

          .rounded-lg.border.bg-card.text-card-foreground.shadow-sm::after,
          [data-card="true"]::after,
          .bg-gray-800\\/50::after,
          .bg-stone-900\\/50::after,
          .bg-blue-900\\/20::after,
          .bg-red-900\\/20::after,
          .bg-green-900\\/20::after {
            content: '';
            position: absolute;
            top: -2px;
            left: -2px;
            right: -2px;
            bottom: -2px;
            background: linear-gradient(
              45deg,
              transparent,
              rgba(139, 95, 191, 0.2),
              transparent
            );
            z-index: -1;
            animation: shimmer 3s infinite;
            opacity: 0;
            transition: opacity 0.3s ease;
            border-radius: 16px;
          }

          .rounded-lg.border.bg-card.text-card-foreground.shadow-sm:hover::after,
          [data-card="true"]:hover::after,
          .bg-gray-800\\/50:hover::after,
          .bg-stone-900\\/50:hover::after,
          .bg-blue-900\\/20:hover::after,
          .bg-red-900\\/20:hover::after,
          .bg-green-900\\/20:hover::after {
            opacity: 1;
          }

          [data-sidebar="sidebar"],
          .magical-sidebar,
          [data-sidebar] {
            background: linear-gradient(180deg, rgba(15, 5, 23, 0.95) 0%, rgba(26, 11, 46, 0.95) 100%) !important;
            border-right: 1px solid rgba(139, 95, 191, 0.4) !important;
            backdrop-filter: blur(15px);
            color: #e8e8e8 !important;
            width: 250px;
          }

          [data-sidebar] [data-sidebar-header],
          .magical-sidebar [data-sidebar-header] {
            background: rgba(26, 11, 46, 0.8) !important;
            border-bottom: 1px solid rgba(139, 95, 191, 0.3) !important;
          }

          [data-sidebar] [data-sidebar-content] {
            background: transparent !important;
          }

          .magical-nav-item {
            background: transparent;
            border-radius: 12px;
            transition: all 0.3s ease;
            position: relative;
            margin: 4px 0;
            color: #d1d5db !important;
          }

          .magical-nav-item:hover {
            background: rgba(139, 95, 191, 0.2) !important;
            transform: translateX(4px);
            color: #f4d03f !important;
          }

          .magical-nav-item.active {
            background: linear-gradient(135deg, rgba(139, 95, 191, 0.3) 0%, rgba(76, 42, 133, 0.4) 100%) !important;
            border: 1px solid rgba(139, 95, 191, 0.5);
            color: #f4d03f !important;
          }

          .magical-nav-item.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 4px;
            height: 60%;
            background: linear-gradient(180deg, var(--magical-gold) 0%, var(--magical-amber) 100%);
            border-radius: 0 4px 4px 0;
          }

          button {
            transition: all 0.3s ease;
          }

          .bg-yellow-700,
          .bg-green-700,
          .bg-blue-700,
          .bg-red-700 {
            background: linear-gradient(135deg, rgba(244, 208, 63, 0.9) 0%, rgba(243, 156, 18, 1) 100%) !important;
            border: 2px solid rgba(244, 208, 63, 0.5);
            color: #1a0b2e !important;
            font-weight: bold;
            border-radius: 12px;
            position: relative;
            overflow: hidden;
          }

          .bg-yellow-700:hover,
          .bg-green-700:hover,
          .bg-blue-700:hover,
          .bg-red-700:hover {
            background: linear-gradient(135deg, rgba(241, 196, 15, 1) 0%, rgba(244, 208, 63, 1) 100%) !important;
            box-shadow: 0 0 30px rgba(244, 208, 63, 0.6);
            transform: translateY(-2px);
          }

          input, textarea, select {
            background: rgba(26, 11, 46, 0.8) !important;
            border: 2px solid rgba(139, 95, 191, 0.3) !important;
            border-radius: 12px !important;
            color: #e8e8e8 !important;
            transition: all 0.3s ease;
          }

          input:focus, textarea:focus, select:focus {
            border-color: rgba(139, 95, 191, 0.8) !important;
            box-shadow: 0 0 20px rgba(139, 95, 191, 0.3) !important;
            background: rgba(26, 11, 46, 0.9) !important;
          }

          .inline-flex.items-center.rounded-full.border {
            background: linear-gradient(135deg, rgba(139, 95, 191, 0.8) 0%, rgba(76, 42, 133, 0.9) 100%) !important;
            border: 1px solid rgba(139, 95, 191, 0.5) !important;
            color: #e8e8e8 !important;
          }

          .border-green-600 {
            background: linear-gradient(135deg, rgba(39, 174, 96, 0.15) 0%, rgba(46, 204, 113, 0.2) 100%) !important;
            border: 1px solid rgba(39, 174, 96, 0.4) !important;
            color: #a8e6cf !important;
          }

          .border-red-600 {
            background: linear-gradient(135deg, rgba(231, 76, 60, 0.15) 0%, rgba(192, 57, 43, 0.2) 100%) !important;
            border: 1px solid rgba(231, 76, 60, 0.4) !important;
            color: #f5b7b1 !important;
          }

          ::-webkit-scrollbar {
            width: 8px;
          }

          ::-webkit-scrollbar-track {
            background: rgba(26, 11, 46, 0.5);
            border-radius: 4px;
          }

          ::-webkit-scrollbar-thumb {
            background: linear-gradient(180deg, rgba(139, 95, 191, 0.8) 0%, rgba(76, 42, 133, 0.9) 100%);
            border-radius: 4px;
          }

          ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(180deg, rgba(139, 95, 191, 1) 0%, rgba(76, 42, 133, 1) 100%);
          }

          .sparkle-effect {
            position: relative;
          }

          .sparkle-effect::after {
            content: '✨';
            position: absolute;
            top: -5px;
            right: -5px;
            font-size: 12px;
            animation: sparkle 2s infinite;
          }

          .floating-icon {
            animation: float 3s ease-in-out infinite;
          }
        `}</style>
        
        <Sidebar className="magical-sidebar">
          <SidebarHeader className="border-b border-purple-800/30 p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-br from-purple-900/50 to-indigo-900/50 rounded-xl border border-purple-700/50 sparkle-effect">
                <ScrollText className="w-6 h-6 text-yellow-300 floating-icon" />
              </div>
              <div>
                <h2 className="font-bold text-yellow-300 tracking-wider text-lg">Unofficial TES</h2>
                <h3 className="font-bold text-yellow-300 tracking-wider -mt-1">Script Creator</h3>
                <p className="text-xs text-purple-300 mt-1">✨ AI-Powered Modding Assistant ✨</p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-2">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-medium text-purple-400 uppercase tracking-wider px-2 py-3">
                ⚡ Magical Tools ⚡
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navigationItems.map((item) => {
                    // Hide admin-only items if user is not admin
                    if (item.adminOnly && (!currentUser || currentUser.role !== 'admin')) {
                      return null;
                    }
                    
                    return (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton 
                          asChild 
                          className={`magical-nav-item transition-all duration-300 ${
                            location.pathname === item.url ? 'active' : ''
                          }`}
                          id={
                            item.title === "Script Generator" ? "nav-script-generator" :
                            item.title === "My Scripts" ? "nav-my-scripts" :
                            item.title === "Learning Library" ? "nav-learning-library" :
                            item.title === "Sound ID Reference" ? "nav-sound-id-reference" :
                            item.title === "AI Script Forge" ? "nav-ai-script-forge" :
                            item.title === "Nexus Desc. Generator" ? "nav-nexus-generator" : ''
                          }
                        >
                          <Link to={item.url} className={`flex items-center gap-3 px-4 py-3 hover:text-yellow-300 ${
                              location.pathname === item.url ? 'text-yellow-300' : 'text-gray-300'
                            }`}>
                            <item.icon className="w-5 h-5" />
                            <span className="font-medium">{item.title}</span>
                            {item.adminOnly && ( // Badge for admin-only items
                              <Badge className="ml-auto bg-purple-900/50 text-purple-300 text-xs">
                                Admin
                              </Badge>
                            )}
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    );
                  })}
                  
                  {/* Tutorial Restart Button in Sidebar - Admin Only */}
                  {currentUser && currentUser.role === 'admin' && (
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild>
                        <button
                          onClick={restartTutorial}
                          className="flex items-center gap-3 px-4 py-3 text-purple-300 hover:text-yellow-300 magical-nav-item transition-all duration-300 w-full text-left"
                          id="nav-restart-tutorial"
                        >
                          <ScrollText className="w-5 h-5" />
                          <span className="font-medium text-sm">🔮 Jiub's Tutorial</span>
                        </button>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  )}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 flex flex-col relative z-10">
          <header className="bg-gradient-to-r from-purple-900/20 to-indigo-900/20 border-b border-purple-800/30 px-6 py-4 md:hidden backdrop-blur-lg">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-purple-700/30 p-2 rounded-lg transition-colors duration-200" />
              <h1 className="text-xl font-bold text-yellow-200 sparkle-effect">Unofficial TES Script Creator</h1>
            </div>
          </header>

          <div className="flex-1 overflow-auto p-4 md:p-8">
            <div className="max-w-6xl mx-auto">
              {children}
            </div>
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}

