import React, { useState, useEffect } from "react";
import { LearningFile } from "@/api/entities";
import { AILearningReport } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, FileText, Code, BrainCircuit, ExternalLink, FolderOpen, Folder, ChevronRight, ChevronDown } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import _ from 'lodash';

const gameColors = {
  Morrowind: "border-red-700/50 text-red-300",
  Oblivion: "border-blue-700/50 text-blue-300",
  Skyrim: "border-purple-700/50 text-purple-300",
  TES3MP: "border-teal-700/50 text-teal-300",
  OpenMW: "border-cyan-700/50 text-cyan-300",
  MWSE: "border-orange-700/50 text-orange-300",
  Other: "border-gray-500/50 text-gray-300"
};

// Helper function to build folder structure
const buildFolderStructure = (files) => {
  const structure = {};
  
  files.forEach(file => {
    const path = file.relativePath || file.fileName;
    const parts = path.split('/');
    
    let current = structure;
    
    // Navigate through the path, creating folders as needed
    for (let i = 0; i < parts.length - 1; i++) {
      const folderName = parts[i];
      if (!current[folderName]) {
        current[folderName] = { type: 'folder', children: {}, files: [] };
      }
      current = current[folderName].children;
    }
    
    // Add the file to the final folder
    const fileName = parts[parts.length - 1];
    if (!current.__files__) current.__files__ = [];
    current.__files__.push(file);
  });
  
  return structure;
};

// Component to render folder structure
const FolderTree = ({ structure, onFileClick, level = 0 }) => {
  const [expandedFolders, setExpandedFolders] = useState(new Set());

  const toggleFolder = (folderName) => {
    setExpandedFolders(prev => {
      const newSet = new Set(prev);
      if (newSet.has(folderName)) {
        newSet.delete(folderName);
      } else {
        newSet.add(folderName);
      }
      return newSet;
    });
  };

  const renderItem = (key, item) => {
    if (key === '__files__') {
      // Render files
      return item.map(file => (
        <div key={file.id} className={`flex items-center gap-2 py-2 px-3 ml-${level * 4} hover:bg-gray-700/30 rounded-md cursor-pointer transition-colors`}>
          <FileText className="w-4 h-4 text-yellow-300 flex-shrink-0" />
          <div className="flex-grow overflow-hidden">
            <p className="text-gray-200 font-medium truncate" title={file.fileName}>{file.fileName}</p>
            <p className="text-xs text-gray-400">
              {(file.size / 1024).toFixed(1)} KB • {file.fileType}
            </p>
          </div>
          <Button variant="ghost" size="sm" onClick={() => onFileClick(file)} className="text-gray-400 hover:text-white">
            View
          </Button>
        </div>
      ));
    } else {
      // Render folder
      const isExpanded = expandedFolders.has(key);
      return (
        <div key={key} className={`ml-${level * 4}`}>
          <Collapsible open={isExpanded} onOpenChange={() => toggleFolder(key)}>
            <CollapsibleTrigger asChild>
              <div className="flex items-center gap-2 py-2 px-3 hover:bg-gray-700/30 rounded-md cursor-pointer transition-colors">
                {isExpanded ? (
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                )}
                {isExpanded ? (
                  <FolderOpen className="w-4 h-4 text-blue-400" />
                ) : (
                  <Folder className="w-4 h-4 text-blue-400" />
                )}
                <span className="text-gray-200 font-medium">{key}</span>
              </div>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <div className="ml-4">
                <FolderTree 
                  structure={item.children} 
                  onFileClick={onFileClick} 
                  level={level + 1} 
                />
                {item.children.__files__ && (
                  <FolderTree 
                    structure={{ __files__: item.children.__files__ }} 
                    onFileClick={onFileClick} 
                    level={level + 1} 
                  />
                )}
              </div>
            </CollapsibleContent>
          </Collapsible>
        </div>
      );
    }
  };

  return (
    <div className="space-y-1">
      {Object.entries(structure).map(([key, item]) => renderItem(key, item))}
    </div>
  );
};

export default function LearningLibraryPage() {
  const [filesByGame, setFilesByGame] = useState({});
  const [learningReports, setLearningReports] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [modalContent, setModalContent] = useState('');
  const [isModalLoading, setIsModalLoading] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const [allFiles, allReports] = await Promise.all([
          LearningFile.list('-created_date', 500),
          AILearningReport.list('-created_date', 100)
        ]);
        
        const groupedFiles = _.groupBy(allFiles, 'game');
        setFilesByGame(groupedFiles);
        setLearningReports(allReports);
      } catch (error) {
        console.error("Failed to fetch learning data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleViewFile = async (file) => {
    setSelectedFile(file);
    if (['pdf', 'png', 'jpg', 'jpeg', 'gif'].includes(file.fileType)) {
      window.open(file.fileUrl, '_blank');
      return;
    }
    
    setIsModalLoading(true);
    try {
      const response = await fetch(file.fileUrl);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const textContent = await response.text();
      setModalContent(textContent);
    } catch (error) {
      console.error("Failed to fetch file content:", error);
      setModalContent("Error: Could not load file content.");
    } finally {
      setIsModalLoading(false);
    }
  };

  const renderGameContent = (files, game) => {
    const folderStructure = buildFolderStructure(files);

    return (
      <div className="space-y-6">
        {/* AI Learning Reports Section */}
        {learningReports.filter(report => report.game === game).length > 0 && (
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-yellow-300 mb-3 flex items-center gap-2">
              <BrainCircuit className="w-5 h-5" />
              AI Learning Reports ({game})
            </h3>
            <div className="grid gap-3">
              {learningReports.filter(report => report.game === game).map(report => (
                <Card key={report.id} className="bg-gray-800/30 border-yellow-700/30">
                  <CardHeader className="p-3 pb-2">
                    <CardTitle className="text-yellow-300 text-base flex items-center justify-between">
                      AI Analysis Report - {report.fileCount} file{report.fileCount !== 1 ? 's' : ''}
                      <Badge className="bg-yellow-900/50 text-yellow-200">
                        Score: {report.qualityScore}/10
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-3 pt-0 space-y-2 text-sm">
                    <div>
                      <p className="text-gray-300 font-medium">Assessment:</p>
                      <p className="text-gray-400 italic">"{report.overallAssessment}"</p>
                    </div>
                    <div>
                      <p className="text-gray-300 font-medium">Files Analyzed:</p>
                      <p className="text-gray-400">{report.analyzedFileNames.length > 0 ? report.analyzedFileNames.join(', ') : 'Script files (used as context)'}</p>
                    </div>
                    <div>
                      <p className="text-gray-300 font-medium">Key Learnings:</p>
                      <ul className="list-disc list-inside text-gray-400 pl-2 space-y-1">
                        {report.keyLearnings.slice(0, 3).map((learning, i) => (
                          <li key={i}>{learning}</li>
                        ))}
                        {report.keyLearnings.length > 3 && (
                          <li className="text-gray-500">...and {report.keyLearnings.length - 3} more</li>
                        )}
                      </ul>
                    </div>
                    <div>
                      <p className="text-gray-300 font-medium">AI Recommendations:</p>
                      <p className="text-gray-400">{report.recommendations}</p>
                    </div>
                    <p className="text-xs text-gray-500 pt-2">
                      Analyzed on {new Date(report.created_date).toLocaleDateString()}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Files Section with Folder Structure */}
        <div>
          <h3 className="text-lg font-semibold text-gray-300 mb-3 flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Uploaded Files ({files.length}) - Organized by Folder Structure
          </h3>
          <Card className="bg-gray-800/50 border-gray-700/50">
            <CardContent className="p-4">
              <ScrollArea className="h-96 w-full">
                <FolderTree structure={folderStructure} onFileClick={handleViewFile} />
              </ScrollArea>
            </CardContent>
          </Card>
        </div>

        {/* File Content Modal */}
        <Dialog>
          <DialogTrigger asChild>
            <div className="hidden"></div>
          </DialogTrigger>
          <DialogContent className="max-w-4xl h-5/6 flex flex-col bg-gray-900 border-yellow-700/50 text-gray-200">
            <DialogHeader>
              <DialogTitle className="text-yellow-300 flex items-center gap-2">
                <FileText className="w-5 h-5" />
                {selectedFile?.fileName}
                <span className="text-sm font-normal text-gray-400">
                  ({selectedFile?.relativePath})
                </span>
              </DialogTitle>
            </DialogHeader>
            <ScrollArea className="flex-grow bg-black/50 p-1 rounded-md border border-gray-700">
              {isModalLoading ? (
                <div className="flex items-center justify-center h-full">
                  <Loader2 className="w-8 h-8 animate-spin text-yellow-300" />
                </div>
              ) : (
                <pre className="text-sm p-4 whitespace-pre-wrap"><code>{modalContent}</code></pre>
              )}
            </ScrollArea>
          </DialogContent>
        </Dialog>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-yellow-200 mb-2 flex items-center justify-center gap-3">
          <BrainCircuit className="w-8 h-8" />
          AI Learning Library
        </h1>
        <p className="text-gray-400">A community-contributed library of scripts and documents organized by folder structure.</p>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center py-20">
          <Loader2 className="w-12 h-12 animate-spin text-yellow-300" />
        </div>
      ) : (
        <Tabs defaultValue={Object.keys(filesByGame)[0] || 'none'} className="w-full">
          <TabsList className="grid w-full grid-cols-3 md:grid-cols-6 bg-gray-900/50 p-2 h-auto">
            {Object.keys(gameColors).map(game => (
              (filesByGame[game] && filesByGame[game].length > 0) || learningReports.filter(report => report.game === game).length > 0 ? (
                <TabsTrigger key={game} value={game} className="data-[state=active]:bg-yellow-800/50 data-[state=active]:text-yellow-200">
                  {game} ({(filesByGame[game]?.length || 0)})
                </TabsTrigger>
              ) : null
            ))}
          </TabsList>
          {Object.keys(gameColors).map(game => (
            ((filesByGame[game] && filesByGame[game].length > 0) || learningReports.filter(report => report.game === game).length > 0) && (
            <TabsContent key={game} value={game}>
              <Card className="bg-transparent border-none mt-4">
                <CardContent>
                  {renderGameContent(filesByGame[game] || [], game)}
                </CardContent>
              </Card>
            </TabsContent>
            )
          ))}
        </Tabs>
      )}
    </div>
  );
}