
import React, { useState, useEffect, useRef, useCallback } from "react";
import { GameScript } from "@/api/entities";
import { ScriptFix } from "@/api/entities";
import { User } from "@/api/entities";
import { InvokeLLM, UploadFile } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button, buttonVariants } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Library, Search, Filter, FileText, Gamepad2, Code, Eye, Upload, X, MessageSquare, Loader2, AlertCircle, Clipboard, CheckCircle, Trash2, MoreHorizontal, Globe, Mic, StopCircle, RotateCcw } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

const gameIcons = {
  Morrowind: <FileText className="w-4 h-4" />,
  Oblivion: <Gamepad2 className="w-4 h-4" />,
  Skyrim: <Code className="w-4 h-4" />,
  TES3MP: <Globe className="w-4 h-4" />
};

const gameColors = {
  Morrowind: "bg-red-900/50 text-red-300 border-red-700",
  Oblivion: "bg-blue-900/50 text-blue-300 border-blue-700",
  Skyrim: "bg-purple-900/50 text-purple-300 border-purple-700",
  TES3MP: "bg-teal-900/50 text-teal-300 border-teal-700"
};

const categoryColors = {
  NPC: "bg-green-900/50 text-green-300",
  Object: "bg-orange-900/50 text-orange-300",
  Quest: "bg-yellow-900/50 text-yellow-300",
  Utility: "bg-cyan-900/50 text-cyan-300",
  Combat: "bg-red-900/50 text-red-300",
  Magic: "bg-purple-900/50 text-purple-300",
  Other: "bg-gray-900/50 text-gray-300"
};

// Define SpeechRecognition for browser compatibility
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

function VoiceToText({ onTranscript, className }) {
  const [isListening, setIsListening] = useState(false);
  const [error, setError] = useState("");
  const recognitionRef = useRef(null);

  useEffect(() => {
    if (!SpeechRecognition) {
      setError("Speech Recognition is not supported by your browser.");
      return;
    }

    recognitionRef.current = new SpeechRecognition();
    recognitionRef.current.continuous = false; // Listen for a single utterance
    recognitionRef.current.interimResults = false; // Don't show interim results
    recognitionRef.current.lang = "en-US";

    recognitionRef.current.onstart = () => {
      setIsListening(true);
      setError("");
    };

    recognitionRef.current.onresult = (event) => {
      const transcript = Array.from(event.results)
        .map((result) => result[0])
        .map((result) => result.transcript)
        .join("");
      onTranscript(transcript);
    };

    recognitionRef.current.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current.onerror = (event) => {
      setError("Speech recognition error: " + event.error);
      setIsListening(false);
    };

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [onTranscript]);

  const toggleListening = () => {
    if (!SpeechRecognition) {
      setError("Speech Recognition is not supported by your browser.");
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
    } else {
      try {
        recognitionRef.current.start();
      } catch (e) {
        if (e.message.includes("recognition has already started")) {
          console.warn("Recognition already started, ignoring start call.");
        } else {
          setError("Failed to start speech recognition. " + e.message);
          console.error("Speech recognition start error:", e);
        }
      }
    }
  };

  return (
    <div className={className}>
      <Button
        type="button"
        onClick={toggleListening}
        variant="ghost"
        size="icon"
        className="w-8 h-8 text-gray-400 hover:text-white"
        title={isListening ? "Stop listening" : "Start voice input"}
      >
        {isListening ? (
          <StopCircle className="w-4 h-4 text-red-400 animate-pulse" />
        ) : (
          <Mic className="w-4 h-4" />
        )}
      </Button>
      {error && <p className="text-red-400 text-xs mt-1">{error}</p>}
    </div>
  );
}

// Global flag to prevent multiple instances from loading simultaneously
let globalLoadingFlag = false;

// Cache to store scripts and prevent repeated API calls
let scriptsCache = {
  data: null,
  userEmail: null,
  timestamp: null,
  expireTime: 30000 // 30 seconds cache
};

export default function MyScriptsPage() {
  const [scripts, setScripts] = useState([]);
  const [filteredScripts, setFilteredScripts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [gameFilter, setGameFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");

  // AI Error Analysis State
  const [showErrorAnalysis, setShowErrorAnalysis] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [uploadedFileUrls, setUploadedFileUrls] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const [errorDescription, setErrorDescription] = useState("");
  const [selectedScriptForError, setSelectedScriptForError] = useState("general");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  // Add new state for error discussion mode
  const [errorDiscussionMode, setErrorDiscussionMode] = useState(false);
  const [errorDiscussionHistory, setErrorDiscussionHistory] = useState([]);
  const [userFollowupResponse, setUserFollowupResponse] = useState("");
  const [isErrorDiscussionAnalyzing, setIsErrorDiscussionAnalyzing] = useState(false);

  // Deletion State
  const [isDeleting, setIsDeleting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);

  // Jiub Tutorial State
  const [showJiubTutorial, setShowJiubTutorial] = useState(false);
  const [currentJiubStep, setCurrentJiubStep] = useState(0);
  const [hasCompletedJiubTutorial, setHasCompletedJiubTutorial] = useState(false);

  // Add user state for admin check
  const [currentUser, setCurrentUser] = useState(null);
  const [retryCount, setRetryCount] = useState(0);
  const [lastLoadTime, setLastLoadTime] = useState(0);

  // Ref for tracking the currently highlighted tutorial element
  const highlightedElementRef = useRef(null);

  // Define highlight classes for tutorial
  const highlightClassNames = "outline outline-4 outline-yellow-400 outline-offset-2 z-10 relative transition-all duration-300";

  // Jiub Tutorial Steps
  const jiubTutorialSteps = React.useMemo(() => [
    {
      title: "Welcome, Outlander!",
      text: "I am Jiub, and I'll be your guide to managing your scripts. Let's take a quick tour!",
      targetId: null,
    },
    {
      title: "Your Script Collection",
      text: "This is where all your generated and saved scripts live. You can search, filter, and view details of each.",
      targetId: "filters-section",
    },
    {
      title: "Need Help? Ask the AI!",
      text: "Experiencing a bug or need a script fixed? Click the 'Get Help with Errors' button to get our AI assistant to diagnose and even fix your code!",
      targetId: "error-analysis-button-container",
    },
    {
      title: "Organize Your Work",
      text: "Scripts can be grouped into projects for better organization. You'll see projects and individual scripts listed below.",
      targetId: "scripts-grid-area",
    },
    {
      title: "Viewing Script Details",
      text: "Click on any script title or the eye icon to view its full details, code, and edit it.",
      targetId: null, // Describing interaction rather than highlighting a specific link for simplicity
    },
    {
      title: "That's it for now!",
      text: "May your journey be filled with successful modding, Outlander! You can always start this tutorial again by clicking 'Jiub's Tour'.",
      targetId: null,
    },
  ], []);

  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  const loadScripts = useCallback(async (userEmail, forceReload = false) => {
    // Prevent multiple concurrent calls globally
    if (globalLoadingFlag && !forceReload) {
      console.log("Another instance is already loading scripts, waiting...");
      // Wait and try to use cached data
      await sleep(1000);
      if (scriptsCache.data && scriptsCache.userEmail === userEmail) {
        setScripts(scriptsCache.data);
        setFilteredScripts(scriptsCache.data);
        setIsLoading(false);
        return;
      }
    }

    const emailToFilter = userEmail || currentUser?.email;
    if (!emailToFilter) {
      console.warn("Cannot load scripts without a user email.");
      setScripts([]);
      setFilteredScripts([]);
      setIsLoading(false);
      return;
    }

    // Check cache first (unless force reload)
    const now = Date.now();
    if (!forceReload && scriptsCache.data && 
        scriptsCache.userEmail === emailToFilter && 
        scriptsCache.timestamp && 
        (now - scriptsCache.timestamp) < scriptsCache.expireTime) {
      console.log("Using cached scripts data");
      setScripts(scriptsCache.data);
      setFilteredScripts(scriptsCache.data);
      setIsLoading(false);
      return;
    }

    // Rate limiting protection - don't make requests too frequently
    const timeSinceLastLoad = now - lastLoadTime;
    if (timeSinceLastLoad < 2000 && !forceReload) { // 2 second minimum between loads
      console.log("Rate limiting protection: too soon since last load, waiting...");
      await sleep(2000 - timeSinceLastLoad);
    }

    globalLoadingFlag = true;
    setIsLoading(true);
    setLastLoadTime(now);

    try {
      console.log(`Loading scripts for user: ${emailToFilter}`);
      const data = await GameScript.filter({ created_by: emailToFilter }, "-created_date");
      
      // Update cache
      scriptsCache = {
        data: data,
        userEmail: emailToFilter,
        timestamp: now,
        expireTime: 30000
      };

      setScripts(data);
      setFilteredScripts(data);
      setRetryCount(0); // Reset retry count on success
      setError(null); // Clear any previous errors
      console.log(`Successfully loaded ${data.length} scripts`);
    } catch (error) {
      console.error("Error loading scripts:", error);
      
      if (error.message && error.message.includes('429')) {
        // Rate limit exceeded - implement exponential backoff
        const backoffTime = Math.min(1000 * Math.pow(2, retryCount), 10000); // Max 10 seconds
        setError(`Rate limit exceeded. Retrying in ${Math.ceil(backoffTime/1000)} seconds...`);
        
        if (retryCount < 3) { // Max 3 retries
          setTimeout(() => {
            setRetryCount(prev => prev + 1);
            setError(null); // Clear error message to show only during wait time
            loadScripts(emailToFilter, true); // Force reload on retry
          }, backoffTime);
        } else {
          setError("Too many requests. Please wait a few minutes and refresh the page manually.");
          // Use cached data if available
          if (scriptsCache.data && scriptsCache.userEmail === emailToFilter) {
            setScripts(scriptsCache.data);
            setFilteredScripts(scriptsCache.data);
          }
        }
      } else {
        setError("Failed to load scripts. Please refresh the page.");
        setScripts([]);
        setFilteredScripts([]);
      }
    } finally {
      globalLoadingFlag = false;
      setIsLoading(false);
    }
  }, [currentUser?.email, retryCount, lastLoadTime]);

  useEffect(() => {
    const loadInitialData = async () => {
      setIsLoading(true); // Ensure loading is true before trying to fetch user/scripts
      try {
        const user = await User.me();
        setCurrentUser(user);
        
        // Small delay to prevent rapid-fire requests immediately after user data is fetched
        await sleep(100);
        
        // Load scripts for this user
        await loadScripts(user.email);
      } catch (error) {
        console.error("Failed to load user:", error);
        if (error.message && error.message.includes('429')) {
          setError("Rate limit exceeded loading user data. Please refresh the page in a moment.");
        } else {
          setError("Failed to load user data. Please check your connection and refresh the page.");
        }
        setIsLoading(false); // Stop loading if there's an error
      }

      const tutorialStatus = localStorage.getItem('hasCompletedJiubTutorial');
      if (tutorialStatus === 'true') {
        setHasCompletedJiubTutorial(true);
      }
    };

    // Only load once when component mounts
    loadInitialData();
  }, [loadScripts]); // Include loadScripts as dependency


  useEffect(() => {
    // If scripts are loaded and user hasn't seen tutorial, offer to start
    // We add a delay to allow page elements to render before attempting to scroll/highlight
    if (!isLoading && scripts.length > 0 && !hasCompletedJiubTutorial) {
      // You could add a small alert/toast here to prompt the user to start the tour
      // For now, simply making the button available is sufficient.
    }
  }, [isLoading, scripts, hasCompletedJiubTutorial]);


  useEffect(() => {
    // Scroll to target element and apply highlight if one is specified for the current step
    if (showJiubTutorial) {
      // Clear previous highlight
      if (highlightedElementRef.current) {
        highlightedElementRef.current.classList.remove(...highlightClassNames.split(' '));
        highlightedElementRef.current = null;
      }

      const targetId = jiubTutorialSteps[currentJiubStep]?.targetId;
      if (targetId) {
        const targetElement = document.getElementById(targetId);
        if (targetElement) {
          targetElement.scrollIntoView({ behavior: "smooth", block: "center" });
          // Add highlight classes
          targetElement.classList.add(...highlightClassNames.split(' '));
          highlightedElementRef.current = targetElement;
        }
      }
    } else {
      // Tutorial ended or not shown, clean up any remaining highlight
      if (highlightedElementRef.current) {
        highlightedElementRef.current.classList.remove(...highlightClassNames.split(' '));
        highlightedElementRef.current = null;
      }
    }

    // Cleanup function for when component unmounts or dependencies change
    return () => {
      if (highlightedElementRef.current) {
        highlightedElementRef.current.classList.remove(...highlightClassNames.split(' '));
        highlightedElementRef.current = null;
      }
    };
  }, [showJiubTutorial, currentJiubStep, jiubTutorialSteps]); // jiubTutorialSteps is a memoized array, safe to include

  // Jiub Tutorial Handlers
  const startJiubTutorial = () => {
    setShowJiubTutorial(true);
    setCurrentJiubStep(0);
    // When restarting, we don't clear hasCompletedJiubTutorial,
    // only when completing it do we set it.
  };

  const nextJiubStep = () => {
    if (currentJiubStep < jiubTutorialSteps.length - 1) {
      setCurrentJiubStep(prev => prev + 1);
    } else {
      endJiubTutorial();
    }
  };

  const endJiubTutorial = () => {
    setShowJiubTutorial(false);
    setHasCompletedJiubTutorial(true);
    localStorage.setItem('hasCompletedJiubTutorial', 'true');
    setCurrentJiubStep(0); // Reset for next time
  };

  const restartTutorial = () => {
    localStorage.removeItem('hasCompletedJiubTutorial');
    // Navigate to home page to trigger tutorial
    window.location.href = createPageUrl('MyScripts'); // Changed from 'Home' to 'MyScripts' to immediately restart
  };

  useEffect(() => {
    let filtered = scripts;

    if (searchTerm) {
      filtered = filtered.filter(script =>
        script.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        script.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        script.originalPrompt.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (script.projectName && script.projectName.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    if (gameFilter !== "all") {
      filtered = filtered.filter(script => script.game === gameFilter);
    }

    if (categoryFilter !== "all") {
      filtered = filtered.filter(script => script.category === categoryFilter);
    }

    setFilteredScripts(filtered);
  }, [scripts, searchTerm, gameFilter, categoryFilter]);

  const handleFileChange = async (event) => {
    const files = Array.from(event.target.files);
    if (!files.length) return;

    // Validate each file
    const validTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/webp'];
    const maxSize = 10 * 1024 * 1024; // 10MB per file

    // Check total file limit first
    if (uploadedFiles.length + files.length > 5) {
      setError("You can upload a maximum of 5 images. Please remove some existing images or select fewer new ones.");
      return;
    }

    for (const file of files) {
      if (!validTypes.includes(file.type)) {
        setError(`${file.name} is not a valid image file. Please upload PNG, JPEG, GIF, or WebP files only.`);
        return;
      }
      if (file.size > maxSize) {
        setError(`${file.name} is too large. Please upload images under 10MB each.`);
        return;
      }
    }

    setIsUploading(true);
    setError(null);

    try {
      const newFileUrls = [];
      const newFiles = [];

      for (const file of files) {
        const { file_url } = await UploadFile({ file });
        newFileUrls.push(file_url);
        newFiles.push(file);
      }

      setUploadedFiles(prev => [...prev, ...newFiles]);
      setUploadedFileUrls(prev => [...prev, ...newFileUrls]);
    } catch (e) {
      setError("Failed to upload one or more images. Please try again with different files.");
      console.error("Upload error:", e);
    } finally {
      setIsUploading(false);
    }
  };

  const removeFile = (indexToRemove) => {
    setUploadedFiles(prev => prev.filter((_, index) => index !== indexToRemove));
    setUploadedFileUrls(prev => prev.filter((_, index) => index !== indexToRemove));
  };

  const removeAllFiles = () => {
    setUploadedFiles([]);
    setUploadedFileUrls([]);
  };

  const handleAnalyzeError = async () => {
    if (uploadedFileUrls.length === 0 && !errorDescription.trim()) {
      setError("Please upload at least one image or describe the error you're experiencing.");
      return;
    }

    setIsAnalyzing(true);
    setError(null);
    setAnalysisResult(null);
    setSuccess(null);

    const selectedScript = selectedScriptForError !== "general" ?
      scripts.find(s => s.id === selectedScriptForError) : null;

    if (selectedScript) {
      // Get learning data from previous fixes
      const previousFixes = await ScriptFix.list('-created_date', 20); // Fetch recent fixes
      const relevantFixes = previousFixes.filter(fix =>
        fix.game === selectedScript.game &&
        fix.scriptCategory === selectedScript.category &&
        fix.userValidated === true // Only learn from validated fixes
      ).slice(0, 10); // Limit to 10 relevant examples

      const learningContext = relevantFixes.length > 0 ? `
      LEARN FROM THESE PREVIOUS VALIDATED FIXES:
      Based on previous user issues, here are common problems and successful solutions for ${selectedScript.game} ${selectedScript.category} scripts. Use this knowledge to avoid similar mistakes and provide an accurate, high-quality fix.

      ${relevantFixes.map((fix, i) => `
      Fix ${i + 1}:
      - Problem Description: ${fix.problemDescription}
      - Error Pattern: ${fix.errorPattern}
      - Problem Type: ${fix.problemType}
      - Solution Provided: ${fix.solution}
      `).join('\n')}

      USE THIS KNOWLEDGE TO AVOID SIMILAR MISTAKES IN YOUR FIX AND ENSURE THE PROVIDED SCRIPT IS CORRECT.
      ` : '';

      // Script-specific fix
      const prompt = `You are an expert Elder Scrolls modding assistant. A user is having issues with their script and needs you to FIX IT for them. Assume the user doesn't know how to script.

      ${learningContext}

      CURRENT SCRIPT:
      Title: ${selectedScript.title}
      Game: ${selectedScript.game}
      Category: ${selectedScript.category}
      Script Code:
      ${selectedScript.scriptCode}

      USER'S PROBLEM: "${errorDescription}"

      ${uploadedFileUrls.length > 0 ? `The user has provided ${uploadedFileUrls.length} image(s) showing the error or issue. Analyze all images for context.` : ''}

      Please analyze the problem and provide a COMPLETELY FIXED VERSION of the script that solves their issue. Don't just give suggestions - actually rewrite the script to work properly.

      Return a JSON object with:
      - "problemDiagnosis": string (what was wrong with the original script)
      - "fixedScriptCode": string (the completely corrected script code that will work)
      - "whatChanged": array of strings (specific changes made to fix the script)
      - "implementationSteps": array of strings (step-by-step instructions for replacing the old script)
      - "testingAdvice": string (how to test that the fix worked)
      - "errorPattern": string (describe the common error pattern for learning purposes, e.g., "Missing 'EndIf' block", "Incorrect variable scope", "API mismatch for game version")
      - "problemType": string (one of: "Syntax Error", "Logic Error", "Performance Issue", "Compatibility Issue", "Missing Feature", "Runtime Error", "Other")`;

      try {
        const requestData = {
          prompt: prompt,
          response_json_schema: {
            type: "object",
            properties: {
              problemDiagnosis: { type: "string" },
              fixedScriptCode: { type: "string" },
              whatChanged: { type: "array", items: { type: "string" } },
              implementationSteps: { type: "array", items: { type: "string" } },
              testingAdvice: { type: "string" },
              errorPattern: { type: "string" },
              problemType: { type: "string" }
            },
            required: ["problemDiagnosis", "fixedScriptCode", "whatChanged", "implementationSteps", "testingAdvice", "errorPattern", "problemType"]
          }
        };

        if (uploadedFileUrls.length > 0) {
          requestData.file_urls = uploadedFileUrls;
        }

        const result = await InvokeLLM(requestData);
        setAnalysisResult({ ...result, selectedScript, isScriptFix: true });

        // Save this fix to the learning database if a specific script was selected
        if (selectedScript) {
            try {
              await ScriptFix.create({
                originalScript: selectedScript.scriptCode,
                fixedScript: result.fixedScriptCode,
                problemDescription: errorDescription || "User reported script issues",
                problemType: result.problemType,
                game: selectedScript.game,
                scriptCategory: selectedScript.category,
                errorPattern: result.errorPattern,
                solution: result.problemDiagnosis,
                userValidated: false, // Will be set to true when user confirms fix worked
              });
            } catch (saveError) {
              console.error("Failed to save fix for learning:", saveError);
              // Don't show error to user, this is background learning
            }
        }

      } catch (e) {
        console.error("Script fix error:", e);
        if (e.message && e.message.includes('image')) {
          setError("There was an issue with one or more uploaded images. Please try uploading different images or describe the error in text.");
        } else {
          setError("Failed to fix script. Please try again or describe the issue in more detail.");
        }
      }
    } else {
      // General troubleshooting - also use learning data
      const previousFixes = await ScriptFix.list('-created_date', 15); // Fetch recent fixes
      const validatedPatterns = previousFixes.filter(fix => fix.userValidated === true).map(fix => fix.errorPattern);
      const commonPatterns = [...new Set(validatedPatterns)].slice(0, 10); // Unique and limited patterns

      const learningContext = commonPatterns.length > 0 ? `
      COMMON ERROR PATTERNS TO WATCH FOR:
      Based on previous user-validated issues, here are frequent problems and their patterns:
      ${commonPatterns.map((pattern, i) => `${i + 1}. ${pattern}`).join('\n')}

      Keep these patterns in mind when diagnosing the user's issue and formulating solutions.
      ` : '';

      const prompt = `You are an expert Elder Scrolls modding assistant. A user is having general modding/scripting issues and needs help.

      ${learningContext}

      USER'S PROBLEM: "${errorDescription}"

      ${uploadedFileUrls.length > 0 ? `The user has provided ${uploadedFileUrls.length} image(s) showing the error or issue. Analyze all images for context.` : ''}

      Please provide specific, actionable solutions to fix their problem. Assume they don't know how to script.

      Return a JSON object with:
      - "problemType": string (what type of issue this is)
      - "diagnosis": string (what's causing the problem)
      - "solutions": array of strings (step-by-step solutions to try, be very specific)
      - "preventionTips": array of strings (how to avoid this problem in the future)
      - "commonMistakes": array of strings (common mistakes that lead to this issue)`;

      try {
        const requestData = {
          prompt: prompt,
          response_json_schema: {
            type: "object",
            properties: {
              problemType: { type: "string" },
              diagnosis: { type: "string" },
              solutions: { type: "array", items: { type: "string" } },
              preventionTips: { type: "array", items: { type: "string" } },
              commonMistakes: { type: "array", items: { type: "string" } }
            },
            required: ["problemType", "diagnosis", "solutions", "preventionTips", "commonMistakes"]
          }
        };

        if (uploadedFileUrls.length > 0) {
          requestData.file_urls = uploadedFileUrls;
        }

        const result = await InvokeLLM(requestData);
        setAnalysisResult({ ...result, isScriptFix: false });
      } catch (e) {
        console.error("General help error:", e);
        if (e.message && e.message.includes('image')) {
          setError("There was an issue with one or more uploaded images. Please try uploading different images or describe the error in text.");
        } else {
          setError("Failed to analyze error. Please try again or describe the issue in text instead.");
        }
      }
    }

    setIsAnalyzing(false);
  };

  const handleResetErrorAnalysis = () => {
    setShowErrorAnalysis(false);
    setUploadedFiles([]); // Clear array
    setUploadedFileUrls([]); // Clear array
    setErrorDescription("");
    setSelectedScriptForError("general");
    setAnalysisResult(null);
    setError(null);
    setSuccess(null); // Clear success message on reset
    setErrorDiscussionMode(false); // Also reset discussion mode
    setErrorDiscussionHistory([]);
    setUserFollowupResponse("");
    setIsErrorDiscussionAnalyzing(false);
  };

  // New function to handle starting error discussion
  const handleStartErrorDiscussion = () => {
    if (!analysisResult) {
      setError("Please run the initial error analysis first.");
      return;
    }

    setErrorDiscussionMode(true);
    setErrorDiscussionHistory([{
      type: 'initial_analysis',
      content: analysisResult,
      timestamp: Date.now()
    }]);
    setError(null); // Clear any previous errors
  };

  // New function to handle discussion responses
  const handleErrorDiscussionResponse = async () => {
    if (!userFollowupResponse.trim()) {
      setError("Please describe what happened when you tried the suggested fix.");
      return;
    }

    setIsErrorDiscussionAnalyzing(true);
    setError(null);

    const conversationHistory = errorDiscussionHistory.map(item => {
      if (item.type === 'initial_analysis') {
        if (item.content.isScriptFix) {
          return `Initial AI Analysis (Problem Diagnosis: ${item.content.problemDiagnosis}. Suggested fix provided.)`;
        } else {
          return `Initial AI Analysis (Diagnosis: ${item.content.diagnosis}. Solutions provided.)`;
        }
      } else if (item.type === 'user_response') {
        return `User Feedback: ${item.content}`;
      } else if (item.type === 'ai_followup') {
        return `AI Response: ${item.content.response || JSON.stringify(item.content)}`;
      }
      return '';
    }).filter(Boolean).join('\n\n'); // Filter out empty strings and join

    const selectedScript = selectedScriptForError !== "general" ?
      scripts.find(s => s.id === selectedScriptForError) : null;

    const followupPrompt = `You are an expert Elder Scrolls modding assistant helping a user troubleshoot their script issue. The user has tried your previous suggestions but is still having problems.

    ${selectedScript ? `
    CURRENT SCRIPT CONTEXT:
    Title: ${selectedScript.title}
    Game: ${selectedScript.game}
    Category: ${selectedScript.category}
    Script Code: ${selectedScript.scriptCode}
    ` : ''}

    PREVIOUS CONVERSATION:
    ${conversationHistory}

    USER'S LATEST FEEDBACK: "${userFollowupResponse}"

    The user has tried your previous suggestions but is still experiencing issues. Based on their feedback, provide:
    1. A refined analysis of what might be going wrong
    2. Alternative solutions or different approaches to try
    3. More specific troubleshooting steps
    4. Questions to help narrow down the exact problem

    ${selectedScript ? `
    If needed, provide an updated/corrected version of the script code.

    Return a JSON object with:
    - "response": string (your response acknowledging their feedback and providing new guidance)
    - "newSolutions": array of strings (alternative approaches to try)
    - "troubleshootingQuestions": array of strings (questions to help diagnose the issue further)
    - "updatedScriptCode": string (if you have a new/corrected script version, otherwise null)
    - "nextSteps": array of strings (specific next steps to try)
    ` : `
    Return a JSON object with:
    - "response": string (your response acknowledging their feedback and providing new guidance)
    - "newSolutions": array of strings (alternative approaches to try)
    - "troubleshootingQuestions": array of strings (questions to help diagnose the issue further)
    - "nextSteps": array of strings (specific next steps to try)
    `}`;

    try {
      let schemaProperties = {
        response: { type: "string" },
        newSolutions: { type: "array", items: { type: "string" } },
        troubleshootingQuestions: { type: "array", items: { type: "string" } },
        nextSteps: { type: "array", items: { type: "string" } }
      };
      let requiredProperties = ["response", "newSolutions", "troubleshootingQuestions", "nextSteps"];

      if (selectedScript) {
        schemaProperties.updatedScriptCode = { type: "string", nullable: true };
      }

      const requestData = {
        prompt: followupPrompt,
        file_urls: uploadedFileUrls.length > 0 ? uploadedFileUrls : undefined,
        response_json_schema: {
          type: "object",
          properties: schemaProperties,
          required: requiredProperties
        }
      };

      const result = await InvokeLLM(requestData);

      const newHistory = [
        ...errorDiscussionHistory,
        { type: 'user_response', content: userFollowupResponse, timestamp: Date.now() },
        { type: 'ai_followup', content: result, timestamp: Date.now() }
      ];

      setErrorDiscussionHistory(newHistory);
      setUserFollowupResponse("");

    } catch (e) {
      console.error("Error in discussion response:", e);
      setError("Failed to continue error discussion. Please try again or rephrase your feedback.");
    } finally {
      setIsErrorDiscussionAnalyzing(false);
    }
  };

  const handleEndErrorDiscussion = () => {
    setErrorDiscussionMode(false);
    setErrorDiscussionHistory([]);
    setUserFollowupResponse("");
    setError(null); // Clear any errors
    setSuccess(null); // Clear any successes
  };

  const openDeleteDialog = (type, id, name) => {
    setItemToDelete({ type, id, name });
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (!itemToDelete) return;

    setIsDeleting(true);
    setError(null); // Clear previous errors
    setSuccess(null); // Clear previous successes
    const { type, id } = itemToDelete;

    try {
      if (type === 'project') {
        const scriptsInProject = scripts.filter(s => s.projectId === id);
        await Promise.all(scriptsInProject.map(s => GameScript.delete(s.id)));
        setSuccess(`Project "${itemToDelete.name}" and all its associated scripts deleted successfully.`);
      } else if (type === 'script') {
        await GameScript.delete(id);
        setSuccess(`Script "${itemToDelete.name}" deleted successfully.`);
      }
      
      setTimeout(() => setSuccess(null), 4000);
      
      // Clear cache and reload
      scriptsCache.data = null;
      await sleep(1000); // Wait a bit before reloading
      await loadScripts(currentUser?.email, true);
      
    } catch (e) {
      if (e.message && e.message.includes('429')) {
        setError(`Rate limit exceeded. Please wait a moment before trying again.`);
      } else {
        setError(`Failed to delete ${type}. Please try again.`);
      }
      console.error(`Delete error:`, e);
    } finally {
      setIsDeleting(false);
      setShowDeleteConfirm(false);
      setItemToDelete(null);
    }
  };

  const getStats = () => {
    const total = scripts.length;
    const projects = [...new Set(scripts.filter(s => s.projectId).map(s => s.projectId))].length;
    const individualScripts = scripts.filter(s => !s.projectId).length;
    const byGame = scripts.reduce((acc, script) => {
      acc[script.game] = (acc[script.game] || 0) + 1;
      return acc;
    }, {});
    return { total, projects, individualScripts, byGame };
  };

  const groupScriptsByProject = (scripts) => {
    const grouped = {};
    const individual = [];

    scripts.forEach(script => {
      if (script.projectId) {
        if (!grouped[script.projectId]) {
          grouped[script.projectId] = [];
        }
        grouped[script.projectId].push(script);
      } else {
        individual.push(script);
      }
    });

    return { grouped, individual };
  };

  // Add a manual refresh function
  const handleManualRefresh = async () => {
    setError(null);
    setRetryCount(0);
    scriptsCache.data = null; // Clear cache
    await loadScripts(currentUser?.email, true);
  };

  const stats = getStats();
  const { grouped: groupedScripts, individual: individualScripts } = groupScriptsByProject(filteredScripts);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-64 space-y-4">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-300"></div>
        <p className="text-gray-400">Loading your scripts...</p>
        {retryCount > 0 && (
          <p className="text-yellow-300 text-sm">Retry attempt {retryCount}/3</p>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Jiub Tutorial Overlay */}
      {showJiubTutorial && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
          <div className="relative magical-card bg-gray-900 border-yellow-700/50 p-6 rounded-lg shadow-xl max-w-md w-full animate-fade-in-up">
            <div className="card-sparkle-1"></div>
            <div className="card-sparkle-2"></div>
            <div className="card-sparkle-3"></div>
            <div className="card-sparkle-4"></div>

            <div className="flex items-start gap-4 mb-4">
              {/* Jiub's Avatar */}
              <img
                src="https://www.imperial-library.info/sites/default/files/Jiub_OB.png" // Public domain image for Jiub
                alt="Jiub, your guide"
                className="w-16 h-16 rounded-full border-2 border-yellow-500 flex-shrink-0 object-cover"
              />
              <div>
                <h3 className="text-xl font-bold text-yellow-300 mb-1">{jiubTutorialSteps[currentJiubStep].title}</h3>
                <p className="text-gray-200">{jiubTutorialSteps[currentJiubStep].text}</p>
              </div>
            </div>

            <div className="flex justify-between items-center mt-6">
              <Button onClick={endJiubTutorial} variant="ghost" className="text-gray-400 hover:text-white">
                Skip Tour
              </Button>
              <Button onClick={nextJiubStep} className="bg-yellow-700 hover:bg-yellow-600 text-black">
                {currentJiubStep === jiubTutorialSteps.length - 1 ? "Got It!" : "Next"}
              </Button>
            </div>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-yellow-200 flex items-center gap-3">
            <Library className="w-8 h-8" />
            My Scripts
          </h1>
          <p className="text-gray-400 mt-1">
            {stats.total} scripts across {Object.keys(stats.byGame).length} games
          </p>
          {scripts.length > 0 && ( // Only show if there are scripts
            hasCompletedJiubTutorial ? (
              <Button onClick={startJiubTutorial} variant="outline" className="mt-2 text-yellow-300 border-yellow-600 hover:bg-yellow-900/20">
                <Globe className="w-4 h-4 mr-2" /> Restart Jiub's Tour
              </Button>
            ) : (
              <Button onClick={startJiubTutorial} variant="outline" className="mt-2 text-yellow-300 border-yellow-600 hover:bg-yellow-900/20">
                <Globe className="w-4 h-4 mr-2" /> Start Jiub's Tour
              </Button>
            )
          )}
        </div>
        <div className="flex gap-2">
          <div id="error-analysis-button-container">
              <Button
                onClick={() => setShowErrorAnalysis(!showErrorAnalysis)}
                className="bg-red-700 hover:bg-red-600"
              >
                <MessageSquare className="w-4 h-4 mr-2" />
                Get Help with Errors
              </Button>
          </div>
          <Button
            onClick={handleManualRefresh}
            variant="outline"
            className="border-yellow-600 text-yellow-300 hover:bg-yellow-900/20"
            disabled={isLoading}
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Utility Actions Section (Including Restart Full Tutorial button) */}
      <div className="flex justify-end items-center gap-2 mt-2">
        {currentUser && (
          <p className="text-xs text-gray-500">
            Logged in as: {currentUser.email} (Role: {currentUser.role})
          </p>
        )}
        <Button
          onClick={restartTutorial}
          variant="ghost"
          className="text-purple-300 hover:bg-purple-900/20 text-sm border border-purple-600/50"
          title="Completely reset and restart the Jiub tutorial from the beginning."
        >
          🔧 Restart Full Tutorial
        </Button>
      </div>

      {/* AI Error Analysis Section */}
      {showErrorAnalysis && !errorDiscussionMode && (
        <div className="magical-card bg-red-900/20 border-red-700/50 p-6 mb-6">
          <div className="card-sparkle-1"></div>
          <div className="card-sparkle-2"></div>
          <div className="card-sparkle-3"></div>
          <div className="card-sparkle-4"></div>
          <CardHeader className="p-0">
            <CardTitle className="text-red-300 flex items-center gap-2">
              <AlertCircle className="w-5 h-5" />
              AI Error Analysis & Troubleshooting
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 p-0">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Related Script (Optional)
                </label>
                <Select value={selectedScriptForError} onValueChange={setSelectedScriptForError}>
                  <SelectTrigger className="bg-gray-900 border-red-800/50 text-gray-200">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">General Error (Not Script-Specific)</SelectItem>
                    {scripts.map(script => (
                      <SelectItem key={script.id} value={script.id}>
                        {script.title} ({script.game})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label htmlFor="error-images" className="block text-sm font-medium text-gray-300 mb-2">
                  Upload Error Screenshots (Max 5)
                </label>
                <div className="flex items-center gap-2">
                  <label htmlFor="error-images" className={cn(
                    buttonVariants({ variant: "outline" }),
                    "border-red-600 text-red-300 hover:bg-red-900/30 cursor-pointer"
                  )}>
                    <Upload className="w-4 h-4 mr-2" />
                    Choose Files
                  </label>
                  <Input
                    id="error-images"
                    type="file"
                    multiple
                    className="hidden"
                    onChange={handleFileChange}
                    accept="image/png, image/jpeg, image/jpg, image/gif, image/webp"
                  />
                  {isUploading && <Loader2 className="w-5 h-5 animate-spin text-gray-400" />}
                  {uploadedFiles.length > 0 && (
                    <div className="flex items-center gap-2 text-sm text-gray-300">
                      <span>{uploadedFiles.length} file{uploadedFiles.length > 1 ? 's' : ''} uploaded</span>
                      <Button variant="ghost" size="icon" onClick={removeAllFiles} className="w-6 h-6 p-0 text-gray-400 hover:text-gray-200">
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {uploadedFiles.length > 0 && (
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Uploaded Images:</label>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                  {uploadedFiles.map((file, index) => (
                    <div key={index} className="relative">
                      <img
                        src={URL.createObjectURL(file)}
                        alt={`Upload ${index + 1}`}
                        className="w-full h-24 object-cover rounded-md border border-red-600"
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeFile(index)}
                        className="absolute -top-2 -right-2 w-6 h-6 p-0 bg-red-600 hover:bg-red-700 text-white rounded-full"
                      >
                        <X className="w-3 h-3" />
                      </Button>
                      <p className="text-xs text-gray-400 mt-1 truncate">{file.name}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Describe the Error (Optional - helps if no images)
              </label>
              <div className="relative">
                <Textarea
                  value={errorDescription}
                  onChange={(e) => setErrorDescription(e.target.value)}
                  placeholder="Describe what error you're getting, what you expected to happen, and any steps to reproduce..."
                  className="h-20 bg-gray-900 border-red-800/50 text-gray-200"
                />
                <div className="absolute top-2 right-2">
                  <VoiceToText
                    onTranscript={(text) => setErrorDescription(prev => prev.trim() + (prev.trim() ? " " : "") + text)}
                    className="bg-gray-900/80 backdrop-blur rounded"
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                onClick={handleAnalyzeError}
                disabled={isAnalyzing || isUploading}
                className="bg-red-700 hover:bg-red-600"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing Error...
                  </>
                ) : (
                  <>
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Get AI Help
                  </>
                )}
              </Button>
              <Button variant="outline" onClick={handleResetErrorAnalysis}>
                Clear All
              </Button>
            </div>
          </CardContent>
        </div>
      )}

      {/* Error Analysis Results */}
      {analysisResult && !errorDiscussionMode && (
        <div className="magical-card bg-green-900/20 border-green-700/50 p-6">
          <div className="card-sparkle-1"></div>
          <div className="card-sparkle-3"></div>
          <CardHeader className="p-0">
            <CardTitle className="text-green-300">
              {analysisResult.isScriptFix ? "🔧 Fixed Script" : "💡 Troubleshooting Help"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 p-0">
            {analysisResult.isScriptFix ? (
              <>
                {/* Script Fix Results */}
                <div>
                  <h4 className="text-yellow-300 font-medium mb-2">Problem Diagnosis ({analysisResult.problemType}, Pattern: {analysisResult.errorPattern}):</h4>
                  <p className="text-gray-300 text-sm bg-gray-800/50 p-3 rounded-md">{analysisResult.problemDiagnosis}</p>
                </div>

                <div>
                  <h4 className="text-green-300 font-medium mb-2">Fixed Script Code:</h4>
                  <div className="relative">
                    <pre className="bg-black/50 p-4 rounded-md overflow-x-auto text-sm text-green-300 whitespace-pre-wrap border border-gray-700">
                      <code>{analysisResult.fixedScriptCode}</code>
                    </pre>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        navigator.clipboard.writeText(analysisResult.fixedScriptCode);
                        setSuccess("Fixed script copied to clipboard!");
                        setTimeout(() => setSuccess(null), 3000);
                      }}
                      className="absolute top-2 right-2 text-gray-400 hover:text-white"
                    >
                      <Clipboard className="w-4 h-4 mr-2" />
                      Copy Fixed Script
                    </Button>
                  </div>
                </div>

                <div>
                  <h4 className="text-blue-300 font-medium mb-2">What Was Changed:</h4>
                  <ul className="text-gray-300 text-sm space-y-1 list-disc pl-5">
                    {analysisResult.whatChanged.map((change, i) => (
                      <li key={i}>{change}</li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="text-orange-300 font-medium mb-2">How to Replace Your Script:</h4>
                  <ol className="text-gray-300 text-sm space-y-1 list-decimal pl-5">
                    {analysisResult.implementationSteps.map((step, i) => (
                      <li key={i}>{step}</li>
                    ))}
                  </ol>
                </div>

                <div>
                  <h4 className="text-purple-300 font-medium mb-2">Testing the Fix:</h4>
                  <p className="text-gray-300 text-sm bg-purple-900/20 p-3 rounded-md border border-purple-700/50">
                    {analysisResult.testingAdvice}
                  </p>
                </div>

                {/* Auto-update option */}
                <div className="mt-6 p-4 bg-yellow-900/20 border border-yellow-700/50 rounded-md">
                  <h4 className="text-yellow-300 font-medium mb-2">What's Next?</h4>
                  <p className="text-yellow-200 text-sm mb-3">
                    Try the suggested fix. If it doesn't work or you need more help, start a discussion with the AI.
                  </p>
                  <div className="flex gap-3 flex-wrap">
                    {analysisResult.isScriptFix && (
                      <Button
                        onClick={async () => {
                          try {
                            await GameScript.update(analysisResult.selectedScript.id, {
                              scriptCode: analysisResult.fixedScriptCode,
                              // Ensure description doesn't exceed common limits, add ellipsis if needed
                              description: `${analysisResult.selectedScript.description.substring(0, 150)}... (Fixed: ${analysisResult.problemDiagnosis.substring(0, 100).replace(/\n/g, ' ')}...)`
                            });

                            // Mark this fix as validated since user accepted it by updating
                            const fixes = await ScriptFix.filter({
                                originalScript: analysisResult.selectedScript.scriptCode,
                                fixedScript: analysisResult.fixedScriptCode,
                                userValidated: false // Only find unvalidated ones
                            });
                            const recentFix = fixes.find(fix =>
                              fix.problemDescription === (errorDescription || "User reported script issues")
                            );
                            if (recentFix) {
                              await ScriptFix.update(recentFix.id, { userValidated: true });
                            }

                            setSuccess("Script updated with the fix! This successful fix will help improve future AI script generation.");
                            setTimeout(() => setSuccess(null), 5000);
                            scriptsCache.data = null; // Invalidate cache
                            await loadScripts(currentUser?.email, true); // Reload scripts to show updated description/code if needed
                          } catch (e) {
                            setError("Failed to update script. You can copy the fixed code manually.");
                            console.error("Script update failed:", e);
                          }
                        }}
                        className="bg-yellow-700 hover:bg-yellow-600 text-black"
                      >
                        Update My Script with Fix
                      </Button>
                    )}

                    <Button
                      onClick={handleStartErrorDiscussion}
                      variant="outline"
                      className="border-blue-600 text-blue-300 hover:bg-blue-900/30"
                    >
                      💬 Continue Discussion with AI
                    </Button>

                    {analysisResult.isScriptFix && (
                      <Button
                        onClick={async () => {
                          try {
                            // Mark this fix as validated for learning
                            const fixes = await ScriptFix.filter({
                                originalScript: analysisResult.selectedScript.scriptCode,
                                fixedScript: analysisResult.fixedScriptCode,
                                userValidated: false // Only find unvalidated ones
                            });
                            const recentFix = fixes.find(fix =>
                              fix.problemDescription === (errorDescription || "User reported script issues")
                            );
                            if (recentFix) {
                              await ScriptFix.update(recentFix.id, { userValidated: true });
                              setSuccess("Thanks! This fix has been validated and will help improve future AI script generation.");
                              setTimeout(() => setSuccess(null), 4000);
                            } else {
                              // This case might happen if they update first, or if for some reason the fix wasn't saved.
                              // Or if it was already validated.
                              setSuccess("Fix already validated or no pending fix found to validate. Thanks anyway!");
                              setTimeout(() => setSuccess(null), 4000);
                            }
                          } catch (e) {
                            console.error("Failed to validate fix:", e);
                            setError("Failed to confirm fix. Please try again.");
                          }
                        }}
                        variant="outline"
                        className="border-green-600 text-green-300 hover:bg-green-900/30"
                      >
                        ✓ Confirm Fix Works (Help AI Learn)
                      </Button>
                    )}
                  </div>
                </div>
              </>
            ) : (
              <>
                {/* General Troubleshooting Results */}
                <div>
                  <h4 className="text-yellow-300 font-medium mb-2">Problem Type: {analysisResult.problemType}</h4>
                  <p className="text-gray-300 text-sm bg-gray-800/50 p-3 rounded-md">{analysisResult.diagnosis}</p>
                </div>

                <div>
                  <h4 className="text-blue-300 font-medium mb-2">Solutions to Try:</h4>
                  <ol className="text-gray-300 text-sm space-y-1 list-decimal pl-5">
                    {analysisResult.solutions.map((solution, i) => (
                      <li key={i}>{solution}</li>
                    ))}
                  </ol>
                </div>

                <div>
                  <h4 className="text-green-300 font-medium mb-2">Prevention Tips:</h4>
                  <ul className="text-gray-300 text-sm space-y-1 list-disc pl-5">
                    {analysisResult.preventionTips.map((tip, i) => (
                      <li key={i}>{tip}</li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="text-red-300 font-medium mb-2">Common Mistakes:</h4>
                  <ul className="text-gray-300 text-sm space-y-1 list-disc pl-5">
                    {analysisResult.commonMistakes.map((mistake, i) => (
                      <li key={i}>{mistake}</li>
                    ))}
                  </ul>
                </div>
                <div className="mt-6 p-4 bg-yellow-900/20 border border-yellow-700/50 rounded-md">
                  <h4 className="text-yellow-300 font-medium mb-2">What's Next?</h4>
                  <p className="text-yellow-200 text-sm mb-3">
                    Try the suggested solutions. If they don't work or you need more help, start a discussion with the AI.
                  </p>
                  <Button
                    onClick={handleStartErrorDiscussion}
                    variant="outline"
                    className="border-blue-600 text-blue-300 hover:bg-blue-900/30"
                  >
                    💬 Continue Discussion with AI
                  </Button>
                </div>
              </>
            )}
          </CardContent>
        </div>
      )}

      {/* Error Discussion Mode */}
      {errorDiscussionMode && (
        <div className="space-y-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-yellow-200 flex items-center gap-2">
              <MessageSquare className="w-6 h-6" /> AI Error Discussion
            </h2>
            <Button variant="ghost" onClick={handleEndErrorDiscussion} className="text-gray-400 hover:text-white">
              <RotateCcw className="w-4 h-4 mr-2" />
              End Discussion
            </Button>
          </div>

          {/* Discussion History */}
          <div className="space-y-4">
            {errorDiscussionHistory.map((item, index) => (
              <Card key={index} className={
                item.type === 'user_response' ? "bg-blue-900/20 border-blue-700/50" : "bg-gray-800/50 border-yellow-800/30"
              }>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-full ${item.type === 'user_response' ? 'bg-blue-700 text-white' : 'bg-yellow-700 text-black'}`}>
                      {item.type === 'user_response' ? '👤' : '🤖'}
                    </div>
                    <div className="flex-1">
                      {item.type === 'initial_analysis' ? (
                        <div>
                          <p className="text-gray-300 font-medium mb-2">Initial Analysis Complete</p>
                          <p className="text-gray-400 text-sm">AI provided {item.content.isScriptFix ? 'script fix' : 'troubleshooting guidance'}. Review the analysis above. Continue the discussion below if you need more help.</p>
                        </div>
                      ) : item.type === 'ai_followup' ? (
                        <div className="space-y-3">
                          <p className="text-gray-300">{item.content.response}</p>

                          {item.content.newSolutions && item.content.newSolutions.length > 0 && (
                            <div>
                              <h5 className="text-green-300 text-sm font-medium mb-1">Try These Alternatives:</h5>
                              <ul className="text-sm text-gray-400 space-y-1">
                                {item.content.newSolutions.map((solution, i) => (
                                  <li key={i} className="flex items-start gap-1">
                                    <span className="text-green-400">•</span>
                                    <span>{solution}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {item.content.troubleshootingQuestions && item.content.troubleshootingQuestions.length > 0 && (
                            <div>
                              <h5 className="text-blue-300 text-sm font-medium mb-1">Help Me Understand:</h5>
                              <ul className="text-sm text-gray-400 space-y-1">
                                {item.content.troubleshootingQuestions.map((question, i) => (
                                  <li key={i} className="flex items-start gap-1">
                                    <span className="text-blue-400">?</span>
                                    <span>{question}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {item.content.updatedScriptCode && (
                            <div>
                              <h5 className="text-purple-300 text-sm font-medium mb-2">Updated Script Code:</h5>
                              <pre className="bg-black/50 p-3 rounded-md text-xs text-green-300 overflow-x-auto border border-gray-700">
                                <code>{item.content.updatedScriptCode}</code>
                              </pre>
                            </div>
                          )}

                          {item.content.nextSteps && item.content.nextSteps.length > 0 && (
                            <div>
                              <h5 className="text-orange-300 text-sm font-medium mb-1">Next Steps:</h5>
                              <ol className="text-sm text-gray-400 space-y-1 list-decimal pl-4">
                                {item.content.nextSteps.map((step, i) => (
                                  <li key={i}>{step}</li>
                                ))}
                              </ol>
                            </div>
                          )}
                        </div>
                      ) : (
                        <p className="text-gray-300">{item.content}</p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>


          {/* Response Input */}
          <Card className="bg-gray-800/50 border-yellow-800/30">
            <CardHeader>
              <CardTitle className="text-yellow-300 text-lg">Your Feedback</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="relative">
                <Textarea
                  value={userFollowupResponse}
                  onChange={(e) => setUserFollowupResponse(e.target.value)}
                  placeholder="Describe what happened when you tried the suggestions. What errors did you get? What didn't work as expected? The more specific you are, the better I can help."
                  className="h-24 bg-gray-900 border-yellow-800/50 text-gray-200 pr-12"
                />
                <div className="absolute top-2 right-2">
                  <VoiceToText
                    onTranscript={(text) => setUserFollowupResponse(prev => prev.trim() + (prev.trim() ? " " : "") + text)}
                    className="bg-gray-900/80 backdrop-blur rounded"
                  />
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  onClick={handleErrorDiscussionResponse}
                  disabled={isErrorDiscussionAnalyzing || !userFollowupResponse.trim()}
                  className="bg-yellow-700 hover:bg-yellow-600 text-black"
                >
                  {isErrorDiscussionAnalyzing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      AI Analyzing...
                    </>
                  ) : (
                    <>
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Get More Help
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error!</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Success Alert */}
      {success && (
        <Alert className="bg-green-900/20 border-green-700/50 text-green-300">
          <CheckCircle className="h-4 w-4 text-green-400" />
          <AlertTitle>Success!</AlertTitle>
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the
              {itemToDelete?.type === 'project' ? ` project "${itemToDelete?.name}" and all its associated scripts.` : ` script "${itemToDelete?.name}".`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              disabled={isDeleting}
              className="bg-red-600 hover:bg-red-700"
            >
              {isDeleting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                'Delete'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Stats Cards */}
      {stats.total > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <div className="magical-card bg-gray-800/50 border-yellow-800/30 p-4 text-center">
            <div className="card-sparkle-1"></div>
            <div className="card-sparkle-2"></div>
            <div className="text-2xl font-bold text-yellow-300">{stats.total}</div>
            <div className="text-sm text-gray-400">Total Scripts</div>
          </div>
          <div className="magical-card bg-gray-800/50 border-yellow-800/30 p-4 text-center">
            <div className="card-sparkle-1"></div>
            <div className="card-sparkle-3"></div>
            <div className="text-2xl font-bold text-blue-300">{stats.projects}</div>
            <div className="text-sm text-gray-400">Projects</div>
          </div>
          {Object.entries(stats.byGame).map(([game, count]) => (
            <div key={game} className="magical-card bg-gray-800/50 border-yellow-800/30 p-4 text-center">
              <div className="card-sparkle-2"></div>
              <div className="card-sparkle-4"></div>
              <div className="flex items-center justify-center gap-2 mb-1">
                {gameIcons[game]}
                <div className="text-xl font-bold text-yellow-300">{count}</div>
              </div>
              <div className="text-sm text-gray-400">{game}</div>
            </div>
          ))}
        </div>
      )}

      {/* Filters */}
      <div id="filters-section" className="magical-card bg-gray-800/50 border-yellow-800/30 p-4">
        <div className="card-sparkle-1"></div>
        <CardContent className="p-0">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search scripts..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-gray-900 border-yellow-800/50 text-gray-200"
                />
              </div>
            </div>
            <Select value={gameFilter} onValueChange={setGameFilter}>
              <SelectTrigger className="w-full md:w-48 bg-gray-900 border-yellow-800/50 text-gray-200">
                <SelectValue placeholder="Filter by game" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Games</SelectItem>
                <SelectItem value="Morrowind">Morrowind</SelectItem>
                <SelectItem value="Oblivion">Oblivion</SelectItem>
                <SelectItem value="Skyrim">Skyrim</SelectItem>
                <SelectItem value="TES3MP">TES3MP</SelectItem>
              </SelectContent>
            </Select>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full md:w-48 bg-gray-900 border-yellow-800/50 text-gray-200">
                <SelectValue placeholder="Filter by category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="NPC">NPC</SelectItem>
                <SelectItem value="Object">Object</SelectItem>
                <SelectItem value="Quest">Quest</SelectItem>
                <SelectItem value="Utility">Utility</SelectItem>
                <SelectItem value="Combat">Combat</SelectItem>
                <SelectItem value="Magic">Magic</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </div>

      {/* Scripts Grid */}
      {filteredScripts.length === 0 ? (
        <div className="magical-card bg-gray-800/50 border-yellow-800/30 p-8 text-center">
          <div className="card-sparkle-2"></div>
          <div className="card-sparkle-4"></div>
          <CardContent className="p-0">
            <Library className="w-12 h-12 text-gray-500 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-400 mb-2">
              {scripts.length === 0 ? "No scripts yet" : "No scripts found"}
            </h3>
            <p className="text-gray-500 mb-4">
              {scripts.length === 0
                ? "Create your first script using the Script Generator"
                : "Try adjusting your search or filters"
              }
            </p>
            {scripts.length === 0 && (
              <Link to={createPageUrl("Home")}>
                <Button className="bg-yellow-700 hover:bg-yellow-600 text-black">
                  Create First Script
                </Button>
              </Link>
            )}
          </CardContent>
        </div>
      ) : (
        <div id="scripts-grid-area" className="space-y-6">
          {/* Project Groups */}
          {Object.entries(groupedScripts).map(([projectId, projectScripts]) => {
            const firstScript = projectScripts[0]; // Use first script to represent project info
            return (
              <div key={projectId} className="magical-card bg-gray-800/50 border-yellow-800/30 hover:border-yellow-600/50 transition-colors p-6">
                <div className="card-sparkle-1"></div>
                <div className="card-sparkle-3"></div>
                <CardHeader className="p-0">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-yellow-300 text-lg mb-2">
                        📁 {firstScript.projectName}
                      </CardTitle>
                      {firstScript.projectDescription && (
                        <p className="text-gray-300 text-sm mb-3">
                          {firstScript.projectDescription}
                        </p>
                      )}
                      <div className="flex gap-2 flex-wrap">
                        <Badge className={`${gameColors[firstScript.game]} border`}>
                          {gameIcons[firstScript.game]}
                          <span className="ml-1">{firstScript.game}</span>
                        </Badge>
                        <Badge className="bg-blue-900/50 text-blue-300">
                          {projectScripts.length} Script{projectScripts.length !== 1 ? 's' : ''}
                        </Badge>
                        {/* Display unique categories for the project */}
                        {[...new Set(projectScripts.map(script => script.category))].map((category, index) => (
                          <Badge key={index} className={`${categoryColors[category]} border-0 text-xs`}>
                            {category}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={() => openDeleteDialog('project', projectId, firstScript.projectName)}
                            className="text-red-400 focus:bg-red-900/50 focus:text-red-300"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete Project
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3 p-0">
                  <div className="text-xs text-gray-500">
                    Created {format(new Date(firstScript.created_date), 'MMM d, yyyy')}
                  </div>

                  {/* Individual Scripts in Project */}
                  <div className="grid gap-2">
                    {projectScripts.map(script => (
                      <div key={script.id} className="flex items-center justify-between p-3 bg-gray-900/50 rounded-md border border-gray-700/50">
                        <div className="flex-1">
                          <div className="font-medium text-gray-200">{script.title}</div>
                          <div className="text-sm text-gray-400 line-clamp-1">{script.description}</div>
                        </div>
                        <Link to={createPageUrl(`ScriptDetail?id=${script.id}`)}>
                          <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </Link>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </div>
            );
          })}

          {/* Individual Scripts */}
          {individualScripts.length > 0 && (
            <>
              {Object.keys(groupedScripts).length > 0 && (
                <div className="border-t border-gray-700 pt-6">
                  <h3 className="text-lg font-medium text-gray-300 mb-4">Individual Scripts</h3>
                </div>
              )}
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {individualScripts.map((script) => (
                  <div key={script.id} className="magical-card bg-gray-800/50 border-yellow-800/30 hover:border-yellow-600/50 transition-colors p-6">
                    <div className="card-sparkle-2"></div>
                    <div className="card-sparkle-4"></div>
                    <CardHeader className="p-0">
                      <div className="flex items-start justify-between">
                        <CardTitle className="text-yellow-300 text-lg truncate">
                          {script.title}
                        </CardTitle>
                        <div className="flex items-center">
                          <Link to={createPageUrl(`ScriptDetail?id=${script.id}`)}>
                            <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                              <Eye className="w-4 h-4" />
                            </Button>
                          </Link>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-red-500 hover:text-red-400"
                            onClick={() => openDeleteDialog('script', script.id, script.title)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex gap-2 flex-wrap">
                        <Badge className={`${gameColors[script.game]} border`}>
                          {gameIcons[script.game]}
                          <span className="ml-1">{script.game}</span>
                        </Badge>
                        <Badge className={`${categoryColors[script.category]} border-0`}>
                          {script.category}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-0">
                      <p className="text-gray-300 text-sm mb-3 line-clamp-3">
                        {script.description}
                      </p>
                      <div className="text-xs text-gray-500">
                        Created {format(new Date(script.created_date), 'MMM d, yyyy')}
                      </div>
                    </CardContent>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
