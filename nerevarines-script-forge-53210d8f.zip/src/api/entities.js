import { base44 } from './base44Client';


export const GameScript = base44.entities.GameScript;

export const ScriptFix = base44.entities.ScriptFix;

export const LearningFile = base44.entities.LearningFile;

export const AILearningReport = base44.entities.AILearningReport;

export const AIScriptSession = base44.entities.AIScriptSession;



// auth sdk:
export const User = base44.auth;